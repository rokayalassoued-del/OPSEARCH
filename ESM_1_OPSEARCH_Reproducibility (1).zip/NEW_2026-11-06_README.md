# OPSEARCH — reproducibility completion, 6 November 2026

Manuscript OPSE-D-26-00417. This release extends the preceding Online Resource 1 archive without replacing its archived numerical evidence. It supplies newly recorded environment information and replay runs for the recovered six large instances, the previously omitted 216-run PSO parameter study, and a wall-clock/evaluation-budget reconciliation.

## Evidence streams and limitations

1. **Archived L1–L6, original four-run PSO pilot:** original generator, original code, seeds, objective records and reported loop timings. The originally used computer and software-build version have *not* been recovered.
2. **Independent current-host replay (6 Nov 2026):** the archived code was rerun four times per each L1–L6 input using identical seeds. All six FCFS/PSO objective summaries match the archived figures to their original printed precision. The new host properties and measured times are stored in `2026-11-06_verification/environment/` and `.../results/NEW_REPLAY_...`. New timings are not substituted for historical ones.
3. **216 supplementary PSO parameter experiments:** 3 datasets (L1, L3, L6) × 12 random replicates × 6 settings (iterations 20/45/70 and local-search intervals 5/10/15). The full 216 numeric scores were regenerated with the unchanged original PSO reference; 216/216 match. Iteration counts have **different** objective budgets (244/528/829 evaluations). Local-search intervals share a 528-evaluation budget by redistributing trial moves among calls; consequently those tests change frequency **and per-call search effort**.
4. **Other stress/holdout/arrival experiments:** complete input files, codes and run logs remain in the pre-existing nested packages. Fixed-budget comparisons use 528 objective evaluations per method per run. The exploratory 0.35-s wall-clock experiment uses 384 runs on twelve synthetic conditions, under a potentially noisy shared compute environment. Neither result supports universal superiority or a common CPU-time interpretation.
5. **New exact benchmarks:** 9/10 have independent saved optimality certificates; NEW-M4 has a valid feasible schedule and a gap of about 15.78% after a 3,600-s cutoff. These new synthetic input datasets differ from the historical S1–M4 submissions. Original S1–M4 vessel-level inputs and exact-solver certificates are unavailable.

## Current computational environment (new replay only)

Linux x86_64; reported CPU `AMD EPYC 9V74 80-Core Processor`; 5 logical CPUs visible to the process, 4 CPU equivalents as a cgroup quota; 4 GiB cgroup memory limit; Python 3.13.5; NumPy 2.3.5; SciPy 1.17.0; bundled HiGHS 1.8.0. Execution was inside a containerized cloud environment. HiGHS was **queried in the current environment** and is not identified as the historical MILP solver build.

## Rerunning from an extracted archive

From the location of this README, change directory to `2026-11-06_verification`. Then run:

```
python source/independent_replay_and_environment.py
python source/replay_216_parameter_runs.py
```

The first command records new run timings and environment details. The second writes `results/recomputed_216/ADDITIONAL_PSO_PARAMETER_RUNS.csv`. Both operate on the preserved source under `source/`. Objective values are repeatable with the same code and seeds; wall-clock durations depend on machine load, software and hardware. The primary archived `source_records`, `linked_reproducibility_packages`, and `verification` directories have their original paths in this updated ESM archive.

## Manuscript and response files

Editable LaTeX sources and the response letter are distributed separately. The submission editor instructed authors to upload editable sources, not a manuscript PDF. The response letter distinguishes Editor, Reviewer 1, and Reviewer 2 and cites current-host verification separately from unavailable original machine details.
