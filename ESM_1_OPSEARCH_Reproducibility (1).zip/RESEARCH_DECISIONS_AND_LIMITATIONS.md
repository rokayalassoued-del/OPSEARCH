# OPSEARCH — final scientific results selection (working research record)

**Manuscript:** OPSE-D-26-00417  
**Date:** 5 November 2026  
**Status:** Technical selection complete. Submitted LaTeX and reviewer responses have not been edited.

## Selection decision

The final comparison evidence will use four primary tables, with a strict provenance separation:

1. **New exact MILP benchmark (MAIN-01):** 10 newly generated S/M instances. S1–S6 and M1–M3 (nine) were reported as proven optimal in saved HiGHS files. NEW-M4 terminated at the one-hour limit with objective 1343.041945, certified lower bound 1131.050525, and a 15.7844% gap on the article objective. All ten saved schedules passed the independent feasibility and objective checks. Use the explicit **NEW-** prefix everywhere.
2. **Recovered six large instances, fresh 30-run algorithm comparison (MAIN-02):** same original L1–L6 instances regenerated from original seeds; the Stage 3 four-method comparison is new. PSO has the lowest 30-run mean in six out of six; GA has the best individual run on L2. All four methods received 528 objective evaluations, not identical wall-clock times.
3. **Independent holdout (MAIN-03):** Stage 5 contains 96 related synthetic treatments across **12 independent generator-seed families**. Family-level comparisons favor the original PSO on mean by +1.969% vs GA, +4.759% vs SA, +9.545% vs MSLS. Use family-blocked confidence intervals and Holm-adjusted p-values stored alongside effects; the two PSO tuning variants are supplementary.
4. **Arrival-pattern robustness (MAIN-04):** Stage 6 tests uniform, rising-intensity non-homogeneous Poisson conditional on N, and clustered arrivals on 12 families. Report all nine tested comparisons in supplements; a concise GA-focused three-row comparison may fit the main manuscript. Service requirements and compatibility were held constant within each matched instance.

## Research-only supporting evidence

- Original L1–L6 four-run data are reproducible, but are historic (SUP-01). Original schedules violate the printed hard completion deadline c_j <= H, so they require the corrected arrival-window model interpretation to be used consistently.
- Correct the **four flagged** aggregate descriptors in the final manuscript when writing begins (SUP-02). Full-precision archive: best improvement mean 13.853883...% -> **13.85%**, SD of best improvement **2.40**, SD of average improvement **2.39**, SD of per-instance objective SDs **230.63**. The submitted displayed values were 13.86, 2.42, 2.46, and 230.18, respectively.
- Stage 4 (54 stress cases, 6,480 runs) is exploratory because there are only three independent seed families. Keep condition-level comparisons and parameter-screening outputs in supplement, with no unsupported independence claims.
- Historic S1–S6 and M1–M4 are **ARCHIVE ONLY**. The summary values exist, but the ten original vessel-level datasets, historic CPLEX/HiGHS models, and original optimality certificates remain unavailable. Distinguish **HIST-S1** from **NEW-S1**, etc. The archived historic exact objectives (around 70–193) are not comparable by ID with newly generated objectives (around 575–1895).

## Interpretation and reporting safeguards

- Objective for all chosen new experimental tables: total turnaround time = sum_j(c_j - a_j). Smaller is better. Difference of objective conventions between HiGHS native sum(c_j) and paper sum(c_j-a_j) means **recalculate the relative bound gap** on the article objective; the dataset stores both source and recalculated values.
- An optimality certificate applies only to exact MILP instances where the solver explicitly returned proven optimal; it never applies to heuristic schedules or NEW-M4.
- Do not generalize estimated synthetic performance effects to measured Sfax port operations. The generator is shared across independent seed families; different seeds are not different data-generating processes.
- PSO priority-based greedy decoder can miss MILP feasible optimal assignments; it is a feasible heuristic, not an exact parameterization of the full MILP feasible region.
- Security control and payment time remain part of every vessel processing time under the declared berth-occupation assumptions. The original quantity limit is not binding independently on the original L1–L6 generator, so it cannot be credited with observed improvements in those cases.
- Original runtime observations depend on hardware and implementation; compare CPU times under documented same-platform conditions. Evaluation-budget equality does not imply runtime equality. Stage 4 contains a short equal-time pilot, not strong external validation.
- Existing original plots match their legacy input tables, but regenerated primary-table figures must come from NEW selected CSVs; the original plots must not be rebranded as new evidence.

## Source traceability and audit method

Each selected CSV includes a source-file pointer to one unchanged raw CSV within `source_records/`. NEW exact cases additionally carry the source input SHA-256. `00_MASTER_evidence_register.csv` records the main/supplement/archive classification and the limitations. `verification/INDEPENDENT_SELECTION_CHECKS.csv` provides fresh consistency tests. Computation independently reaggregates Stage 3 (1,920 rows), Stage 5 (5,760 rows), and Stage 6 (5,760 rows) using their saved full-precision objectives. Family-level percentage effects match the previously saved inference tables numerically, to floating-point tolerance.

**Decision gate:** The numerical material for the planned main tables is selected. The original exact-data provenance limitation and synthetic external-validity limitation remain disclosure requirements. The manuscript and reviewer replies are intentionally unchanged.
