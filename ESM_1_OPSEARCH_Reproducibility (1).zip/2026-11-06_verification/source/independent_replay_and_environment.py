"""Portable OPSEARCH environment capture and recovered PSO 4-run replay.
Run: python source/independent_replay_and_environment.py
It is an independent NEW REPLAY on the executing machine, never a record of the original machine.
"""
from pathlib import Path
import os,sys,platform,time,json,csv,hashlib,statistics,math,socket
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source'))
from synthetic_pso_experiments_ORIGINAL import gen_instance, decode_fcfs, pso
import scipy,numpy
from scipy.optimize._highspy import _core

def read(path):
 try:return Path(path).read_text().strip()
 except OSError:return None

def cpu_model():
 s=read('/proc/cpuinfo') or ''
 for line in s.splitlines():
  if line.lower().startswith('model name'):
   return line.split(':',1)[-1].strip()
 return platform.processor()

def cgroup_limit(path):
 s=read(path)
 return s if s and s!='max' else None

def filesize_sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
 return h.hexdigest()

def run():
 env={'source':'execution host at runtime; new replay only',
      'timestamp_utc':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),
      'processor_model_visible':cpu_model(),
      'logical_processors_visible':os.cpu_count(),
      'process_cpu_affinity_count':len(os.sched_getaffinity(0)) if hasattr(os,'sched_getaffinity') else None,
      'linux_kernel':platform.release(),'platform':platform.platform(),
      'python':sys.version.split()[0], 'numpy':numpy.__version__, 'scipy':scipy.__version__,
      'highs_backend_version':f'{_core.HIGHS_VERSION_MAJOR}.{_core.HIGHS_VERSION_MINOR}.{_core.HIGHS_VERSION_PATCH}',
      'cgroup_memory_limit_bytes':cgroup_limit('/sys/fs/cgroup/memory.max'),
      'cgroup_cpu_quota_period':cgroup_limit('/sys/fs/cgroup/cpu.max'),
      'original_code_sha256':filesize_sha(ROOT/'source'/'synthetic_pso_experiments_ORIGINAL.py'),
      'timing_clock':'time.perf_counter() (wall-clock; internal PSO loop timer excludes initialization and initial swarm decoding)',
      'original_2019_hardware_proven':False,
      'original_submitted_four_run_hardware_proven':False}
 (ROOT/'environment'/'CURRENT_EXECUTION_ENVIRONMENT_ONLY.json').write_text(json.dumps(env,indent=2)+'\n')
 cases=[('L1',60,15),('L2',72,11),('L3',84,37),('L4',96,23),('L5',108,23),('L6',120,12)]
 rows=[]
 for name,n,seed in cases:
  t0=time.perf_counter();inst=gen_instance(n,seed);generate=time.perf_counter()-t0
  t1=time.perf_counter();fcfs=decode_fcfs(inst);fcfs_wall=time.perf_counter()-t1
  t2=time.perf_counter();runs=pso(inst,runs=4);full_pso=time.perf_counter()-t2
  for run,(obj,loop) in enumerate(runs):
   rows.append({'case':name,'n_vessels':n,'generator_seed':seed,'run_index':run,
           'reported_seed':100000+seed*100+run,'workload_rho':inst['rho'],
           'fcfs_obj':fcfs,'pso_obj':obj,'pso_internal_search_loop_s':loop,
           'pso_total_4run_wall_s':full_pso,'pso_4run_est_average_full_s':full_pso/4,
           'instance_generation_wall_s':generate,'fcfs_wall_s':fcfs_wall,'replay_environment':'CURRENT_EXECUTION_ENVIRONMENT_ONLY'})
  print(name,'best',round(min(x[0] for x in runs),4),'mean internal loop',round(statistics.mean(x[1] for x in runs),5),'four-run elapsed',round(full_pso,4),flush=True)
 with (ROOT/'results'/'NEW_REPLAY_L1_L6_24_runs.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 summary=[]
 for name,n,seed in cases:
  part=[r for r in rows if r['case']==name]
  summary.append({'case':name,'runs':4,'fcfs_obj':part[0]['fcfs_obj'],
    'pso_best_obj':min(r['pso_obj'] for r in part),'pso_mean_obj':statistics.mean(r['pso_obj'] for r in part),
    'pso_pstd_obj':statistics.pstdev(r['pso_obj'] for r in part),
    'pso_mean_internal_loop_s_new_host':statistics.mean(r['pso_internal_search_loop_s'] for r in part),
    'pso_mean_whole_call_s_new_host':part[0]['pso_4run_est_average_full_s'],
    'fcfs_wall_s_single_call_new_host':part[0]['fcfs_wall_s']})
 with (ROOT/'results'/'NEW_REPLAY_L1_L6_SUMMARY.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
 return env,summary
if __name__=='__main__':run()
