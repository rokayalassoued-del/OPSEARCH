"""After replay_216_parameter_runs.py, compare every saved objective & evaluation with regenerated data."""
import csv,math
from pathlib import Path
base=Path(__file__).resolve().parents[1]
def read(p):return list(csv.DictReader(open(p,encoding='utf-8')))
for fname in ('ADDITIONAL_PSO_PARAMETER_RUNS.csv','ADDITIONAL_PSO_PARAMETER_SUMMARY.csv'):
 orig=read(base/'results'/fname);new=read(base/'results'/'recomputed_216'/fname)
 assert len(orig)==len(new),(fname,len(orig),len(new))
 for i,(a,b) in enumerate(zip(orig,new)):
  for k in a:
   if a[k]==b[k]:continue
   try: pass_same=math.isclose(float(a[k]),float(b[k]),rel_tol=1e-12,abs_tol=1e-8)
   except ValueError:pass_same=False
   assert pass_same,(fname,i,k,a[k],b[k])
 print(fname,len(orig),'PASS')
