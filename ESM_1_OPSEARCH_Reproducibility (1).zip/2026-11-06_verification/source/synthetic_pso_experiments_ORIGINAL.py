"""Synthetic large-instance generator and random-key PSO used to create the
illustrative scalability results reported in ord_bulk_bap_full.tex.
This script is included for reproducibility of the synthetic study.
"""
import csv
import math
import random
import statistics
import time


def make_berth_params():
    params = {}
    for i in range(1, 14):
        if i <= 4:
            L = 170 + 10 * (i - 1)
            D = 8.5 + 0.3 * (i - 1)
            q = 4500 + 300 * (i - 1)
            eta = 0.90 + 0.03 * (i - 1)
            cargo = (1, 2)
        elif i <= 9:
            L = 220 + 10 * (i - 5)
            D = 10.0 + 0.2 * (i - 5)
            q = 6500 + 400 * (i - 5)
            eta = 1.00 + 0.025 * (i - 5)
            cargo = (1, 2, 3)
        else:
            L = 280 + 15 * (i - 10)
            D = 11.5 + 0.3 * (i - 10)
            q = 9000 + 500 * (i - 10)
            eta = 1.10 + 0.02 * (i - 10)
            cargo = (2, 3)
        params[i] = {"L": L, "D": D, "q": q, "eta": eta, "cargo": set(cargo)}
    return params


PARAMS = make_berth_params()
BASE_L = {1: 0.018, 2: 0.022, 3: 0.028}
BASE_U = {1: 0.016, 2: 0.020, 3: 0.026}


def sample_cargo(r):
    return 1 if r < 0.45 else 2 if r < 0.80 else 3


def gen_instance(n, seed, arrival_frac=0.35, rho_low=0.86, rho_high=0.95):
    rnd = random.Random(seed)
    H = 72 + 6 * n
    while True:
        feas = []
        P = []
        for _ in range(n):
            while True:
                w = sample_cargo(rnd.random())
                ell = rnd.uniform(110, 180) if w == 1 else rnd.uniform(150, 230) if w == 2 else rnd.uniform(200, 300)
                d = min(13, max(6, 4.5 + 0.025 * ell + rnd.uniform(-0.5, 0.5)))
                if w == 1:
                    QL, QU = rnd.uniform(800, 2200), rnd.uniform(1000, 2600)
                elif w == 2:
                    QL, QU = rnd.uniform(1500, 3500), rnd.uniform(1800, 4200)
                else:
                    QL, QU = rnd.uniform(2500, 5500), rnd.uniform(3000, 6500)
                r = rnd.random()
                if r < 0.15:
                    QL = 0.0
                elif r < 0.30:
                    QU = 0.0
                sct = rnd.uniform(1.0, 3.0)
                ppt = rnd.uniform(0.5, 1.5)
                f = []
                pp = {}
                for i, par in PARAMS.items():
                    if ell <= par["L"] and d <= par["D"] and QU <= par["q"] and w in par["cargo"]:
                        f.append(i)
                        pp[i] = BASE_L[w] / par["eta"] * QL + BASE_U[w] / par["eta"] * QU + sct + ppt
                if f:
                    feas.append(tuple(f))
                    P.append(pp)
                    break
        us = sorted(rnd.random() for _ in range(n))
        A = [math.floor(arrival_frac * H * u) for u in us]
        rho = sum(min(pp.values()) for pp in P) / (13 * H)
        if rho_low <= rho <= rho_high:
            return {"n": n, "H": H, "A": A, "feas": feas, "P": P, "seed": seed, "rho": rho}


def decode_fcfs(inst):
    A, feas, P = inst["A"], inst["feas"], inst["P"]
    seq = sorted(range(inst["n"]), key=lambda j: (A[j], j))
    avail = {i: 0.0 for i in PARAMS}
    total = 0.0
    for j in seq:
        fj = feas[j]
        avail_now = [i for i in fj if avail[i] <= A[j]]
        if avail_now:
            i, s = min(avail_now), A[j]
        else:
            i = min(fj, key=lambda b: (avail[b], b))
            s = avail[i]
        c = s + P[j][i]
        avail[i] = c
        total += c - A[j]
    return total


def decode_keys(inst, keys):
    A, feas, P = inst["A"], inst["feas"], inst["P"]
    seq = sorted(range(inst["n"]), key=lambda j: (keys[j], A[j], j))
    avail = [0.0] * 14
    total = 0.0
    for j in seq:
        Aj = A[j]
        best_i, best_c = None, None
        for i in feas[j]:
            s = Aj if Aj > avail[i] else avail[i]
            c = s + P[j][i]
            if best_c is None or c < best_c or (c == best_c and i < best_i):
                best_i, best_c = i, c
        avail[best_i] = best_c
        total += best_c - Aj
    return total, seq


def seq_to_keys(seq):
    keys = [0.0] * len(seq)
    for pos, j in enumerate(seq):
        keys[j] = pos
    return keys


def local_search(inst, seq, max_trials=15, rnd=None):
    rnd = rnd or random
    best_seq = seq[:]
    best_obj = decode_keys(inst, seq_to_keys(best_seq))[0]
    n = len(seq)
    for _ in range(max_trials):
        cand = best_seq[:]
        if rnd.random() < 0.5:
            a, b = rnd.sample(range(n), 2)
            cand[a], cand[b] = cand[b], cand[a]
        else:
            a, b = rnd.sample(range(n), 2)
            x = cand.pop(a)
            cand.insert(b, x)
        obj = decode_keys(inst, seq_to_keys(cand))[0]
        if obj < best_obj:
            best_obj, best_seq = obj, cand
    return best_obj, best_seq


def pso(inst, runs=4, swarm_size=10, iterations=45, c1=1.7, c2=2.0, vmax=4.0):
    n = inst["n"]
    results = []
    for run in range(runs):
        rnd = random.Random(100000 + inst["seed"] * 100 + run)
        X = [[rnd.random() for _ in range(n)] for _ in range(swarm_size)]
        V = [[rnd.uniform(-1, 1) for _ in range(n)] for _ in range(swarm_size)]
        pbest = [x[:] for x in X]
        pbest_obj = [decode_keys(inst, x)[0] for x in X]
        g = min(range(swarm_size), key=lambda p: pbest_obj[p])
        gbest = pbest[g][:]
        gbest_obj = pbest_obj[g]
        t0 = time.perf_counter()
        for it in range(iterations):
            w = 0.9 - 0.5 * it / max(1, iterations - 1)
            for p in range(swarm_size):
                xp, vp, pb = X[p], V[p], pbest[p]
                for j in range(n):
                    v = w * vp[j] + c1 * rnd.random() * (pb[j] - xp[j]) + c2 * rnd.random() * (gbest[j] - xp[j])
                    v = max(-vmax, min(vmax, v))
                    vp[j] = v
                    xp[j] += v
                obj, _ = decode_keys(inst, xp)
                if obj < pbest_obj[p]:
                    pbest_obj[p] = obj
                    pbest[p] = xp[:]
                    if obj < gbest_obj:
                        gbest_obj = obj
                        gbest = xp[:]
            if it % 10 == 9:
                _, seq = decode_keys(inst, gbest)
                ls_obj, ls_seq = local_search(inst, seq, max_trials=15, rnd=rnd)
                if ls_obj < gbest_obj:
                    gbest_obj = ls_obj
                    gbest = seq_to_keys(ls_seq)
        elapsed = time.perf_counter() - t0
        results.append((gbest_obj, elapsed))
    return results


def main():
    chosen = [("L1", 60, 15), ("L2", 72, 11), ("L3", 84, 37), ("L4", 96, 23), ("L5", 108, 23), ("L6", 120, 12)]
    with open("large_results_reproduced.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Instance", "Berths", "Vessels", "Horizon_h", "Workload_ratio", "FCFS_obj", "Best_PSO", "Avg_PSO", "StdDev", "Avg_time_s", "Best_impr_pct", "Avg_impr_pct"])
        for label, n, seed in chosen:
            inst = gen_instance(n, seed)
            fcfs = decode_fcfs(inst)
            res = pso(inst)
            objs = [o for o, _ in res]
            times = [t for _, t in res]
            writer.writerow([
                label, 13, n, inst["H"], round(inst["rho"], 10), round(fcfs, 4), round(min(objs), 4),
                round(statistics.mean(objs), 4), round(statistics.pstdev(objs), 4), round(statistics.mean(times), 4),
                round((fcfs - min(objs)) / fcfs * 100, 4), round((fcfs - statistics.mean(objs)) / fcfs * 100, 4)
            ])


if __name__ == "__main__":
    main()
