"""Standalone regeneration of 216 exploratory PSO parameter runs.
Run from an extracted reproducibility package; it uses the preserved original PSO code.
Call-interval treatments also redistribute local-search trials to equalize evaluations.
Iteration treatments change both iterations and evaluation budget.
"""
from pathlib import Path
import csv, math, random, statistics, sys, time
source=Path(__file__).resolve().parent
sys.path.insert(0,str(source))
from synthetic_pso_experiments_ORIGINAL import gen_instance, decode_keys, local_search,seq_to_keys,pso
cases=[('L1',60,15),('L3',84,37),('L6',120,12)]
S=10

def run(inst,rep,iterations=45,freq=10,trialcounts=None):
    n=inst['n'];rnd=random.Random(100000+inst['seed']*100+rep)
    X=[[rnd.random() for _ in range(n)] for _ in range(S)]
    V=[[rnd.uniform(-1,1) for _ in range(n)] for _ in range(S)]
    PB=[x[:] for x in X];pbo=[decode_keys(inst,x)[0] for x in X]; evaluations=S
    k=min(range(S),key=lambda i:pbo[i]);GB=PB[k][:];best=pbo[k]
    loc=0
    for it in range(iterations):
      w=.9-.5*it/max(1,iterations-1)
      for p in range(S):
        xp,vp,pb=X[p],V[p],PB[p]
        for j in range(n):
          v=w*vp[j]+1.7*rnd.random()*(pb[j]-xp[j])+2.0*rnd.random()*(GB[j]-xp[j])
          v=max(-4.,min(4.,v));vp[j]=v;xp[j]+=v
        obj,_=decode_keys(inst,xp);evaluations+=1
        if obj<pbo[p]:
          pbo[p]=obj;PB[p]=xp[:]
          if obj<best:best=obj;GB=xp[:]
      if (it+1)%freq==0:
        _,seq=decode_keys(inst,GB);evaluations+=1
        trials=15 if trialcounts is None else trialcounts[loc]
        ls_obj,ls_seq=local_search(inst,seq,max_trials=trials,rnd=rnd)
        evaluations+=1+trials;loc+=1
        if ls_obj<best:best=ls_obj;GB=seq_to_keys(ls_seq)
    return best,evaluations,loc

def distribute(total,blocks):
    q,r=divmod(total,blocks);return [q+(i<r) for i in range(blocks)]

rows=[]
for name,n,seed in cases:
 inst=gen_instance(n,seed)
 olds=[t[0] for t in pso(inst,runs=12)]
 for rep in range(12):
  # Reference trajectory against the unmodified original PSO implementation.
  old=olds[rep]
  x,c,k=run(inst,rep)
  assert math.isclose(x,old,rel_tol=1e-13,abs_tol=1e-7),(name,rep,x,old)
  for t in [20,45,70]:
   a,e,nloc=run(inst,rep,iterations=t,freq=10)
   rows.append(dict(case=name,seed=seed,rep=rep,design='iteration',setting=str(t),objective=a,evaluations=e,local_calls=nloc))
  for f in [5,10,15]:
   cnt=45//f
   trialcounts=distribute(68-2*cnt,cnt)
   a,e,nloc=run(inst,rep,iterations=45,freq=f,trialcounts=trialcounts)
   assert e==528,(f,e)
   rows.append(dict(case=name,seed=seed,rep=rep,design='frequency',setting=str(f),objective=a,evaluations=e,local_calls=nloc))
 print('Done',name,flush=True)
out=Path(__file__).resolve().parents[1] / 'results' / 'recomputed_216'
out.mkdir(parents=True, exist_ok=True)
with (out/'ADDITIONAL_PSO_PARAMETER_RUNS.csv').open('w',newline='') as f:
 wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
from collections import defaultdict
groups=defaultdict(list)
for r in rows:groups[(r['case'],r['design'],r['setting'])].append(r)
summary=[]
for (case,design,setting),grp in sorted(groups.items()):
 obs=[r['objective'] for r in grp]
 summary.append(dict(case=case,design=design,setting=setting,runs=len(grp),evals=grp[0]['evaluations'],local_calls=grp[0]['local_calls'],mean=statistics.mean(obs),std=statistics.stdev(obs),best=min(obs)))
with (out/'ADDITIONAL_PSO_PARAMETER_SUMMARY.csv').open('w',newline='') as f:
 wr=csv.DictWriter(f,fieldnames=list(summary[0]));wr.writeheader();wr.writerows(summary)
for x in summary:print(x)
print('VERIFIED',len(rows),'runs; archived code reproduced for',len(cases)*12,'baseline runs')
