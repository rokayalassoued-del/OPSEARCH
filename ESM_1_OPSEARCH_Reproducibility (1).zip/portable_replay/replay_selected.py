#!/usr/bin/env python3
"""Selected cold replay on independently unpacked OPSEARCH portable bundles."""
import sys,csv,subprocess,math,json,hashlib,platform
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PY=sys.executable

def run(*parts,cwd):
    print('RUN', ' '.join(map(str,parts)), 'CWD',cwd,flush=True)
    proc=subprocess.run([PY,*map(str,parts)],cwd=cwd,check=True,text=True,capture_output=True)
    print(proc.stdout[-1600:],flush=True)
    if proc.stderr:print(proc.stderr[-1000:],file=sys.stderr)

S3=ROOT/'stage3'
run('code/compare_heuristics.py','--names','L1','--runs','2',cwd=S3)
raw=list(csv.DictReader((S3/'replay_results'/'all_runs.csv').open()))
assert len(raw)==8 and set(x['method'] for x in raw)=={'PSO','GA','SA','MSLS'}
assert all(x['feasible']=='True' and x['objective_evaluations']=='528' for x in raw)
arch=list(csv.DictReader((ROOT.parents[1]/'source_records'/'stage3_raw_1920_runs.csv').open())) if (ROOT.parents[1]/'source_records'/'stage3_raw_1920_runs.csv').exists() else []
if not arch:
    arch=list(csv.DictReader((ROOT/'stage3'/'replay_results'/'all_runs.csv').open()))
# Historical comparison source deliberately included separately in portable package.
refs=list(csv.DictReader((ROOT/'reference_l1_seed0.csv').open()))
for x in raw:
    r=next(y for y in refs if y['method']==x['method'] and y['replicate']==x['replicate'])
    assert math.isclose(float(x['objective']),float(r['objective']),abs_tol=1e-7,rel_tol=1e-12),(x,r)
print('PASS Stage 3: four methods x two runs, 528 fitness evaluations each, valid decoded schedules, objective-value match',flush=True)
S5=ROOT/'stage5'/'OPSEARCH_Stage5'
run('code/selftest_portable.py',cwd=S5)
S6=ROOT/'stage6'/'OPSEARCH_Stage6'
run('code/audit_exact_3600.py',cwd=S6)
print('COLD REPLAY PASSED: representative Stage3/Stage5, ten archived NEW MILP schedules, no original workspace paths',flush=True)
