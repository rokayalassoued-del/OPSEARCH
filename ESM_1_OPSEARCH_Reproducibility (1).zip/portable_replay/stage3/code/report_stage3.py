#!/usr/bin/env python3
"""Post-process OPSEARCH Stage 3 archived results; no reruns and no changes to raw data."""
import csv,json,hashlib,math,platform,statistics
from pathlib import Path
from collections import defaultdict
import numpy as np
from scipy.stats import ttest_ind
ROOT=Path(__file__).resolve().parent.parent
O=ROOT/'results'
with (O/'all_runs.csv').open(newline='') as f:runs=list(csv.DictReader(f))
with (O/'method_summary.csv').open(newline='') as f:summary=list(csv.DictReader(f))
by=defaultdict(list)
for r in runs:
    by[(r['instance'],r['method'])].append(float(r['objective']))
assert len(runs)==16*4*30 and all(r['feasible']=='True' and r['objective_evaluations']=='528' for r in runs)
assert len(set((r['instance'],r['method'],r['replicate']) for r in runs))==len(runs)
methods=['PSO','GA','SA','MSLS']
large=[f'L{i}' for i in range(1,7)]
comparisons=[]
# Nonparametric independent-sample permutation tests, fixed seed for reproducibility.
# Two-sided using absolute difference in sample means; 20000 permutations per comparison.
rng=np.random.default_rng(20261031)
for name in large:
    pso=np.array(by[(name,'PSO')]); meanp=pso.mean()
    for method in methods[1:]:
        comp=np.array(by[(name,method)]); meancomp=comp.mean(); obs=meancomp-meanp
        pooled=np.concatenate((pso,comp));count=0; R=20000
        for _ in range(R):
            ix=rng.permutation(60)
            perm=pooled[ix[30:]].mean()-pooled[ix[:30]].mean()
            count+=abs(perm)>=abs(obs)-1e-10
        pperm=(count+1)/(R+1)
        # Independent bootstrap 95% percentile CI for difference of means
        # positive difference means PSO is better, as we minimize.
        boot=[]
        for _ in range(10000):
            boot.append(float(comp[rng.integers(30,size=30)].mean()-pso[rng.integers(30,size=30)].mean()))
        lo,hi=np.percentile(boot,[2.5,97.5])
        comparisons.append(dict(instance=name,comparison='PSO vs '+method,PSO_mean=meanp,competitor_mean=meancomp,PSO_best=pso.min(),competitor_best=comp.min(),mean_difference_comp_minus_PSO=obs,mean_relative_advantage_pct=100*obs/meancomp,bootstrap_CI95_lower=lo,bootstrap_CI95_upper=hi,permutation_p_two_sided=pperm))
# Holm familywise adjustment across 18 comparisons; monotone
ix=sorted(range(len(comparisons)), key=lambda i:comparisons[i]['permutation_p_two_sided'])
last=0.0
for rank,i in enumerate(ix):
    adj=min(1.0,(len(ix)-rank)*comparisons[i]['permutation_p_two_sided'])
    last=max(last,adj)
    comparisons[i]['holm_adjusted_p_18_tests']=last
    comparisons[i]['significant_at_005_Holm']=last < .05
with (O/'large_comparison_inference.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(comparisons[0]));w.writeheader();w.writerows(comparisons)
# Overall summary with no aggregating raw scores across differing-scale instances
wins=[]
for name in large:
    means={m:statistics.mean(by[(name,m)]) for m in methods}
    bests={m:min(by[(name,m)]) for m in methods}
    wins.append(dict(instance=name, PSO_mean=means['PSO'], GA_mean=means['GA'],SA_mean=means['SA'],MSLS_mean=means['MSLS'],PSO_best=bests['PSO'],GA_best=bests['GA'],SA_best=bests['SA'],MSLS_best=bests['MSLS'],mean_winner=min(means,key=means.get),best_winner=min(bests,key=bests.get),PSO_vs_GA_mean_advantage_pct=(means['GA']-means['PSO'])/means['GA']*100))
with (O/'large_instance_descriptive.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(wins[0]));w.writeheader();w.writerows(wins)
# count optimal hits for the 8 MILP certified cases from previous exact table
hit=[]
for name in [f'S{i}' for i in range(1,7)]+['M1','M2']:
    for m in methods:
        x=next(s for s in summary if s['instance']==name and s['method']==m)
        hit.append(dict(instance=name,method=m,optimal_hits=int(x['optimal_hits']),runs=30,best=float(x['best']),mean=float(x['mean']),sd=float(x['sample_std'])))
with (O/'eight_exact_optimal_hit_rates.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(hit[0]));w.writeheader();w.writerows(hit)
# document limitations plainly
stat_signif=[(x['instance'],x['comparison'],round(float(x['holm_adjusted_p_18_tests']),4)) for x in comparisons if x['significant_at_005_Holm']]
report=f'''# OPSEARCH Stage 3 technical comparison (working, not manuscript text)

Date: 2026-10-31. All reported scores minimize total vessel turnaround time, sum_j(c_j-a_j).

## Execution and validation

- 16 instances: S1–S6 and M1–M4 are **newly generated** validation data (original 2019 manuscript-level data unavailable); L1–L6 are deterministically regenerated from the **archived original generator**.
- 4 algorithms: archived PSO trajectory, independently programmed GA, SA, and MSLS.
- 30 independent runs/method/instance, exactly **528 objective evaluations per run**.
- **1920/1920 schedules passed** independent feasibility and objective-value checks.
- Comparison holds the decoder and number of evaluations constant, but does **not** match wall-clock time; methods' parameters are illustrative and are **not** asserted to be optimally tuned or literature-leading implementations.
- 3600-second exact MILP experiments are separate; M3/M4 should be treated as pending until completed result files are present.

## Recovered large instances: sample mean and best of 30 (smaller is better)

| Case | PSO mean | GA mean | SA mean | MSLS mean | PSO best | GA best | Mean winner |
|---|---:|---:|---:|---:|---:|---:|---|
'''
for x in wins:
    report+=f"| {x['instance']} | {x['PSO_mean']:,.2f} | {x['GA_mean']:,.2f} | {x['SA_mean']:,.2f} | {x['MSLS_mean']:,.2f} | {x['PSO_best']:,.2f} | {x['GA_best']:,.2f} | {x['mean_winner']} |\n"
report+='''
PSO has the lowest sample mean on all six large datasets. The lowest **single-run** objective for L2 belongs to GA; it would be misleading to claim that PSO wins every run. The outcomes are dependent on the fixed generator, implementation and evaluation budget. These 6 archived seeds are not a broad independent distribution of operational instances.

## Statistical analysis

- Two-sided **independent-sample permutation tests** on mean differences, 20,000 permutations, comparing PSO with each alternative separately on each of L1–L6 (18 tests). Holm adjustment across the 18 comparisons.
- 10,000 independent within-method bootstrap draws for a descriptive 95% CI on competitor mean minus PSO mean. Positive means PSO better.
- Holm-significant comparisons (0.05): '''+str(stat_signif)+'''.\n
This analysis is preliminary for model validation. It does not establish dominance over the general class of genetic algorithms or simulated annealing: stronger tuned implementations, more instance replications, and time-matched experiments are needed before a general comparative claim.

## Exact-small cases

The newly generated S1–S6, M1–M2 cases have independently certified MILP optima; all four tested heuristics attain the optimum at least once on each of these eight problems. Their hit rate and stability differ (see `eight_exact_optimal_hit_rates.csv`). This suggests that most of the new small cases are not sufficiently discriminating to prove one heuristic is superior.

## Data provenance and reproducibility

- `all_runs.csv`: 1,920 disaggregated runs and unique seeds, every schedule feasible.
- `method_summary.csv`: per-instance and per-method best/mean/standard deviation and runtimes.
- `best_schedules.jsonl`: best schedule for each instance and method.
- `large_comparison_inference.csv`: complete inferential tests and unadjusted/adjusted p-values.
- `large_instance_descriptive.csv`: comparison table for L1–L6.
- `eight_exact_optimal_hit_rates.csv`: count of optimal hits by method.
- `code/compare_heuristics.py`: algorithm implementations and independent validator.

## Remaining research tasks (before manuscript/reviewer response)

1. Collect final M3/M4 HiGHS results for the 3600-s exact runs when completed; do not assume optimality if time-limited.
2. Run separate congestion-level and scale replications with independent seeds; generator labels are not a substitute for experimentally varied congestion.
3. Compare algorithms under a wall-clock budget or evaluate best-so-far vs time curves; equal objective evaluations alone are insufficient for strong fairness.
4. Confirm no hidden issue in the recovered legacy decoder, and test parameter sensitivity (PSO swarm, iterations, local search, GA, SA).
5. Decide and document how the new exact instances relate to the archival manuscript results. Keep provenance explicit.

Original manuscript and reviewer correspondence were not edited.
'''
(O/'STAGE3_TECHNICAL_REPORT.md').write_text(report)
meta={'analysis_date':'2026-10-31','n_validated_runs':len(runs),'n_instances':16,'methods':methods,'evaluations_per_run':528,'n_per_method_instance':30,'permutation_seed':20261031,'permutation_trials':20000,'bootstrap_draws':10000,'scipy_version':__import__('scipy').__version__,'significant_comparisons_holm':stat_signif}
(O/'inference_metadata.json').write_text(json.dumps(meta,indent=2))
print(report[:2800]);print('SIGNIFICANT:',stat_signif)
