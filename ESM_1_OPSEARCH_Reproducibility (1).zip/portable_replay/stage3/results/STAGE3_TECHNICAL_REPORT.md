# OPSEARCH Stage 3 technical comparison (working, not manuscript text)

Date: 2026-10-31. All reported scores minimize total vessel turnaround time, sum_j(c_j-a_j).

## Execution and validation

- 16 instances: S1–S6 and M1–M4 are **newly generated** validation data (original 2019 manuscript-level data unavailable); L1–L6 are deterministically regenerated from the **archived original generator**.
- 4 algorithms: archived PSO trajectory, independently programmed GA, SA, and MSLS.
- 30 independent runs/method/instance, exactly **528 objective evaluations per run**.
- **1920/1920 schedules passed** independent feasibility and objective-value checks.
- Comparison holds the decoder and number of evaluations constant, but does **not** match wall-clock time; methods' parameters are illustrative and are **not** asserted to be optimally tuned or literature-leading implementations.
- 3600-second exact MILP experiments are separate; M3/M4 should be treated as pending until completed result files are present.

## Recovered large instances: sample mean and best of 30 (smaller is better)

| Case | PSO mean | GA mean | SA mean | MSLS mean | PSO best | GA best | Mean winner |
|---|---:|---:|---:|---:|---:|---:|---|
| L1 | 10,708.46 | 10,941.38 | 11,042.88 | 11,320.48 | 10,337.43 | 10,575.59 | PSO |
| L2 | 14,878.86 | 15,019.56 | 15,298.42 | 15,863.56 | 14,121.20 | 13,933.15 | PSO |
| L3 | 19,376.86 | 19,530.10 | 19,843.66 | 20,981.72 | 17,857.53 | 18,433.05 | PSO |
| L4 | 22,196.58 | 22,750.04 | 23,254.65 | 24,472.77 | 20,356.52 | 21,206.51 | PSO |
| L5 | 29,182.18 | 29,706.87 | 30,679.49 | 32,258.30 | 27,117.54 | 28,203.06 | PSO |
| L6 | 36,401.55 | 37,188.44 | 38,746.49 | 40,983.84 | 34,083.04 | 34,465.14 | PSO |

PSO has the lowest sample mean on all six large datasets. The lowest **single-run** objective for L2 belongs to GA; it would be misleading to claim that PSO wins every run. The outcomes are dependent on the fixed generator, implementation and evaluation budget. These 6 archived seeds are not a broad independent distribution of operational instances.

## Statistical analysis

- Two-sided **independent-sample permutation tests** on mean differences, 20,000 permutations, comparing PSO with each alternative separately on each of L1–L6 (18 tests). Holm adjustment across the 18 comparisons.
- 10,000 independent within-method bootstrap draws for a descriptive 95% CI on competitor mean minus PSO mean. Positive means PSO better.
- Holm-significant comparisons (0.05): [('L1', 'PSO vs GA', 0.0035), ('L1', 'PSO vs SA', 0.0009), ('L1', 'PSO vs MSLS', 0.0009), ('L2', 'PSO vs SA', 0.002), ('L2', 'PSO vs MSLS', 0.0009), ('L3', 'PSO vs SA', 0.0342), ('L3', 'PSO vs MSLS', 0.0009), ('L4', 'PSO vs GA', 0.04), ('L4', 'PSO vs SA', 0.0009), ('L4', 'PSO vs MSLS', 0.0009), ('L5', 'PSO vs SA', 0.0009), ('L5', 'PSO vs MSLS', 0.0009), ('L6', 'PSO vs SA', 0.0009), ('L6', 'PSO vs MSLS', 0.0009)].

This analysis is preliminary for model validation. It does not establish dominance over the general class of genetic algorithms or simulated annealing: stronger tuned implementations, more instance replications, and time-matched experiments are needed before a general comparative claim.

## Exact-small cases

The newly generated S1–S6, M1–M2 cases have independently certified MILP optima; all four tested heuristics attain the optimum at least once on each of these eight problems. Their hit rate and stability differ (see `eight_exact_optimal_hit_rates.csv`). This suggests that most of the new small cases are not sufficiently discriminating to prove one heuristic is superior.

## Data provenance and reproducibility

- `all_runs.csv`: 1,920 disaggregated runs and unique seeds, every schedule feasible.
- `method_summary.csv`: per-instance and per-method best/mean/standard deviation and runtimes.
- `best_schedules.jsonl`: best schedule for each instance and method.
- `large_comparison_inference.csv`: complete inferential tests and unadjusted/adjusted p-values.
- `large_instance_descriptive.csv`: comparison table for L1–L6.
- `eight_exact_optimal_hit_rates.csv`: count of optimal hits by method.
- `code/compare_heuristics.py`: algorithm implementations and independent validator.

## Remaining research tasks (before manuscript/reviewer response)

1. Collect final M3/M4 HiGHS results for the 3600-s exact runs when completed; do not assume optimality if time-limited.
2. Run separate congestion-level and scale replications with independent seeds; generator labels are not a substitute for experimentally varied congestion.
3. Compare algorithms under a wall-clock budget or evaluate best-so-far vs time curves; equal objective evaluations alone are insufficient for strong fairness.
4. Confirm no hidden issue in the recovered legacy decoder, and test parameter sensitivity (PSO swarm, iterations, local search, GA, SA).
5. Decide and document how the new exact instances relate to the archival manuscript results. Keep provenance explicit.

Original manuscript and reviewer correspondence were not edited.
