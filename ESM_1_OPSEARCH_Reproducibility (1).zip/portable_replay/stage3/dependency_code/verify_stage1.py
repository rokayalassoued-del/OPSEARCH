"""Independent small-case optimality verification; does not edit a manuscript."""
from __future__ import annotations
import csv, itertools, random, math, pathlib
from canonical_exact_milp import Instance,solve,evaluate_schedule
OUT=pathlib.Path(__file__).resolve().parent

def enumerate_optimal(inst,deadline=None):
    best=math.inf
    keys=[list(row) for row in inst.p]
    for assignment in itertools.product(*keys):
        groups={i:tuple(j for j,k in enumerate(assignment) if k==i) for i in inst.berths}
        for ordering in itertools.product(*(itertools.permutations(groups[i]) for i in inst.berths)):
            total=0.0;maxc=0
            for i,seq in zip(inst.berths,ordering):
                avail=0
                for j in seq:
                    finish=max(avail,inst.arrivals[j])+inst.p[j][i]
                    if deadline is not None and finish>deadline+1e-8:
                        total=math.inf;break
                    avail=finish;maxc=max(maxc,finish);total+=finish-inst.arrivals[j]
                if not math.isfinite(total):break
            best=min(best,total)
    return best

def main():
    cases=[Instance((0,3,1),({1:2},{1:3},{1:1}),'one_berth'),
           Instance((0,1,3),({1:2,2:4},{1:4,2:2},{1:3,2:3}),'two_berth'),
           Instance((0,0),({1:3},{1:4}),'deadline_infeasible')]
    rng=random.Random(311026)
    for q in range(16):
        n=rng.choice([3,4]);m=rng.choice([2,3]);P=[]
        for j in range(n):
            row={i:rng.randint(1,5) for i in range(1,m+1) if rng.random()<.70}
            if not row:row[rng.randint(1,m)]=rng.randint(1,5)
            P.append(row)
        cases.append(Instance(tuple(rng.randint(0,4) for j in range(n)),tuple(P),f'random_{q:02d}'))
    logs=[]
    for inst in cases:
        for deadline in [None, max(5,int(inst.U*.62))]:
            brute=enumerate_optimal(inst,deadline)
            model=solve(inst,hard_completion_deadline=deadline,time_limit=15)
            model_obj=model['objective']
            matches=(math.isinf(brute) and model['status']==2) or (math.isfinite(brute) and model['status']==0 and abs(model_obj-brute)<1e-6)
            feas=None
            if model.get('schedule'):
                feas=evaluate_schedule(inst,model['schedule'])
                matches=matches and feas['ok'] and feas['within_U']
                if deadline is not None:matches=matches and feas['max_completion']<=deadline+1e-6
            logs.append(dict(instance=inst.name,n=inst.n,berths=len(inst.berths),deadline='none' if deadline is None else deadline,
                             bound=model['bound_U'],bruteforce='INFEASIBLE' if not math.isfinite(brute) else round(brute,7),
                             milp_status=model['status'],milp_obj=model_obj,checked=matches,
                             n_vars=model['n_vars'],n_constraints=model['n_constraints']))
            if not matches:print('FAIL',logs[-1])
    with open(OUT/'verified_microcases.csv','w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(logs[0]));w.writeheader();w.writerows(logs)
    print('microcase independent comparisons:',sum(v['checked'] for v in logs),'/',len(logs))
    assert all(v['checked'] for v in logs)
if __name__=='__main__':main()
