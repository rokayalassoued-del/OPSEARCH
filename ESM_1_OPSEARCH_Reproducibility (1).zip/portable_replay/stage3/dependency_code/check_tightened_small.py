from run_benchmark import inputs
from tightened_exact_milp import solve_tight
from canonical_exact_milp import solve
for k in ['S1','S2','S3','S4']:
    _,inst,_,_=inputs(k)
    orig=solve(inst,time_limit=15)
    new=solve_tight(inst,time_limit=15)
    assert orig['status']==new['status']==0
    assert abs(orig['objective']-new['objective'])<1e-5
    print(k,orig['objective'],new['objective'])
