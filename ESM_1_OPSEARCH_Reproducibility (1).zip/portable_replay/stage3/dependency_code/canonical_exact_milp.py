"""Independent verification implementation for OPSEARCH BAP (research audit).

This is NEW verification code, not the recovered historical HiGHS source.
No original submission or historic data are altered.

Model: nonpreemptive dynamic discrete berth allocation, each vessel assigned to
exactly one compatible berth; arrivals and processing durations observed.
No external completion deadline by default. U is an optimum-preserving bound.
Optional hard_completion_deadline allows auditing the submitted hard-horizon model.
"""
from __future__ import annotations
from dataclasses import dataclass
from itertools import combinations
from math import inf
from typing import Mapping, Sequence
import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint
from scipy.sparse import coo_matrix

@dataclass(frozen=True)
class Instance:
    arrivals: tuple[float, ...]
    p: tuple[dict[int,float], ...]  # vessel -> berth -> processing hours (only compatible pairs)
    name: str = 'audit_case'

    def __post_init__(self):
        if not self.arrivals or len(self.arrivals)!=len(self.p):
            raise ValueError('Number of vessel arrivals and processing-time dictionaries must match')
        for j,(a,row) in enumerate(zip(self.arrivals,self.p)):
            if a < 0 or not row or not all(q>0 for q in row.values()):
                raise ValueError(f'Invalid arrival/feasibility/processing time for vessel {j}')

    @property
    def n(self): return len(self.arrivals)
    @property
    def berths(self): return tuple(sorted(set().union(*(set(x.keys()) for x in self.p))))

    @property
    def U(self):
        amax=max(self.arrivals)
        return amax+max(sum(row.get(i,0) for row in self.p) for i in self.berths)

    @property
    def rho_nominal(self):
        # no automatic interpretation of this ratio as a feasibility guarantee
        return sum(min(row.values()) for row in self.p)


def solve(inst: Instance, hard_completion_deadline: float | None=None,
          time_limit: float=20.0, mip_rel_gap: float=1e-9, M_override: float | None=None):
    U=inst.U if hard_completion_deadline is None else float(hard_completion_deadline)
    M=U if M_override is None else M_override
    n=inst.n
    x=[(j,i) for j,row in enumerate(inst.p) for i in sorted(row)]
    y=[(i,j,k) for j,k in combinations(range(n),2) if (common := set(inst.p[j]).intersection(inst.p[k])) for i in sorted(common)]
    ix={pair:idx for idx,pair in enumerate(x)}
    iy={key:len(x)+2*n+idx for idx,key in enumerate(y)}
    is_={j:len(x)+j for j in range(n)}
    ic={j:len(x)+n+j for j in range(n)}
    nv=len(x)+2*n+len(y)
    rows=[];lower=[];upper=[]
    def add(terms,lb=-inf,ub=inf):
        rows.append(terms);lower.append(lb);upper.append(ub)
    for j in range(n):
        add({ix[(j,i)]:1 for i in inst.p[j]},lb=1,ub=1)
        add({ic[j]:1,is_[j]:-1,**{ix[(j,i)]:-p for i,p in inst.p[j].items()}},lb=0,ub=0)
    for i,j,k in y:
        yy=iy[(i,j,k)]; xx=ix[(j,i)]; xk=ix[(k,i)]
        add({yy:1,xx:-1},ub=0)
        add({yy:1,xk:-1},ub=0)
        add({is_[k]:1,ic[j]:-1,yy:-M,xx:-M,xk:-M},lb=-3*M)
        add({is_[j]:1,ic[k]:-1,yy:M,xx:-M,xk:-M},lb=-2*M)
    rr=[];cc=[];vv=[]
    for rid,terms in enumerate(rows):
        for idx,val in terms.items():
            rr.append(rid);cc.append(idx);vv.append(float(val))
    mat=coo_matrix((vv,(rr,cc)),shape=(len(rows),nv)).tocsr()
    lo=np.zeros(nv); hi=np.full(nv,inf); integrality=np.zeros(nv,dtype=int)
    for j,i in x:
        hi[ix[(j,i)]]=1; integrality[ix[(j,i)]]=1
    for key in y:
        hi[iy[key]]=1; integrality[iy[key]]=1
    for j in range(n):
        lo[is_[j]]=inst.arrivals[j]
        hi[is_[j]]=U
        hi[ic[j]]=U
    obj=np.zeros(nv)
    for j in range(n):obj[ic[j]]=1
    res=milp(obj, integrality=integrality, bounds=Bounds(lo,hi),
             constraints=LinearConstraint(mat,lower,upper),
             options={'time_limit':time_limit,'mip_rel_gap':mip_rel_gap})
    output=dict(name=inst.name,status=int(res.status),message=res.message,
                bound_U=U,big_M=M,n_vars=nv,n_binary=len(x)+len(y),n_constraints=len(rows),
                objective=None if res.fun is None else float(res.fun-sum(inst.arrivals)),
                lower_bound=None if getattr(res,'mip_dual_bound',None) is None else float(res.mip_dual_bound-sum(inst.arrivals)),
                gap=getattr(res,'mip_gap',None))
    if res.x is not None:
        assignments=[]
        for j in range(n):
            berth=next(i for i in inst.p[j] if res.x[ix[(j,i)]]>0.5)
            assignments.append({'vessel':j,'berth':berth,'arrival':inst.arrivals[j],
                                'start':float(res.x[is_[j]]),'finish':float(res.x[ic[j]]),
                                'duration':inst.p[j][berth]})
        output['schedule']=assignments
    return output


def evaluate_schedule(inst:Instance, assignments:Sequence[Mapping], eps=1e-5):
    if len(assignments)!=inst.n:return {'ok':False,'reason':'wrong number of vessel assignments'}
    seen=set();by_berth={};total=0.;maximum=0.
    for r in assignments:
        j=int(r['vessel']);i=int(r['berth']);s=float(r['start']);c=float(r['finish'])
        if j in seen or j<0 or j>=inst.n:return {'ok':False,'reason':'duplicate/invalid vessel'}
        seen.add(j)
        if i not in inst.p[j]:return {'ok':False,'reason':'incompatible berth'}
        if s+eps<inst.arrivals[j]:return {'ok':False,'reason':'before arrival'}
        if abs(c-s-inst.p[j][i])>eps:return {'ok':False,'reason':'incorrect processing duration'}
        by_berth.setdefault(i,[]).append((s,c,j))
        total+=c-inst.arrivals[j];maximum=max(maximum,c)
    for i,work in by_berth.items():
        work.sort()
        for first,second in zip(work,work[1:]):
            if first[1]>second[0]+eps:return {'ok':False,'reason':f'berth {i} overlaps vessels {first[2]} and {second[2]}'}
    return {'ok':True,'objective':total,'max_completion':maximum,'within_U':maximum<=inst.U+eps}
