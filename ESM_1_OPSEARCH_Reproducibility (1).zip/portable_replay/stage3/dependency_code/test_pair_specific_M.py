"""Check per-vessel completion bounds / pair M using independent brute force."""
import sys,random,math,csv
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from verify_stage1 import enumerate_optimal
from canonical_exact_milp import Instance
from tightened_exact_milp import solve_tight
rng=random.Random(311026)
cases=[Instance((0,3,1),({1:2},{1:3},{1:1}),'one_berth'),Instance((0,1,3),({1:2,2:4},{1:4,2:2},{1:3,2:3}),'two_berth')]
for q in range(20):
    n=rng.choice([3,4]);m=rng.choice([2,3]);P=[]
    for j in range(n):
        row={i:rng.randint(1,5) for i in range(1,m+1) if rng.random()<.70}
        if not row:row[rng.randint(1,m)]=rng.randint(1,5)
        P.append(row)
    cases.append(Instance(tuple(rng.randint(0,4) for _ in range(n)),tuple(P),f'random_{q:02d}'))
rows=[]
for instance in cases:
    brute=enumerate_optimal(instance)
    sol=solve_tight(instance,time_limit=15)
    passed=sol['status']==0 and abs(sol['objective']-brute)<1e-6
    rows.append(dict(case=instance.name,n=instance.n,brute=brute,exact=sol['objective'],status=sol['status'],passed=passed))
    assert passed,(instance.name,brute,sol)
with (HERE.parent/'outputs'/'pair_M_exhaustive_verification.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
print(f'Pairwise M + Uj validated against exhaustive enumeration: {sum(r["passed"] for r in rows)}/{len(rows)}',flush=True)
