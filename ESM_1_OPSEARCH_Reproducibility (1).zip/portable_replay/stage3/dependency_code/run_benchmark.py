"""Stage-2 NEW validation: archived PSO rerun + independently modelled exact MILP.
Original OPSEARCH submission/legacy datasets unchanged. Scope: ten newly generated
small/medium cases, not a claim of reproducing archived S1--M4.
"""
from __future__ import annotations
import os,sys,math,csv,json,time,random,hashlib,platform,argparse,statistics
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(HERE))
import synthetic_pso_experiments as legacy
from canonical_exact_milp import Instance,solve,evaluate_schedule
import numpy,scipy


def inputs(name):
    path=ROOT/'data_new'/f'{name}.json'; o=json.loads(path.read_text())
    c=Instance(tuple(v['arrival'] for v in o['vessels']),tuple({int(i):float(t) for i,t in v['p_by_berth'].items()} for v in o['vessels']), name)
    lg=dict(n=len(o['vessels']),A=[v['arrival'] for v in o['vessels']],feas=[tuple(v['feasible_berths']) for v in o['vessels']],P=[{int(i):float(t) for i,t in v['p_by_berth'].items()} for v in o['vessels']],H=o['H_nominal'],seed=o['seed'])
    return o,c,lg,hashlib.sha256(path.read_bytes()).hexdigest()

def decode_to_schedule(inst, keys):
    _,sequence=legacy.decode_keys(inst,keys)
    av={i:0.0 for poss in inst['feas'] for i in poss}
    assignments=[]
    for j in sequence:
        candidates=[(max(inst['A'][j],av[i])+inst['P'][j][i],i) for i in inst['feas'][j]]
        finish,i=min(candidates)
        start=max(inst['A'][j],av[i]);av[i]=finish
        assignments.append(dict(vessel=j,berth=i,arrival=inst['A'][j],start=start,finish=finish,duration=inst['P'][j][i]))
    return assignments

def pso_with_keys(inst,runs=30):
    n=inst['n'];out=[]
    for run in range(runs):
        rnd=random.Random(100000+inst['seed']*100+run)
        X=[[rnd.random() for _ in range(n)] for _ in range(10)]
        V=[[rnd.uniform(-1,1) for _ in range(n)] for _ in range(10)]
        pb=[x[:] for x in X]
        scores=[legacy.decode_keys(inst,x)[0] for x in X]
        idx=min(range(10),key=lambda p:scores[p]); gbest=pb[idx][:]; gscore=scores[idx]
        for it in range(45):
            w=.9-.5*it/44
            for k in range(10):
                xp,vp,pk=X[k],V[k],pb[k]
                for j in range(n):
                    v=w*vp[j]+1.7*rnd.random()*(pk[j]-xp[j])+2.0*rnd.random()*(gbest[j]-xp[j])
                    v=max(-4.0,min(4.0,v))
                    vp[j]=v;xp[j]+=v
                objective,_=legacy.decode_keys(inst,xp)
                if objective<scores[k]:
                    scores[k]=objective;pb[k]=xp[:]
                    if objective<gscore:
                        gscore=objective;gbest=xp[:]
            if it%10==9:
                _,seq=legacy.decode_keys(inst,gbest)
                lscore,lseq=legacy.local_search(inst,seq,max_trials=15,rnd=rnd)
                if lscore<gscore:
                    gscore=lscore;gbest=legacy.seq_to_keys(lseq)
        schedule=decode_to_schedule(inst,gbest)
        out.append(dict(run=run,seed=100000+inst['seed']*100+run,objective=gscore,schedule=schedule))
    return out

def main(names,max_time,runs):
    # Retain previously verified cases when running in batches.
    summary_path=ROOT/'outputs'/'exact_vs_PSO_summary.csv'
    raw_path=ROOT/'outputs'/'all_pso_runs.csv'
    detail_path=ROOT/'outputs'/'schedule_validation.jsonl'
    exclude=set(names)
    summary=[row for row in csv.DictReader(summary_path.open()) if row['instance'] not in exclude] if summary_path.exists() else []
    raw=[row for row in csv.DictReader(raw_path.open()) if row['instance'] not in exclude] if raw_path.exists() else []
    details=[json.loads(line) for line in detail_path.read_text().splitlines() if json.loads(line)['instance'] not in exclude] if detail_path.exists() else []
    for name in names:
        o,inst,lg,sha=inputs(name)
        t0=time.perf_counter()
        exact=solve(inst,time_limit=max_time,mip_rel_gap=1e-8)
        elapsed=time.perf_counter()-t0
        schedule_ok=None
        if exact.get('schedule'):
            v=evaluate_schedule(inst,exact['schedule']);schedule_ok=v['ok']
            if not v['ok']:raise RuntimeError(f'MILP schedule invalid {name}: {v}')
            assert abs(v['objective']-exact['objective'])<1e-4
        fcfs_keys=lg['A'];fcfs=legacy.decode_keys(lg,fcfs_keys)[0]
        fcfs_check=evaluate_schedule(inst,decode_to_schedule(lg,fcfs_keys))
        assert fcfs_check['ok'] and abs(fcfs_check['objective']-fcfs)<1e-6
        psos=pso_with_keys(lg,runs=runs)
        original=legacy.pso(lg,runs=runs)
        assert len(psos)==len(original)
        for r,(pr,old) in enumerate(zip(psos,original)):
            assert abs(pr['objective']-old[0])<1e-7, (name,r,pr['objective'],old[0])
            validity=evaluate_schedule(inst,pr['schedule'])
            assert validity['ok'] and validity['within_U'] and abs(validity['objective']-pr['objective'])<1e-6
            raw.append(dict(instance=name,run=r,seed=pr['seed'],objective=pr['objective'],valid=True,max_completion=validity['max_completion'],opt_bound_U=inst.U))
        values=[r['objective'] for r in psos]
        best=min(values);avg=statistics.mean(values);std=statistics.stdev(values) if len(values)>1 else 0
        if exact['status']==0:
            assert all(v>=exact['objective']-1e-4 for v in values),('Heuristic better than optimum',name,exact['objective'],best)
        r=dict(instance=name,origin='NEW_VALIDATION',n_vessels=inst.n,n_berths=o['n_berths'],seed=o['seed'],nominal_H=o['H_nominal'],rho=o['nominal_workload_ratio'],U=inst.U,
            exact_status=exact['status'],exact_objective=exact.get('objective'),exact_lower_bound=exact.get('lower_bound'),exact_mip_gap=exact.get('gap'),exact_seconds=elapsed,exact_schedule_verified=schedule_ok,
            fcfs_earliest_completion=fcfs,pso_runs=runs,pso_best=best,pso_mean=avg,pso_sample_std=std,
            best_pso_gap_to_proven_opt_pct=((best/exact['objective']-1)*100 if exact['status']==0 and exact['objective'] and exact['objective']>0 else None),
            best_pso_improvement_vs_fcfs_pct=(fcfs-best)/fcfs*100,input_sha256=sha)
        summary.append(r)
        details.append(dict(instance=name,milp=exact,fcfs_schedule=decode_to_schedule(lg,fcfs_keys),best_pso=min(psos,key=lambda p:p['objective'])))
        print(f"{name} status={exact['status']} exact={exact.get('objective')} bestPSO={best:.3f} FCFS={fcfs:.3f} time={elapsed:.2f}s",flush=True)
        write_summary(summary,raw,details)
    (ROOT/'outputs'/'run_environment.json').write_text(json.dumps(dict(python=platform.python_version(),numpy=numpy.__version__,scipy=scipy.__version__,platform=platform.platform(),processor=platform.processor(),
              original_script_sha256=hashlib.sha256(Path(legacy.__file__).read_bytes()).hexdigest(),independent_milp_sha256=hashlib.sha256(Path(sys.modules['canonical_exact_milp'].__file__).read_bytes()).hexdigest(),mode='NEW_VALIDATION'),indent=2))
    print('COMPLETE',flush=True)

def write_summary(summary,raw,details):
    def csv_out(path,rows):
        if not rows:return
        with path.open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0].keys()));w.writeheader();w.writerows(rows)
    csv_out(ROOT/'outputs'/'exact_vs_PSO_summary.csv',summary)
    csv_out(ROOT/'outputs'/'all_pso_runs.csv',raw)
    with (ROOT/'outputs'/'schedule_validation.jsonl').open('w') as f:
        for item in details:f.write(json.dumps(item)+'\n')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--time-limit',type=float,default=15);ap.add_argument('--runs',type=int,default=30);ap.add_argument('--names',nargs='*',default=[f'S{i}' for i in range(1,7)]+[f'M{i}' for i in range(1,5)])
    a=ap.parse_args();main(a.names,a.time_limit,a.runs)
