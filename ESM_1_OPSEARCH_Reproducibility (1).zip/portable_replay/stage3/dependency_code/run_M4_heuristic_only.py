"""Recover 30 reproducible PSO runs for M4 without claiming an exact MILP result."""
import sys,csv,json,hashlib,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'code'))
import run_benchmark as bench
from canonical_exact_milp import evaluate_schedule
name='M4';data,inst,lg,sha=bench.inputs(name)
psos=bench.pso_with_keys(lg,runs=30)
original=bench.legacy.pso(lg,runs=30)
raw=[]
for r,(p,o) in enumerate(zip(psos,original)):
    assert abs(p['objective']-o[0])<1e-7
    v=evaluate_schedule(inst,p['schedule']);assert v['ok'] and v['within_U']
    raw.append(dict(instance=name,run=r,seed=p['seed'],objective=p['objective'],valid=True,max_completion=v['max_completion'],opt_bound_U=inst.U))
fcfs=bench.legacy.decode_keys(lg,lg['A'])[0]
vals=[x['objective'] for x in psos];best=min(vals)
rec=dict(instance=name,origin='NEW_VALIDATION',n_vessels=inst.n,n_berths=data['n_berths'],seed=data['seed'],nominal_H=data['H_nominal'],rho=data['nominal_workload_ratio'],U=inst.U,
         exact_status='NOT_CERTIFIED',exact_objective='',exact_lower_bound='',exact_mip_gap='',exact_seconds='',exact_schedule_verified='',
         fcfs_earliest_completion=fcfs,pso_runs=30,pso_best=best,pso_mean=statistics.mean(vals),pso_sample_std=statistics.stdev(vals),
         best_pso_gap_to_proven_opt_pct='',best_pso_improvement_vs_fcfs_pct=(fcfs-best)/fcfs*100,input_sha256=sha)
existing=list(csv.DictReader((ROOT/'outputs'/'exact_vs_PSO_summary.csv').open()))
summary=[r for r in existing if r['instance']!=name]+[rec]
other=list(csv.DictReader((ROOT/'outputs'/'all_pso_runs.csv').open()))
rows=[r for r in other if r['instance']!=name]+raw
with (ROOT/'outputs'/'exact_vs_PSO_summary.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=summary[0].keys());w.writeheader();w.writerows(summary)
with (ROOT/'outputs'/'all_pso_runs.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
with (ROOT/'outputs'/'schedule_validation.jsonl').open('a') as f:
    f.write(json.dumps(dict(instance=name,milp=dict(status='NOT_CERTIFIED'),fcfs_schedule=bench.decode_to_schedule(lg,lg['A']),best_pso=min(psos,key=lambda p:p['objective'])))+'\n')
print(f'M4 no exact proof, PSO best={best:.6f}; FCFS={fcfs:.6f}; all 30 runs reproduced and feasible')
