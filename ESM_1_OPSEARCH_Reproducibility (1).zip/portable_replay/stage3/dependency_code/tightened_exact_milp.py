"""NEW strengthened MILP with job-specific completion ceilings and pairwise big-M.
For the no-hard-deadline problem, a left-shifted optimal schedule exists with
c_j <= U_j = max_k a_k + max_{i in B_j} sum_{k: i in B_k} p_ik.
Pairwise disjunctive relaxations use M_{j->k}=U_j-a_k and reverse counterpart.
This is a computational strengthening, not the original submitted formulation.
"""
from __future__ import annotations
from itertools import combinations
from math import inf
import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint
from scipy.sparse import coo_matrix
from canonical_exact_milp import Instance, evaluate_schedule

def solve_tight(inst:Instance,time_limit:float=20.0,mip_rel_gap:float=1e-8):
    n=inst.n; a=inst.arrivals
    max_a=max(a)
    bset=inst.berths
    berth_work={i:sum(row.get(i,0.0) for row in inst.p) for i in bset}
    Uj=[max_a+max(berth_work[i] for i in row) for row in inst.p]
    x=[(j,i) for j,row in enumerate(inst.p) for i in sorted(row)]
    y=[(i,j,k) for j,k in combinations(range(n),2) for i in sorted(set(inst.p[j]).intersection(inst.p[k]))]
    ix={v:idx for idx,v in enumerate(x)}
    is_={j:len(x)+j for j in range(n)}
    ic={j:len(x)+n+j for j in range(n)}
    iy={t:len(x)+2*n+k for k,t in enumerate(y)}
    nv=len(x)+2*n+len(y)
    rows=[];lower=[];upper=[]
    def add(d,lb=-inf,ub=inf):rows.append(d);lower.append(lb);upper.append(ub)
    for j in range(n):
        add({ix[(j,i)]:1 for i in inst.p[j]},lb=1,ub=1)
        add({ic[j]:1,is_[j]:-1,**{ix[(j,i)]:-q for i,q in inst.p[j].items()}},lb=0,ub=0)
    for i,j,k in y:
        yk=iy[(i,j,k)];xx=ix[(j,i)];xk=ix[(k,i)]
        Mf=max(0.,Uj[j]-a[k]); Mr=max(0.,Uj[k]-a[j])
        add({yk:1,xx:-1},ub=0)
        add({yk:1,xk:-1},ub=0)
        # s_k >= c_j - Mf(1-y) - Mf(2-xj-xk)
        add({is_[k]:1,ic[j]:-1,yk:-Mf,xx:-Mf,xk:-Mf},lb=-3*Mf)
        # s_j >= c_k - Mr*y - Mr(2-xj-xk)
        add({is_[j]:1,ic[k]:-1,yk:Mr,xx:-Mr,xk:-Mr},lb=-2*Mr)
    rr=[];cc=[];vv=[]
    for rid,row in enumerate(rows):
        for idx,v in row.items():rr.append(rid);cc.append(idx);vv.append(v)
    mat=coo_matrix((vv,(rr,cc)),shape=(len(rows),nv)).tocsr()
    lo=np.zeros(nv);hi=np.full(nv,inf);integrality=np.zeros(nv,dtype=int)
    for j,i in x:
        hi[ix[(j,i)]]=1;integrality[ix[(j,i)]]=1
    for t in y:
        hi[iy[t]]=1;integrality[iy[t]]=1
    for j in range(n):
        lo[is_[j]]=a[j];hi[is_[j]]=Uj[j];hi[ic[j]]=Uj[j]
    obj=np.zeros(nv)
    for j in range(n):obj[ic[j]]=1
    res=milp(obj,integrality=integrality,bounds=Bounds(lo,hi),
             constraints=LinearConstraint(mat,lower,upper),
             options={'time_limit':time_limit,'mip_rel_gap':mip_rel_gap})
    out=dict(name=inst.name,status=int(res.status),message=res.message,objective=None if res.fun is None else float(res.fun-sum(a)),
             lower_bound=None if getattr(res,'mip_dual_bound',None) is None else float(res.mip_dual_bound-sum(a)),
             gap=getattr(res,'mip_gap',None),n_vars=nv,n_constraints=len(rows),Uj=Uj)
    if res.x is not None:
        schedule=[]
        for j in range(n):
            berth=next(i for i in inst.p[j] if res.x[ix[(j,i)]]>0.5)
            schedule.append(dict(vessel=j,berth=berth,arrival=a[j],start=float(res.x[is_[j]]),finish=float(res.x[ic[j]]),duration=inst.p[j][berth]))
        assert evaluate_schedule(inst,schedule)['ok']
        out['schedule']=schedule
    return out
