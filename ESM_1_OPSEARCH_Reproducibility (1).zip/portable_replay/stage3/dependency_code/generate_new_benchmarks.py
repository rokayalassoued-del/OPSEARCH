"""NEW 2026-10-31 OPSEARCH validation instances. Not original S1-M4 inputs.
Physical vessel/cargo/berth sampling is adapted transparently from recovered
synthetic_pso_experiments.py. Uses a deliberately reduced berth subset and a
non-hard nominal horizon H to target nominal workload ratios.
"""
from __future__ import annotations
import json, math, random, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(Path(__file__).resolve().parent))
import synthetic_pso_experiments as original

PLAN=[('S1',4,6,20261101,.70,.35),('S2',4,7,20261102,.75,.25),('S3',4,8,20261103,.80,.35),
      ('S4',5,8,20261104,.72,.30),('S5',5,9,20261105,.80,.25),('S6',5,10,20261106,.86,.35),
      ('M1',6,11,20261107,.72,.30),('M2',6,12,20261108,.80,.25),('M3',6,13,20261109,.86,.35),
      ('M4',6,14,20261110,.90,.30)]
BERTHS={4:[1,4,5,9],5:[1,4,5,9,12],6:[1,4,5,9,12,13]}

def generate(label,m,n,seed,target_rho,arr_frac):
    rng=random.Random(seed)
    allowed=BERTHS[m]
    vessels=[]
    for j in range(n):
        rejected=0
        while True:
            rejected+=1
            if rejected>10000:raise RuntimeError('sampled too many incompatible vessels')
            w=original.sample_cargo(rng.random())
            ell=(rng.uniform(110,180) if w==1 else rng.uniform(150,230) if w==2 else rng.uniform(200,300))
            draft=min(13,max(6,4.5+.025*ell+rng.uniform(-.5,.5)))
            if w==1: QL,QU=rng.uniform(800,2200),rng.uniform(1000,2600)
            elif w==2: QL,QU=rng.uniform(1500,3500),rng.uniform(1800,4200)
            else:QL,QU=rng.uniform(2500,5500),rng.uniform(3000,6500)
            r=rng.random()
            if r<.15:QL=0.
            elif r<.30:QU=0.
            security=rng.uniform(1,3);payment=rng.uniform(.5,1.5)
            service={}
            for i in allowed:
                par=original.PARAMS[i]
                if ell<=par['L'] and draft<=par['D'] and QU<=par['q'] and w in par['cargo']:
                    service[i]=original.BASE_L[w]/par['eta']*QL+original.BASE_U[w]/par['eta']*QU+security+payment
            if service:break
        vessels.append(dict(id=j,cargo=w,length=ell,draft=draft,Q_load=QL,Q_unload=QU,security=security,payment=payment,feasible_berths=list(service),p_by_berth={str(i):v for i,v in service.items()}))
    work=sum(min(v['p_by_berth'].values()) for v in vessels)
    H=int(math.ceil(work/(m*target_rho)))
    arrivals=sorted(int(math.floor(arr_frac*H*rng.random())) for j in range(n))
    for j,v in enumerate(vessels): v['arrival']=arrivals[j]
    rho=work/(m*H)
    obj=dict(label=label,source='NEW_VALIDATION_NOT_ORIGINAL',created_utc='2026-10-31',seed=seed,berth_ids=allowed,n_berths=m,n_vessels=n,
             H_nominal=H,nominal_workload_ratio=rho,target_rho=target_rho,arrival_fraction=arr_frac,
             generator='generate_new_benchmarks.py',berth_params={str(i):{k:sorted(list(v)) if isinstance(v,set) else v for k,v in original.PARAMS[i].items()} for i in allowed},vessels=vessels)
    return obj

if __name__=='__main__':
    for cfg in PLAN:
        inst=generate(*cfg)
        path=ROOT/'data_new'/f'{cfg[0]}.json'
        path.write_text(json.dumps(inst,indent=2,sort_keys=True)+'\n',encoding='utf-8')
        print(f"{cfg[0]} n={cfg[2]} m={cfg[1]} H={inst['H_nominal']} rho={inst['nominal_workload_ratio']:.4f} -> {path}")
