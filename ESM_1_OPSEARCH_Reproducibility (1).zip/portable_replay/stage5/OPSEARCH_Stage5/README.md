# OPSEARCH Stage 5 — independent seed-family holdout

**Research verification only. No manuscript or reviewer-response edits.**

This experimental package extends the Stage 4 synthetic comparisons with 12 new generator seed families (eight factorial treatments per family). The 96 instances are newly generated, controlled synthetic derivatives of the recovered generator. None is an historical vessel-level S1–M4 instance, and none is presented as real port data.

Six configurations (archived PSO, GA, SA, MSLS, cognitive-dominant PSO, PSO without local search) are evaluated on each case, 10 independent stochastic runs each. The fitness evaluation budget is fixed at 528 per run. Every run undergoes an independent feasibility and objective consistency audit.

Statistical comparisons use the **12 distinct generator seed families** as independent blocks, with exact sign-flip tests and family-level bootstrap confidence intervals. Multiple-testing correction is separated for algorithm comparisons and two pre-specified PSO variants. Results do not imply port-wide generalization.

The separate 3600-second MILP solver experiment for M4 is **not part of the holdout comparisons**. Its completion and bounds must be independently verified.

Run `python code/run_holdout.py`, `python code/analyze_holdout.py`, `python code/make_report.py` from the package root. The package includes archived algorithm, generator and feasibility-verification dependencies.
