#!/usr/bin/env python3
"""Pre-specified holdout analysis with *independent seed family* as inferential unit."""
import sys,json,csv,itertools,hashlib,math,random,statistics
from collections import defaultdict
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'code'))
import run_holdout as stage5
from canonical_exact_milp import Instance,evaluate_schedule

def csvwrite(p,records):
    if not records:return
    with p.open('w',newline='') as f:
        out=csv.DictWriter(f,fieldnames=list(records[0]));out.writeheader();out.writerows(records)

def exact_signflip(values):
    v=np.array(values,dtype=float)
    obs=abs(float(v.mean()))
    cnt=0
    for bits in itertools.product((-1.,1.),repeat=len(v)):
        if abs(float((v*np.array(bits)).mean()))>=obs-1e-12:cnt+=1
    return cnt/(2**len(v))

def bootstrap_ci(values,seed):
    vals=np.array(values,dtype=float)
    rng=np.random.default_rng(seed)
    reps=30000
    draw=rng.integers(0,len(vals),size=(reps,len(vals)))
    means=vals[draw].mean(axis=1)
    return np.quantile(means,[.025,.975]).tolist()

def holm(items):
    vals=sorted([(item['p_exact'],i) for i,item in enumerate(items)])
    prev=0
    for pos,(p,i) in enumerate(vals):
        corrected=max(prev,min(1,p*(len(vals)-pos)))
        items[i]['holm_p']=corrected
        prev=corrected

def main():
    meta=json.loads((ROOT/'results'/'metadata.json').read_text())
    raw=list(csv.DictReader((ROOT/'results'/'runs.csv').open()))
    manifest=list(csv.DictReader((ROOT/'results'/'input_manifest.csv').open()))
    assert meta['status']=='RUNS_COMPLETE_AWAITING_STATISTICAL_AUDIT'
    assert len(raw)==5760 and len(manifest)==96
    assert set(meta['heldout_seeds']).isdisjoint(meta['stage4_training_seeds'])
    assert {int(row['base_seed']) for row in raw}==set(meta['heldout_seeds'])
    assert len({(r['instance'],r['algorithm'],r['repetition']) for r in raw})==5760
    for r in raw:
        assert int(r['valid'])==1 and int(r['objective_evaluations'])==528 and math.isfinite(float(r['objective']))
    # Separate independent audit: input re-hash, workload and arrivals; saved best schedule check.
    sources={};schedule_verified=0
    for mr in manifest:
        path=ROOT/'data'/(mr['instance']+'.json')
        sha=hashlib.sha256(path.read_bytes()).hexdigest()
        assert sha==mr['sha256']
        data=json.loads(path.read_text())
        assert data['instance']==mr['instance'] and data['seed']==int(mr['seed'])
        arrivals=data['arrival_times']
        P=[{int(i):float(p) for i,p in row.items()} for row in data['processing_times']]
        can=Instance(tuple(arrivals),tuple(P),data['instance'])
        rho=sum(min(row.values()) for row in P)/(13*data['H_nominal'])
        assert math.isclose(rho,float(mr['rho']),rel_tol=1e-10)
        assert abs(can.U-float(mr['U']))<1e-7
        assert max(arrivals)<=data['arrival_fraction']*data['H_nominal']+1e-8
        sources[data['instance']]=(can,sha)
    bests=[json.loads(line) for line in (ROOT/'results'/'best_schedules.jsonl').open()]
    assert len(bests)==96*6
    for r in bests:
        inst,sha=sources[r['instance']]
        assert sha==r['sha256']
        check=evaluate_schedule(inst,r['assignments'])
        assert check['ok'] and check['within_U']
        assert math.isclose(check['objective'],float(r['objective']),rel_tol=1e-10,abs_tol=1e-6)
        schedule_verified+=1
    # instance -> method averages, without treating the 10 heuristic repeats as independent problem instances
    grp=defaultdict(list)
    for r in raw:
        grp[(r['instance'],r['algorithm'])].append(float(r['objective']))
    stats=[]
    for (inst,alg),vals in sorted(grp.items()):
        assert len(vals)==10
        stats.append(dict(instance=inst,algorithm=alg,n=10,mean=statistics.mean(vals),
                         sd=statistics.stdev(vals),median=statistics.median(vals),
                         best=min(vals),worst=max(vals)))
    csvwrite(ROOT/'results'/'case_method_summary.csv',stats)
    case_means={(v['instance'],v['algorithm']):v['mean'] for v in stats}
    family_effects=[]
    scenarios=defaultdict(list)
    for mr in manifest:scenarios[int(mr['seed'])].append(mr['instance'])
    assert set(scenarios)==set(meta['heldout_seeds'])
    assert all(len(names)==8 for names in scenarios.values())
    pairs=[('PSO','GA'),('PSO','SA'),('PSO','MSLS'),('PSO_cognitive','PSO'),('PSO_no_local','PSO')]
    for seed,names in sorted(scenarios.items()):
        for test,reference in pairs:
            # Positive = lower turnaround objective by test compared with reference.
            improvements=[100*(case_means[(i,reference)]-case_means[(i,test)])/case_means[(i,reference)] for i in names]
            family_effects.append(dict(seed_family=seed,comparison=f'{test} vs {reference}',
                independent_cases=len(names),percent_improvement=statistics.mean(improvements),
                case_wins=sum(x>0 for x in improvements)))
    csvwrite(ROOT/'results'/'independent_seed_family_effects.csv',family_effects)
    result=[]
    for test,reference in pairs:
        label=f'{test} vs {reference}'
        vals=[r['percent_improvement'] for r in family_effects if r['comparison']==label]
        assert len(vals)==12
        lo,hi=bootstrap_ci(vals,seed=30113+len(result))
        result.append(dict(comparison=label,seed_families=12,
            mean_relative_improvement_pct=statistics.mean(vals),
            median_family_improvement_pct=statistics.median(vals),
            seed_families_favor_test=sum(v>0 for v in vals),
            ci95_low_pct=lo,ci95_high_pct=hi,
            p_exact=exact_signflip(vals)))
    holm(result[:3]) # Need correction in original objects (slice holds dict refs)
    holm(result[3:])
    csvwrite(ROOT/'results'/'holdout_statistical_comparisons.csv',result)
    findings=dict(status='PASS',input_files=len(sources),runs=len(raw),unique_run_keys=len(raw),
                  all_schedule_records_valid_flagged=True,saved_best_schedules_rechecked=schedule_verified,
                  independent_seed_families=12,existing_stage4_seeds_disjoint=True,
                  new_seed_families=list(meta['heldout_seeds']),per_family_scenarios=8,
                  per_scenario_repeats=10,objective_evaluations_per_run=528,
                  statistical_unit='base generator seed family',
                  no_realworld_data=True,assumes_derived_synthetic_generator=True)
    (ROOT/'results'/'HOLDOUT_AUDIT.json').write_text(json.dumps(findings,indent=2)+'\n')
    meta['status']='PASS_INDEPENDENT_AUDIT';meta['saved_best_schedules_rechecked']=schedule_verified
    (ROOT/'results'/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
    print('INDEPENDENT AUDIT PASS',json.dumps(findings),flush=True)
    for r in result:print('STAT',r,flush=True)
if __name__=='__main__':main()
