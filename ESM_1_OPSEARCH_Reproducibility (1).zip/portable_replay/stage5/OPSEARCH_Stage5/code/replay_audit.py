#!/usr/bin/env python3
"""Cold replay from saved JSON and raw run metadata, independently checks 288 outcomes."""
import sys,csv,json,math,hashlib,statistics,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'code'))
from run_holdout import run_method,ALGORITHMS,FAMILY_SEEDS
import stage4
from canonical_exact_milp import Instance
CASES={(60,.65,.20),(120,1.15,.60)}

def main():
    t=time.perf_counter()
    rows=list(csv.DictReader((ROOT/'results'/'runs.csv').open()))
    sample=[r for r in rows if (int(r['n']),float(r['rho']),float(r['arrival_fraction'])) in CASES and int(r['repetition']) in (0,1)]
    assert len(sample)==12*2*6*2,(len(sample),)
    outcomes=[]
    for r in sample:
        p=ROOT/'data'/(r['instance']+'.json'); data=json.loads(p.read_text())
        assert hashlib.sha256(p.read_bytes()).hexdigest()==r['input_sha256']
        P=[{int(i):float(v) for i,v in pp.items()} for pp in data['processing_times']]
        A=data['arrival_times']; can=Instance(tuple(A),tuple(P),data['instance'])
        lg=dict(n=len(A),H=data['H_nominal'],A=A,P=P,feas=[tuple(row) for row in P],seed=data['seed'],rho=data['rho_observed'])
        score,seq,calls,seed=run_method(r['algorithm'],lg,int(r['repetition']),len(A),float(r['rho']),float(r['arrival_fraction']))
        audit,_=stage4.independent_check(lg,can,seq,score)
        assert calls==528 and audit['ok'] and audit['within_U']
        assert math.isclose(score,float(r['objective']),rel_tol=1e-12,abs_tol=1e-6),(r,score)
        assert seed==int(r['rng_seed'])
        outcomes.append(dict(instance=r['instance'],algorithm=r['algorithm'],rep=int(r['repetition']),
                             expected=float(r['objective']),replayed=score,abs_diff=abs(score-float(r['objective'])),
                             sha256=r['input_sha256'],verified=True))
    out=ROOT/'results'/'cold_replay_288.csv'
    with out.open('w',newline='') as f:
        w=csv.DictWriter(f,list(outcomes[0]));w.writeheader();w.writerows(outcomes)
    (ROOT/'results'/'COLD_REPLAY_AUDIT.json').write_text(json.dumps(dict(status='PASS',replays=len(outcomes),
           max_objective_discrepancy=max(x['abs_diff'] for x in outcomes),
           levels=['60_065_20','120_115_60'],seed_families=len(FAMILY_SEEDS),
           independent_inputs_source='saved JSON datasets, not regenerated original samples',
           elapsed_s=time.perf_counter()-t),indent=2)+'\n')
    print(f'PASS {len(outcomes)} cold replays exact objective reproduction elapsed={time.perf_counter()-t:.1f}s',flush=True)
if __name__=='__main__':main()
