#!/usr/bin/env python3
"""Run the same checked algorithms against saved JSON cases; no external Stage2-4 files required."""
import sys,csv,json,math,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'code'))
import run_holdout as h
import stage4,compare_heuristics
from canonical_exact_milp import Instance

def main():
    # The bundled dependency tree, not an outside /mnt/data source, MUST be used.
    assert str(ROOT/'dependencies') in str(Path(stage4.__file__).resolve())
    assert str(ROOT/'dependencies') in str(Path(compare_heuristics.__file__).resolve())
    raw=list(csv.DictReader((ROOT/'results'/'runs.csv').open()))
    assert len(raw)==5760
    cases=['IND_K01_N60_R065_A20','IND_K12_N120_R115_A60']
    sample=[r for r in raw if r['instance'] in cases and int(r['repetition'])==0]
    assert len(sample)==12
    for r in sample:
        path=ROOT/'data'/(r['instance']+'.json')
        assert hashlib.sha256(path.read_bytes()).hexdigest()==r['input_sha256']
        a=json.loads(path.read_text())
        P=[{int(i):float(x) for i,x in q.items()} for q in a['processing_times']]
        can=Instance(tuple(a['arrival_times']),tuple(P),r['instance'])
        lg=dict(n=a['n_vessels'],H=a['H_nominal'],A=a['arrival_times'],P=P,
                feas=[tuple(p) for p in P],seed=a['seed'],rho=a['rho_observed'])
        score,seq,e,seed=h.run_method(r['algorithm'],lg,0,a['n_vessels'],float(r['rho']),float(r['arrival_fraction']))
        audit,sch=stage4.independent_check(lg,can,seq,score)
        assert audit['ok'] and audit['within_U'] and e==528
        assert math.isclose(score,float(r['objective']),rel_tol=1e-12,abs_tol=1e-7)
        assert seed==int(r['rng_seed'])
    print(f'PORTABLE PASS: {len(sample)} exact algorithm replays, local bundled imports, 528 evaluations each')
if __name__=='__main__':main()
