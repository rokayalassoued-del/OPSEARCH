#!/usr/bin/env python3
"""Output cautious technical research summary and figures from audited Stage 5 results."""
import csv,json,statistics
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent.parent
R=ROOT/'results'
stat=list(csv.DictReader((R/'holdout_statistical_comparisons.csv').open()))
raw=list(csv.DictReader((R/'runs.csv').open()))
audit=json.loads((R/'HOLDOUT_AUDIT.json').read_text())
rows=[]
for alg in ('PSO','GA','SA','MSLS','PSO_cognitive','PSO_no_local'):
    times=[float(r['search_runtime_s']) for r in raw if r['algorithm']==alg]
    rows.append((alg,statistics.mean(times),statistics.median(times)))
fig,ax=plt.subplots(figsize=(9,4.5))
labels=[i['comparison'] for i in stat]
y=list(range(len(stat)))
means=[float(x['mean_relative_improvement_pct']) for x in stat]
low=[float(x['ci95_low_pct']) for x in stat];high=[float(x['ci95_high_pct']) for x in stat]
ax.errorbar(means,y,xerr=[[m-l for m,l in zip(means,low)],[h-m for m,h in zip(means,high)]],fmt='o',capsize=4)
ax.axvline(0,linestyle='--',linewidth=1)
ax.set_yticks(y,labels)
ax.invert_yaxis()
ax.set_xlabel('Relative improvement in mean turnaround time (%)\n(positive values favor the first algorithm)')
ax.set_title('Independent held-out families (n=12), bootstrap 95% CIs')
fig.tight_layout()
(R/'figures').mkdir(exist_ok=True)
fig.savefig(R/'figures'/'holdout_seed_block_effects.png',dpi=190)
plt.close(fig)
lines=['# OPSEARCH — Stage 5 independent-family holdout audit','',
       '## Design and provenance',
       '- Twelve genuinely new deterministic seed families (33001–33203), disjoint from Stage 4 training/stress seeds.',
       '- Each family yields eight related synthetic treatments: 60/120 vessels × nominal intensity 0.65/1.15 × arrival fractions 0.20/0.60.',
       '- Six configurations: unchanged archived PSO, GA, SA, MSLS, cognitive-dominant PSO, PSO with no local search.',
       '- Ten stochastic runs/configuration/scenario, each exactly **528 fitness evaluations**.',
       '- No claim that equal evaluation counts give equal CPU budgets.',
       '- PSO variants were chosen from Stage 4 before inspecting Stage 5 outcomes.',
       '- Inputs originate from the recovered synthetic generator and controlled transformations, not observed port records.',
       '', '## Data and solution integrity',
       f"- Input SHA256 checks: **{audit['input_files']}/{audit['input_files']}**.",
       f"- Final schedules checked during optimization: **{audit['runs']}/{audit['runs']}**.",
       f"- Saved best schedules independently re-checked from raw JSON inputs: **{audit['saved_best_schedules_rechecked']}**.",
       '- Workload ratios and completion bound U independently recomputed from each saved input.',
       '', '## Family-blocked inferential results',
       'Positive effect indicates a lower average turnaround-time objective for the left-hand method.',
       'Effects are first averaged over related scenarios within each independent family. The 12 family-level effects are the inferential units.',
       'Exact two-sided sign-flip p-values enumerate all 4,096 family sign patterns. Holm adjustments are performed separately for the 3 comparator tests and 2 preselected tuning candidates. Percentile bootstrap resamples entire families (30,000 replicates).',
       '', '| Comparison | Mean improvement | 95% bootstrap CI | Favorable families | Exact p | Holm p |',
       '|---|---:|---:|---:|---:|---:|']
for r in stat:
    lines.append(f"| {r['comparison']} | {float(r['mean_relative_improvement_pct']):+.3f}% | [{float(r['ci95_low_pct']):+.3f}%, {float(r['ci95_high_pct']):+.3f}%] | {r['seed_families_favor_test']}/12 | {float(r['p_exact']):.5f} | {float(r['holm_p']):.5f} |")
lines+=['','## Measured per-run search time','', '| Method | Mean seconds | Median seconds |','|---|---:|---:|']
for alg,m,med in rows:lines.append(f'| {alg} | {m:.4f} | {med:.4f} |')
lines+=['','## Limits that remain','',
 '- These families are statistically independent pseudo-random generator seeds but share a single synthetic *generation mechanism*. They cannot establish external operational validity.',
 '- Results compare these implementations at the stated parameters. They do not establish algorithm-independent superiority.',
 '- The two PSO alternatives were selected from Stage 4 exploratory trials. Their Stage 5 evaluation is a confirmatory holdout for these two specified candidates only.',
 '- Arrival fractions and nominal workload intensity represent simulated stress conditions, not field-calibrated arrivals or observed berth utilization.',
 '- The original historical S1–M4 vessel-level data have not been recovered, so no new synthetic inputs have been presented as original.',
 '- The 3,600-second M4 exact benchmark is a distinct experiment and its certificate must be verified from the raw solver output before being added.',
 '- The paper and reviewer responses are not modified.',
 '', '## Reproduction and files','',
 '- `data/`: 96 saved JSON instances.',
 '- `results/runs.csv`: 5,760 runs with seeds, objective, evaluation count and runtime.',
 '- `results/input_manifest.csv`: 96 SHA256s and controlled intensity values.',
 '- `results/best_schedules.jsonl`: 576 best assignment schedules, independently validated.',
 '- `results/independent_seed_family_effects.csv`: 12 family-level comparisons for each pair.',
 '- `results/holdout_statistical_comparisons.csv`: Holm p-values and block bootstrap confidence intervals.',
 '- `results/HOLDOUT_AUDIT.json`: integrity checks.',
 '- `code/` and `dependencies/`: runnable scripts and source of original algorithms.',
 '',
 'Commands from package root:',
 '```bash',
 'python code/run_holdout.py',
 'python code/analyze_holdout.py',
 'python code/make_report.py',
 '```',
 'Rerunning replaces output files. Record a copy of the original package before doing so.',
 '']
(R/'STAGE5_RESEARCH_REPORT.md').write_text('\n'.join(lines))
print('\n'.join(lines[:36]))
