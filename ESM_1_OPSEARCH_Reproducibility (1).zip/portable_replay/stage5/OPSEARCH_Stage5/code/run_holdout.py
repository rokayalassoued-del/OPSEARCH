#!/usr/bin/env python3
"""OPSEARCH Stage 5: independent seed-family holdout and prespecified PSO variants.
Raw input files and manuscript remain unchanged. All new cases labeled derived synthetic.
The 12 seed families were selected prior to observing any Stage5 scores.
"""
import sys,os,csv,json,time,math,hashlib,random,statistics,platform
from pathlib import Path
from collections import defaultdict
ROOT=Path(__file__).resolve().parent.parent
BUNDLED=ROOT/'dependencies'/'stage4'/'code'
DEPEND=BUNDLED
if not (DEPEND/'stage4.py').exists():
    raise FileNotFoundError('Bundled Stage-4 dependencies are required')
sys.path.insert(0,str(DEPEND))
sys.path.insert(0,str(DEPEND/'dependencies'))
import stage4, sensitivity
import synthetic_pso_experiments as legacy
import compare_heuristics as s3
from canonical_exact_milp import Instance
from scipy import __version__ as scipy_version
import numpy as np

# Pre-registered before any Stage5 output was calculated; none overlaps Stage4 seeds.
FAMILY_SEEDS=(33001,33019,33037,33053,33071,33091,33113,33127,33149,33173,33191,33203)
SIZES=(60,120)
WORKLOADS=(.65,1.15)
ARRIVALS=(.20,.60)
REPS=10
ALGORITHMS=('PSO','GA','SA','MSLS','PSO_cognitive','PSO_no_local')
PARAMETERS={
    'PSO_cognitive':dict(swarm=10,c1=2.5,c2=1.2,local_trials=15),
    'PSO_no_local':dict(swarm=10,c1=1.7,c2=2.0,local_trials=0),
}

def create_case(n,w,f,seed,k):
    base=legacy.gen_instance(n,seed)
    scale=w/base['rho']
    arrivals=[int(math.floor(a*f/.35)) for a in base['A']]
    P=[{i:p*scale for i,p in row.items()} for row in base['P']]
    achieved=sum(min(r.values()) for r in P)/(13*base['H'])
    assert abs(achieved-w)<1e-10
    name=f'IND_K{k:02}_N{n}_R{round(w*100):03}_A{round(f*100):02}'
    lg={'n':n,'H':base['H'],'A':arrivals,'feas':base['feas'],'P':P,'seed':seed,'rho':achieved}
    can=Instance(tuple(arrivals),tuple(P),name)
    data=dict(instance=name,source='DERIVED_SYNTHETIC_HOLDOUT_ARCHIVED_GENERATOR',seed=seed,
              seed_family=k,n_vessels=n,n_berths=13,H_nominal=base['H'],
              arrival_fraction=f,rho_target=w,rho_observed=achieved,
              base_rho=base['rho'],duration_multiplier=scale,arrival_times=arrivals,
              processing_times=[{str(i):p for i,p in r.items()} for r in P],U=can.U)
    path=ROOT/'data'/f'{name}.json'
    path.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
    sha=hashlib.sha256(path.read_bytes()).hexdigest()
    return name,lg,can,data,sha

def run_method(alg,inst,rep,n,w,f):
    if alg=='PSO':
        obj,seq,e=s3.pso_archived(inst,rep)
        return obj,seq,e,100000+inst['seed']*100+rep
    if alg.startswith('PSO_'):
        obj,seq,e=sensitivity.variant_pso(inst,rep,PARAMETERS[alg])
        return obj,seq,e,100000+inst['seed']*100+rep
    # Unique deterministic random streams, no source-data leakage.
    tag={'GA':1,'SA':2,'MSLS':3}[alg]
    rs=99000000+inst['seed']*100000+rep*100+tag
    rng=random.Random(rs)
    fun={'GA':s3.ga,'SA':s3.sa,'MSLS':s3.msls_safe}[alg]
    obj,seq,e=fun(inst,rng)
    return obj,seq,e,rs

def save(path,rows):
    if not rows:return
    with open(path,'w',newline='') as fh:
        writer=csv.DictWriter(fh,fieldnames=list(rows[0].keys()))
        writer.writeheader();writer.writerows(rows)

def main():
    tstart=time.perf_counter()
    rows=[];manifest=[];best=[];counter=0
    for k,seed in enumerate(FAMILY_SEEDS,1):
      for n in SIZES:
       for w in WORKLOADS:
        for f in ARRIVALS:
          name,lg,can,data,sha=create_case(n,w,f,seed,k)
          manifest.append(dict(instance=name,sha256=sha,seed=seed,family=k,n=n,
                               rho=w,arrival_fraction=f,achieved_rho=data['rho_observed'],U=can.U))
          for alg in ALGORITHMS:
            minscore=float('inf'); bestrow=None
            for rep in range(REPS):
              t=time.perf_counter()
              score,seq,e,rs=run_method(alg,lg,rep,n,w,f)
              runtime=time.perf_counter()-t
              audit,sch=stage4.independent_check(lg,can,seq,score)
              assert e==s3.BUDGET and audit['ok'] and audit['within_U']
              if alg=='PSO' and rep in (0,1):
                  reference=sensitivity.variant_pso(lg,rep,sensitivity.VARIANTS['archived'])[0]
                  assert math.isclose(reference,score,rel_tol=1e-11,abs_tol=1e-6)
              rows.append(dict(instance=name,seed_family=k,base_seed=seed,n=n,
                               rho=w,arrival_fraction=f,algorithm=alg,
                               repetition=rep,rng_seed=rs,objective=score,
                               objective_evaluations=e,search_runtime_s=runtime,
                               max_completion=audit['max_completion'],U=can.U,
                               valid=1,input_sha256=sha))
              if score<minscore:
                minscore=score
                bestrow=dict(instance=name,algorithm=alg,repetition=rep,
                             objective=score,assignments=sch,sha256=sha)
            best.append(bestrow)
          counter+=1
          save(ROOT/'results'/'runs.csv',rows)
          save(ROOT/'results'/'input_manifest.csv',manifest)
          if counter%4==0:
             print(f'STAGE5 progress {counter}/96 cases {len(rows)}/5760 verified runs elapsed={time.perf_counter()-tstart:.1f}s',flush=True)
    with (ROOT/'results'/'best_schedules.jsonl').open('w') as fh:
        for r in best:fh.write(json.dumps(r)+'\n')
    metadata=dict(status='RUNS_COMPLETE_AWAITING_STATISTICAL_AUDIT',
      source='new derived synthetic holdout; original generator and Stage4 validation',
      heldout_seeds=list(FAMILY_SEEDS),seed_count=len(FAMILY_SEEDS),instances=counter,
      algorithms=list(ALGORITHMS),runs_per_algorithm_per_case=REPS,
      runs=len(rows),evaluation_budget=s3.BUDGET,feasible_schedules=len(rows),
      python=platform.python_version(),scipy=scipy_version,
      generator_sha256=hashlib.sha256(Path(legacy.__file__).read_bytes()).hexdigest(),
      algorithm_sha256=hashlib.sha256(Path(s3.__file__).read_bytes()).hexdigest(),
      sensitivity_sha256=hashlib.sha256(Path(sensitivity.__file__).read_bytes()).hexdigest(),
      stage4_training_seeds=list(stage4.SEEDS),total_elapsed_s=time.perf_counter()-tstart,
      statistical_unit='independent base seed family, not each factorial case or stochastic run',
      limit='synthetic generator; no observed port validation; runtime varies by algorithm; two variant candidates prespecified from Stage4')
    (ROOT/'results'/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
    print('STAGE5 DONE',len(rows),'feasible runs',round(time.perf_counter()-tstart,1),'s',flush=True)

if __name__=='__main__':main()
