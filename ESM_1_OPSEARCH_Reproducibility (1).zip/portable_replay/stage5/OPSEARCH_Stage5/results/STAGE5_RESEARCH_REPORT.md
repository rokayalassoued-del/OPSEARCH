# OPSEARCH — Stage 5 independent-family holdout audit

## Design and provenance
- Twelve genuinely new deterministic seed families (33001–33203), disjoint from Stage 4 training/stress seeds.
- Each family yields eight related synthetic treatments: 60/120 vessels × nominal intensity 0.65/1.15 × arrival fractions 0.20/0.60.
- Six configurations: unchanged archived PSO, GA, SA, MSLS, cognitive-dominant PSO, PSO with no local search.
- Ten stochastic runs/configuration/scenario, each exactly **528 fitness evaluations**.
- No claim that equal evaluation counts give equal CPU budgets.
- PSO variants were chosen from Stage 4 before inspecting Stage 5 outcomes.
- Inputs originate from the recovered synthetic generator and controlled transformations, not observed port records.

## Data and solution integrity
- Input SHA256 checks: **96/96**.
- Final schedules checked during optimization: **5760/5760**.
- Saved best schedules independently re-checked from raw JSON inputs: **576**.
- Workload ratios and completion bound U independently recomputed from each saved input.

## Family-blocked inferential results
Positive effect indicates a lower average turnaround-time objective for the left-hand method.
Effects are first averaged over related scenarios within each independent family. The 12 family-level effects are the inferential units.
Exact two-sided sign-flip p-values enumerate all 4,096 family sign patterns. Holm adjustments are performed separately for the 3 comparator tests and 2 preselected tuning candidates. Percentile bootstrap resamples entire families (30,000 replicates).

| Comparison | Mean improvement | 95% bootstrap CI | Favorable families | Exact p | Holm p |
|---|---:|---:|---:|---:|---:|
| PSO vs GA | +1.969% | [+1.706%, +2.220%] | 12/12 | 0.00049 | 0.00146 |
| PSO vs SA | +4.759% | [+4.252%, +5.261%] | 12/12 | 0.00049 | 0.00146 |
| PSO vs MSLS | +9.545% | [+9.080%, +10.011%] | 12/12 | 0.00049 | 0.00146 |
| PSO_cognitive vs PSO | +1.065% | [+0.853%, +1.291%] | 12/12 | 0.00049 | 0.00098 |
| PSO_no_local vs PSO | +0.860% | [+0.551%, +1.176%] | 12/12 | 0.00049 | 0.00098 |

## Measured per-run search time

| Method | Mean seconds | Median seconds |
|---|---:|---:|
| PSO | 0.0660 | 0.0691 |
| GA | 0.0842 | 0.0844 |
| SA | 0.0574 | 0.0600 |
| MSLS | 0.0572 | 0.0592 |
| PSO_cognitive | 0.0674 | 0.0685 |
| PSO_no_local | 0.0671 | 0.0744 |

## Limits that remain

- These families are statistically independent pseudo-random generator seeds but share a single synthetic *generation mechanism*. They cannot establish external operational validity.
- Results compare these implementations at the stated parameters. They do not establish algorithm-independent superiority.
- The two PSO alternatives were selected from Stage 4 exploratory trials. Their Stage 5 evaluation is a confirmatory holdout for these two specified candidates only.
- Arrival fractions and nominal workload intensity represent simulated stress conditions, not field-calibrated arrivals or observed berth utilization.
- The original historical S1–M4 vessel-level data have not been recovered, so no new synthetic inputs have been presented as original.
- The 3,600-second M4 exact benchmark is a distinct experiment and its certificate must be verified from the raw solver output before being added.
- The paper and reviewer responses are not modified.

## Reproduction and files

- `data/`: 96 saved JSON instances.
- `results/runs.csv`: 5,760 runs with seeds, objective, evaluation count and runtime.
- `results/input_manifest.csv`: 96 SHA256s and controlled intensity values.
- `results/best_schedules.jsonl`: 576 best assignment schedules, independently validated.
- `results/independent_seed_family_effects.csv`: 12 family-level comparisons for each pair.
- `results/holdout_statistical_comparisons.csv`: Holm p-values and block bootstrap confidence intervals.
- `results/HOLDOUT_AUDIT.json`: integrity checks.
- `code/` and `dependencies/`: runnable scripts and source of original algorithms.

Commands from package root:
```bash
python code/run_holdout.py
python code/analyze_holdout.py
python code/make_report.py
```
Rerunning replaces output files. Record a copy of the original package before doing so.
