# OPSEARCH — Stage 6: Arrival-process robustness and final exact-solver audit

**Computational research verification. The submitted paper and reviewer responses are unchanged.**

## Purpose

This package closes the previously unresolved M4 3,600-second exact-MILP status and tests the robustness of the original random-key PSO against alternative synthetic vessel-arrival processes while retaining berth compatibility, vessel processing profiles, and the deterministic scheduling objective.

## Mathematically justified arrival scenarios

For each fixed-vessel-count case, arrivals are sampled in a common window of length `W = 0.60 H` and sorted. Each matched block shares all vessel and berth processing data.

1. **Uniform, conditional homogeneous Poisson:** `n` independently uniform arrivals in `[0,W]` sorted in time. By the order-statistics theorem, these have precisely the same distribution as a homogeneous Poisson process *conditional on exactly n vessels*. It would be misleading to use this as a distinct fourth comparator.
2. **Nonhomogeneous Poisson, conditional on n:** an increasing rate `lambda(t) = (n/W)[0.3 + 1.4(t/W)]` for `0 <= t <= W`. Its integrated intensity equals `n`, and the conditional event-time CDF is `F(u)=0.3u+0.7u^2`, with `u=t/W`. Inverse-transform sampling generates `n` events, conditioned on the event count.
3. **Two-wave clustered synthetic process:** 65% probability of a Gaussian arrival wave centered on `0.22W` with standard deviation `0.065W`, otherwise a second wave centered on `0.72W` with standard deviation `0.075W`. Realizations are **clipped** to `[0,W]`. This is a controlled Gaussian mixture, not a calibrated Hawkes process.

**No observed port arrival data were used.** This is distributional robustness within a generator, not empirical external validation. In addition, the algorithms optimize deterministic schedules with all sampled arrivals revealed. Thus, this experiment does not demonstrate performance in online stochastic dispatching.

## Factorial design and inference

- Twelve *new* independent generator seeds (disjoint from Stage 4 and Stage 5).
- Two vessel counts: 60, 120.
- Two nominal workload ratios: 0.65 and 1.15. This is a synthetic workload measure, **not** an observed berth-utilization fraction.
- Three arrival patterns as above.
- Four archived algorithms: PSO, GA, SA, multi-start local search (MSLS).
- Ten independent runs per algorithm per case; **528 objective evaluations per run**.
- Total: 144 matched instances, 5,760 algorithm runs.
- Independent statistical unit: original seed family. Twelve families are blocks; treatments and optimizer repetitions are not independently drawn ports.

For every run, the code re-decodes a schedule and verifies unique assignment, berth compatibility, release times, processing durations, berth non-overlap, and objective consistency. All source-generated JSON files have SHA-256 fingerprints. An independent audit revalidates every saved best schedule and replays 288 selected runs.

## Exact-solver completion audit

The 3,600-second HiGHS logs **already exist and have terminated**. The independent verifier reports nine instances proven optimal and one (M4) terminated at the time limit. For M4, a feasible solution was found, but HiGHS did **not** prove optimality. The gap in the objective `sum_j(c_j-a_j)` is distinct from HiGHS's gap on `sum_j c_j` and must be computed separately.

## Files and rerunning

- `code/run_stage6.py`: all arrival-case generation, stochastic algorithm runs and schedule verification.
- `code/audit_and_analyze.py`: independently reloads JSON, validates inputs and saved best schedules, checks statistical unit, performs exact paired sign-flip tests and bootstrap confidence intervals, and replays 288 selected runs.
- `code/audit_exact_3600.py`: reads archived Stage 2 inputs and 3,600-second MILP results and writes the audited 10-instance exact benchmark.
- `results/runs.csv`: all run-level results; `input_manifest.csv`: file hashes and provenance.
- `results/statistical_comparisons.csv`: PSO against GA/SA/MSLS by arrival process, using 12 independent families and a nine-test Holm correction.
- `results/arrival_process_effects.csv`: descriptive changes in objective when the arrival process changes, holding service profiles fixed.
- `results/INDEPENDENT_AUDIT.json`: final audit verdict (must be PASS).
- `results/MILP_ALL10_INDEPENDENT_3600_AUDIT.csv`: final exact-solver table.

To reproduce in this package directory (Python, NumPy, SciPy required):

```bash
python code/run_stage6.py --reps 10
python code/audit_and_analyze.py
```

The 3,600-second exact MILP results are **input evidence**, not recomputed by Stage 6. Copies of all ten original Stage 2 instance JSON files and ten saved one-hour solver outputs are included under `evidence/`, together with M3 and M4 logs. The independent verifier uses these local copies, so it runs without the earlier workspace.

## Mathematical and operational references

- R. G. Gallager, *Discrete Stochastic Processes*, MIT OCW chapter 2, §2.5 (Poisson arrivals conditioned on event count): https://ocw.mit.edu/courses/6-262-discrete-stochastic-processes-spring-2011/3a19ce0e02d0008877351bfa24f3716a_MIT6_262S11_chap02.pdf
- Al-Refaie and Abedalqader, *Optimal berth allocation under regular and emergent vessel arrivals*, DOI 10.1177/1475090220937888.
- Legato and Mazza, *Berth planning and resources optimisation at a container terminal via discrete event simulation*, DOI 10.1016/S0377-2217(00)00200-9.

These sources motivate examining arrival uncertainty and release-time processes; **they do not provide the numerical distributional parameters used in these synthetic tests**.

## Completion summary (independently checked)

- MILP exact benchmark: nine proven optima; M4 time-limit (3,600.19 s), best objective 1,343.0419, best lower bound 1,131.0505, corrected turnaround gap 15.78%.
- Arrival experiment: all 144 input files and 5,760 runs independently validated; 576 best schedules independently rechecked; 288 seeded runs reproduced exactly.
- Family-mean PSO advantages against GA: uniform +1.00%, increasing-rate Poisson +2.15%, clustered +1.23%. Stronger advantages against SA/MSLS appear in the detailed statistical table.
- Under uniform arrivals PSO outperforms GA on only 27/48 individual matched cases. Report this nuance with the 12-family averages.
- Arrival-process stress: PSO mean objective increases +1.75% (rising NHPP) and +9.16% (two-wave clustered) compared with uniform, **for the specified synthetic controls**.
- Figures and detailed methods are in `results/STAGE6_RESEARCH_REPORT.md` and `figures/`.
