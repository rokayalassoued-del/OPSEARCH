#!/usr/bin/env python3
"""OPSEARCH Stage 6 — mathematically distinct arrival profiles on held-out seeds.

This is a synthetic robustness test.  Input processing profiles and compatibility
are fixed within (seed family, vessel count, nominal workload) blocks.
Arrival processes: uniform (also conditional homogeneous Poisson), increasing
NHPP conditional on vessel count, and independent two-wave clustered arrivals.
Archived PSO, GA, SA, MSLS algorithms, random-key decoder, and 528-evaluation
budgets are unchanged.  No manuscript or reviewer-response modifications.
"""
from __future__ import annotations
import argparse,csv,hashlib,json,math,platform,random,statistics,sys,time
from pathlib import Path
from collections import defaultdict

ROOT=Path(__file__).resolve().parents[1]
DEPS=ROOT/'dependencies'/'stage4'/'code'
sys.path.insert(0,str(DEPS)); sys.path.insert(0,str(DEPS/'dependencies'))
import synthetic_pso_experiments as legacy
import compare_heuristics as s3
import stage4
from canonical_exact_milp import Instance

SEEDS=(44011,44029,44053,44071,44087,44101,44119,44137,44153,44171,44189,44203)
NS=(60,120); RHO=(.65,1.15); PATTERNS=('uniform','nhpp_rising','clustered')
METHODS=('PSO','GA','SA','MSLS'); REPS_DEFAULT=10
ARRIVAL_WINDOW_FRAC=.60

def save_csv(path,rows):
    if not rows:return
    with open(path,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def arrival_times(n,H,pattern,seed):
    """Arrivals conditional on N=n in [0,W]. Independent distribution RNG.
    NHPP intensity relative to window u: .3+1.4u, CDF .3u+.7u².
    Clustered: 65/35% mixture of truncated normal waves at .22/.72 W.
    """
    rng=random.Random(91377+seed*1009+{'uniform':11,'nhpp_rising':23,'clustered':37}[pattern])
    W=ARRIVAL_WINDOW_FRAC*H
    if pattern=='uniform':
        aa=[rng.random()*W for _ in range(n)]
    elif pattern=='nhpp_rising':
        # F(u)=0.3 u+0.7 u², inverse is analytically exact.
        aa=[(-.3+math.sqrt(.09+2.8*rng.random()))/1.4*W for _ in range(n)]
    elif pattern=='clustered':
        aa=[max(0.,min(W,(rng.gauss(.22,.065) if rng.random()<.65 else rng.gauss(.72,.075))*W)) for _ in range(n)]
    else:raise ValueError(pattern)
    return sorted(aa)

def build_case(n,rho,pattern,seed,k):
    W=ARRIVAL_WINDOW_FRAC*(72+6*n)
    base=legacy.gen_instance(n,seed)
    mult=rho/base['rho']
    durations=[{i:p*mult for i,p in row.items()} for row in base['P']]
    arrivals=arrival_times(n,base['H'],pattern,seed)
    nominal_ratio=sum(min(r.values()) for r in durations)/(13*base['H'])
    assert abs(nominal_ratio-rho)<1e-10
    label=f'EXT_K{k:02}_N{n}_R{round(rho*100):03}_{pattern}'
    lg={'n':n,'H':base['H'],'A':arrivals,'feas':[tuple(r) for r in base['feas']],
        'P':durations,'seed':seed,'rho':rho}
    can=Instance(tuple(arrivals),tuple(durations),label)
    base_payload=json.dumps([[list(row.items()) for row in durations], [list(row) for row in lg['feas']]],sort_keys=True).encode()
    profile_sha=hashlib.sha256(base_payload).hexdigest()
    data=dict(instance=label,origin='SYNTHETIC_ARRIVAL_ROBUSTNESS',seed_family=k,seed=seed,
              vessels=n,berths=13,H_nominal=base['H'],arrival_window=W,
              profile=pattern,rho_target=rho,rho_computed=nominal_ratio,processing_scale=mult,
              berth_service_profile_sha256=profile_sha,arrivals=arrivals,
              compatible_processing_times=[{str(i):p for i,p in row.items()} for row in durations],
              U=can.U,limitations='no observed port arrival or service data')
    # W is the same across profiles and defined independently of the original arrivals.
    p=ROOT/'data'/f'{label}.json'
    p.write_text(json.dumps(data,sort_keys=True,indent=2)+'\n')
    digest=hashlib.sha256(p.read_bytes()).hexdigest()
    return label,lg,can,data,digest,profile_sha

# Module-level helper W explicit before it is used in build_case.
def run_method(alg,lg,rep):
    if alg=='PSO':
        return (*s3.pso_archived(lg,rep), 100000+lg['seed']*100+rep)
    # Common random number stream ACROSS arrival processes to reduce paired noise.
    ix={'GA':1,'SA':2,'MSLS':3}[alg]
    rand_seed=791000000+lg['seed']*100+rep*10+ix
    rng=random.Random(rand_seed)
    obj,seq,ncalls={'GA':s3.ga,'SA':s3.sa,'MSLS':s3.msls_safe}[alg](lg,rng)
    return obj,seq,ncalls,rand_seed

def main(limit_cases=None,reps=REPS_DEFAULT):
    start=time.perf_counter()
    rows=[];manifest=[];best=[];number=0
    seen_seeds={17011,17029,17053,33001,33019,33037,33053,33071,33091,33113,33127,33149,33173,33191,33203}
    assert not set(SEEDS).intersection(seen_seeds)
    for family,seed in enumerate(SEEDS,1):
      for n in NS:
       for rho in RHO:
        expected_service_hash=None
        for pattern in PATTERNS:
          if limit_cases is not None and number>=limit_cases:break
          W=ARRIVAL_WINDOW_FRAC*(72+6*n)
          label,lg,can,data,sha,profile_sha=build_case(n,rho,pattern,seed,family)
          if expected_service_hash is None:expected_service_hash=profile_sha
          assert profile_sha==expected_service_hash,'Service profile changed with arrival pattern'
          arrivals=lg['A'];assert len(arrivals)==n and min(arrivals)>=0 and max(arrivals)<=W
          manifest.append(dict(instance=label,seed_family=family,seed=seed,n=n,rho=rho,
                               process=pattern,sha256=sha,service_profile_sha256=profile_sha,
                               U=can.U,arrival_mean_frac=statistics.mean(arrivals)/W,
                               arrival_p90_frac=sorted(arrivals)[math.ceil(.9*n)-1]/W))
          for method in METHODS:
            bestrow=None
            for rep in range(reps):
              t0=time.perf_counter()
              obj,seq,calls,rng_seed=run_method(method,lg,rep)
              elapsed=time.perf_counter()-t0
              verification,schedule=stage4.independent_check(lg,can,seq,obj)
              assert verification['ok'] and verification['within_U'] and calls==s3.BUDGET
              row=dict(instance=label,seed_family=family,seed=seed,n=n,rho=rho,
                       arrival_process=pattern,method=method,replicate=rep,
                       rng_seed=rng_seed,objective=obj,mean_turnaround=obj/n,
                       evaluations=calls,runtime_s=elapsed,validated=1,
                       max_completion=verification['max_completion'],U=can.U,
                       input_sha256=sha,service_profile_sha256=profile_sha)
              rows.append(row)
              if bestrow is None or obj<bestrow['objective']:
                bestrow=dict(instance=label,method=method,replicate=rep,objective=obj,
                             input_sha256=sha,schedule=schedule)
            best.append(bestrow)
          number+=1
          if number%12==0:
            save_csv(ROOT/'results'/'runs.csv',rows)
            save_csv(ROOT/'results'/'input_manifest.csv',manifest)
            print(f'STAGE6 progress: {number}/144 cases; {len(rows)} verified runs; elapsed {time.perf_counter()-start:.1f}s',flush=True)
        if limit_cases is not None and number>=limit_cases:break
       if limit_cases is not None and number>=limit_cases:break
      if limit_cases is not None and number>=limit_cases:break
    save_csv(ROOT/'results'/'runs.csv',rows)
    save_csv(ROOT/'results'/'input_manifest.csv',manifest)
    with open(ROOT/'results'/'best_schedules.jsonl','w') as f:
        for r in best:f.write(json.dumps(r)+'\n')
    meta=dict(status='COMPLETE',independent_seed_families=len(SEEDS),
              number_of_instances=number,number_of_runs=len(rows),
              repeats_per_case_method=reps,budget_evaluations=s3.BUDGET,
              protocols=list(PATTERNS),sources='archived generator, new synthetic arrivals',
              fixed_service_and_compatibility_within_matched_block=True,
              independent_from_stage4_and_stage5_seeds=True,
              conditional_nhpp_count_fixed=True,
              homogeneous_poisson_conditional_n_equals_uniform=True,
              provenance='RESEARCH_ONLY_NOT_HISTORICAL_NO_OBSERVED_DATA',
              runtime_s=time.perf_counter()-start,python=platform.python_version())
    (ROOT/'results'/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
    print(f'STAGE6 COMPLETE {number} cases {len(rows)} verified runs elapsed={meta["runtime_s"]:.1f}s',flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--limit-cases',type=int);p.add_argument('--reps',type=int,default=REPS_DEFAULT)
    args=p.parse_args();main(limit_cases=args.limit_cases,reps=args.reps)
