#!/usr/bin/env python3
"""Stage6 fully independent file/schedule/replay and seed-block statistical audit.
Carefully distinguish synthetic arrival robustness from empirical external validity.
"""
from __future__ import annotations
import sys,csv,json,hashlib,math,itertools,statistics,random
from pathlib import Path
from collections import defaultdict
import numpy as np
from scipy.stats import kstest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'dependencies'/'stage4'/'code'))
sys.path.insert(0,str(ROOT/'dependencies'/'stage4'/'code'/'dependencies'))
import synthetic_pso_experiments as legacy
import compare_heuristics as s3
import stage4
from canonical_exact_milp import Instance,evaluate_schedule

PATTERNS=('uniform','nhpp_rising','clustered')
ALGS=('PSO','GA','SA','MSLS')

def readcsv(path):
    with open(path,newline='') as f:return list(csv.DictReader(f))
def savecsv(path,rows):
    if not rows:return
    with open(path,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def exact_flip_p(deltas):
    vals=np.array(deltas,dtype=float)
    obs=abs(float(vals.mean()));count=0
    for signs in itertools.product((-1,1),repeat=len(vals)):
        if abs(float(np.mean(vals*np.array(signs))))>=obs-1e-12:count+=1
    return count/(2**len(vals))

def boot_ci(deltas,random_seed=9283,nsim=12000):
    vals=np.asarray(deltas,dtype=float);n=len(vals)
    rng=np.random.default_rng(random_seed)
    vec=vals[rng.integers(0,n,(nsim,n))].mean(axis=1)
    return float(np.quantile(vec,.025)),float(np.quantile(vec,.975))

def run():
    manifest=readcsv(ROOT/'results'/'input_manifest.csv')
    rows=readcsv(ROOT/'results'/'runs.csv')
    assert len(manifest)==144,(len(manifest),'expected 144')
    assert len(rows)==5760,(len(rows),'expected 5760')
    instances={}
    for entry in manifest:
        label=entry['instance'];p=ROOT/'data'/f'{label}.json'
        assert hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
        d=json.loads(p.read_text());a=d['arrivals'];P=[{int(i):v for i,v in row.items()} for row in d['compatible_processing_times']]
        inst=Instance(tuple(a),tuple(P),label)
        assert math.isclose(inst.U,float(entry['U']),abs_tol=1e-8)
        assert math.isclose(sum(min(v.values()) for v in P)/(13*d['H_nominal']),d['rho_target'],abs_tol=1e-10)
        assert len(a)==d['vessels'] and 0<=min(a)<=max(a)<=d['arrival_window']
        assert list(a)==sorted(a)
        instances[label]=(d,inst)
    # all three processes share the same vessel profile, compatibilities, and workload within each block.
    profiles=defaultdict(set); distributions=[]
    for k,(d,inst) in instances.items():
        b=(d['seed_family'],d['vessels'],d['rho_target'])
        profiles[b].add(d['berth_service_profile_sha256'])
        window=d['arrival_window']; uu=np.array(d['arrivals'])/window
        # Kolmogorov tests provide a transparent diagnostic (not evidence of calibration).
        if d['profile']=='uniform': f=lambda x:x
        elif d['profile']=='nhpp_rising': f=lambda x:.3*x+.7*x*x
        else:f=None
        ks=float(kstest(uu,f).statistic) if f else None
        distributions.append(dict(instance=k,seed_family=d['seed_family'],profile=d['profile'],n=len(uu),
                                  mean_relative_arrival=float(uu.mean()),ks_statistic=ks,
                                  early_quarter_frac=float(np.mean(uu<=.25)),
                                  late_quarter_frac=float(np.mean(uu>=.75))))
    assert len(profiles)==48 and all(len(s)==1 for s in profiles.values())
    savecsv(ROOT/'results'/'arrival_distribution_diagnostics.csv',distributions)
    runkeys=set();by_case=defaultdict(list)
    for r in rows:
        key=(r['instance'],r['method'],r['replicate'])
        assert key not in runkeys;runkeys.add(key)
        assert r['instance'] in instances and r['method'] in ALGS
        assert int(r['evaluations'])==528 and int(r['validated'])==1
        assert r['input_sha256']==next(e['sha256'] for e in manifest if e['instance']==r['instance'])
        assert math.isclose(float(r['mean_turnaround']),float(r['objective'])/int(r['n']),rel_tol=1e-12)
        by_case[(r['instance'],r['method'])].append(float(r['objective']))
    assert len(by_case)==576 and all(len(v)==10 for v in by_case.values())
    summary=[]
    for (k,alg),vals in sorted(by_case.items()):
        d=instances[k][0]
        summary.append(dict(instance=k,seed_family=d['seed_family'],n=d['vessels'],rho=d['rho_target'],
                            arrival_process=d['profile'],method=alg,mean_obj=statistics.mean(vals),
                            mean_turnaround=statistics.mean(vals)/d['vessels'],best=min(vals),
                            std_obj=statistics.stdev(vals),worst=max(vals)))
    savecsv(ROOT/'results'/'case_method_summary.csv',summary)
    summaryidx={(r['instance'],r['method']):r for r in summary}
    # compare within 144 matched conditions and aggregate each family independently
    effects=[];case_wins=defaultdict(int)
    for k in instances:
        d=instances[k][0]
        x=float(summaryidx[(k,'PSO')]['mean_obj'])
        for alg in ALGS[1:]:
            baseline=float(summaryidx[(k,alg)]['mean_obj'])
            benefit=100*(baseline-x)/baseline
            effects.append(dict(instance=k,seed_family=d['seed_family'],arrival_process=d['profile'],
                                method=alg,improvement_pct=benefit,n=d['vessels'],rho=d['rho_target']))
            case_wins[(d['profile'],alg)]+=benefit>0
    savecsv(ROOT/'results'/'case_paired_effects.csv',effects)
    family=defaultdict(list)
    for e in effects:family[(e['arrival_process'],e['method'],e['seed_family'])].append(e['improvement_pct'])
    assert len(family)==3*3*12 and all(len(v)==4 for v in family.values())
    comps=[]
    for pattern in PATTERNS:
        for alg in ALGS[1:]:
            vals=[statistics.mean(family[(pattern,alg,i)]) for i in range(1,13)]
            low,high=boot_ci(vals,random_seed=1300+len(comps))
            comps.append(dict(arrival_process=pattern,PSO_vs=alg,
                              family_mean_advantage_pct=statistics.mean(vals),
                              ci_low_pct=low,ci_high_pct=high,
                              wins_out_of_12=sum(v>0 for v in vals),
                              wins_out_of_48_cases=case_wins[(pattern,alg)],
                              exact_sign_flip_p=exact_flip_p(vals)))
    order=sorted(range(len(comps)),key=lambda j:comps[j]['exact_sign_flip_p'])
    adjusted=[]
    for rank,j in enumerate(order):
        adjusted.append(min(1,(len(comps)-rank)*comps[j]['exact_sign_flip_p']))
    mx=0.
    for j,v in zip(order,adjusted):
        mx=max(mx,v);comps[j]['holm_adjusted_p_9']=mx
    savecsv(ROOT/'results'/'statistical_comparisons.csv',comps)
    # descriptively compare arrival profile shifts within each algorithm, matching vessel profile seed.
    out=[]
    for pat in PATTERNS[1:]:
        for alg in ALGS:
            diffs=[]
            for seedid in range(1,13):
                b=[]
                for n in (60,120):
                    for rho in (.65,1.15):
                        matches=[d for d,inst in instances.values() if d['seed_family']==seedid and d['vessels']==n and d['rho_target']==rho]
                        targets={d['profile']:d['instance'] for d in matches}
                        obj1=float(summaryidx[(targets[pat],alg)]['mean_turnaround'])
                        obj0=float(summaryidx[(targets['uniform'],alg)]['mean_turnaround'])
                        b.append(100*(obj1-obj0)/obj0)
                diffs.append(statistics.mean(b))
            lo,hi=boot_ci(diffs,random_seed=777+len(out))
            out.append(dict(contrast=f'{pat}_minus_uniform',method=alg,
                            family_mean_percentage_difference=statistics.mean(diffs),
                            ci_low_pct=lo,ci_high_pct=hi,exact_sign_flip_p=exact_flip_p(diffs)))
    savecsv(ROOT/'results'/'arrival_process_effects.csv',out)
    # independently verify stored 576 best schedules from authoritative JSON input
    best_file=ROOT/'results'/'best_schedules.jsonl'
    savedbest=[json.loads(l) for l in best_file.read_text().splitlines() if l.strip()]
    assert len(savedbest)==576
    for best in savedbest:
        inst=instances[best['instance']][1]
        audit=evaluate_schedule(inst,best['schedule'])
        assert audit['ok'] and audit['within_U']
        assert math.isclose(audit['objective'],best['objective'],abs_tol=1e-5,rel_tol=1e-11)
    # deterministic replay: 2 reps for each method in each of 12 families at 3 profiles = 288 runs
    from run_stage6 import run_method
    replay=[]
    index={(r['instance'],r['method'],int(r['replicate'])):r for r in rows}
    for i in range(1,13):
        for pat in PATTERNS:
            matched=[d for d,inst in instances.values() if d['seed_family']==i and d['vessels']==60 and d['rho_target']==.65 and d['profile']==pat]
            assert len(matched)==1
            d=matched[0]; inst=instances[d['instance']][1]
            lg={'n':d['vessels'],'H':d['H_nominal'],'A':d['arrivals'],
                'feas':[tuple(int(k) for k in r) for r in [list(p.keys()) for p in d['compatible_processing_times']]],
                'P':[{int(k):float(v) for k,v in p.items()} for p in d['compatible_processing_times']],
                'seed':d['seed'],'rho':d['rho_target']}
            for alg in ALGS:
                for rep in (0,1):
                    o,seq,calls,s=run_method(alg,lg,rep)
                    old=index[(d['instance'],alg,rep)]
                    assert math.isclose(o,float(old['objective']),abs_tol=1e-7,rel_tol=1e-12)
                    audit,sch=stage4.independent_check(lg,inst,seq,o)
                    assert audit['ok'] and audit['within_U'] and calls==528
                    replay.append(dict(instance=d['instance'],method=alg,replicate=rep,
                                       objective=o,matched=1))
    assert len(replay)==288
    savecsv(ROOT/'results'/'replay_288.csv',replay)
    version=dict(status='PASS',n_instances=len(instances),n_schedules=len(rows),
                 independent_families=12,n_best_schedules_reverified=len(savedbest),
                 deterministic_replays=len(replay),service_profiles_per_block=1,
                 family_blocks=len(profiles),algorithms=list(ALGS),
                 theory_note='homogeneous Poisson conditional N=n is uniform, NHPP conditional n uses nonuniform F',
                 limitations=['synthetic controlled arrival shapes, no real port calibration',
                              'NHPP conditional on fixed n, no variation in call count',
                              '12 independent generator seeds, rest are crossed controls',
                              'GA/SA/MSLS settings fixed and not globally tuned'])
    (ROOT/'results'/'INDEPENDENT_AUDIT.json').write_text(json.dumps(version,indent=2)+'\n')
    print('STAGE6 FULL AUDIT PASS:',len(rows),'validated runs',len(savedbest),'best schedules',len(replay),'replays')
    print('comparisons:')
    for c in comps:print(c)
    print('arrival process effects:')
    for c in out:print(c)
    return comps,out

if __name__=='__main__':run()
