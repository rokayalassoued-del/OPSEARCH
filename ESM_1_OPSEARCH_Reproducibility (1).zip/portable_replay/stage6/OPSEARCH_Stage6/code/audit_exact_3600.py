#!/usr/bin/env python3
"""Independent verification of exact MILP 3600-second outputs; never modifies archived results."""
import json,sys,csv,math,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
S2=ROOT/'evidence'
SRC=S2/'milp_3600_results'
sys.path.insert(0,str(ROOT/'dependencies/stage4/code/dependencies'))
from canonical_exact_milp import Instance,evaluate_schedule
names=[f'S{i}' for i in range(1,7)]+[f'M{i}' for i in range(1,5)]
rows=[]
for name in names:
    p=S2/'stage2_new_inputs'/f'{name}.json';inp=json.loads(p.read_text())
    d=json.loads((SRC/f'{name}_canonical_3600s.json').read_text())
    assert hashlib.sha256(p.read_bytes()).hexdigest()==d['input_sha256']
    can=Instance(tuple(float(v['arrival']) for v in inp['vessels']),
                 tuple({int(i):float(x) for i,x in v['p_by_berth'].items()} for v in inp['vessels']),name)
    val=evaluate_schedule(can,d['schedule']) if d['schedule'] else {'ok':False}
    assert val['ok'] and val['within_U']
    assert math.isclose(val['objective'],d['objective'],abs_tol=1e-5)
    obj=d['objective'];bound=d['dual_bound']
    gap=None if bound is None else 100*(obj-bound)/obj
    isopt=(d['status']==0)
    rows.append(dict(instance=name,vessels=can.n,source='NEW_VALIDATION',
                     status='PROVEN_OPTIMAL' if isopt else 'TIME_LIMIT_FEASIBLE',
                     objective=obj,lower_bound=bound,
                     objective_gap_pct=gap,solver_native_mip_gap=d['mip_gap'],
                     runtime_seconds=d['elapsed_seconds'],
                     max_completion=val['max_completion'],completion_bound_U=can.U,
                     objective_recalculated=val['objective'],schedule_valid=1,
                     input_sha256=d['input_sha256']))
with open(ROOT/'results'/'MILP_ALL10_INDEPENDENT_3600_AUDIT.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
assert sum(r['status']=='PROVEN_OPTIMAL' for r in rows)==9
assert rows[-1]['status']=='TIME_LIMIT_FEASIBLE'
print('Exact benchmark all10 independently verified:',sum(r['status']=='PROVEN_OPTIMAL' for r in rows),'optimal,',len(rows)-sum(r['status']=='PROVEN_OPTIMAL' for r in rows),'time limit')
print('M4:',rows[-1])
