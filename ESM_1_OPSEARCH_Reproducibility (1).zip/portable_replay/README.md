# Portable OPSEARCH code and cold replay

The six historical research archives in `../linked_reproducibility_packages/` remain unchanged.
The `stage3/` - `stage6/` trees here are distinct *portable copies*, preserving experiment formulas and archived random seeds. Absolute workspace-path dependencies are replaced only in these copies. This is not a claim that the historical MILP inputs or hardware have been reconstructed.

## Requirements

The independent cold replay was tested with Python 3.13.5, NumPy 2.3.5 and SciPy 1.17.0 (`python -m pip install -r requirements.txt`). Exact reproduction of floating-point values across all versions/platforms is not guaranteed. Runtime comparisons require recording the executing host.

## Independent cold replay (run outside original workspace)

    python replay_selected.py

`replay_selected.py` executes two runs each of archived PSO, GA, SA and multi-start local search on L1 (528 evaluations/method); verifies feasibility and compares the scores to preserved reference records. It also executes Stage 5's bundled 12-case replay and Stage 6's saved exact-solution feasibility audit; these commands do not rerun the one-hour MILP optimization.

For all Stage-3 instances and 30 seeds (computationally more expensive), from `stage3/`:

    python code/compare_heuristics.py --names L1 L2 L3 L4 L5 L6 --runs 30

New results are written under `stage3/replay_results/`, leaving the archived `stage3/results/` intact. The Stage-3 main runner must not be confused with original 2019/earlier historical data; newly generated S/M datasets reside under `stage3/data_new/`.

The Stage-4/5/6 folders contain their archived data, independently checked schedules and scripts. Their optional full experimental runners can consume substantial compute. The Stage-4 full audit and Stage-5/6 targeted cold replay check are independent of the full optimization runtimes. Existing archived outputs are preserved in their original nested ZIPs.
