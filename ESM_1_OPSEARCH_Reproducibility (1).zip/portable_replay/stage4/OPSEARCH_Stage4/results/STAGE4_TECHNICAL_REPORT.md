# OPSEARCH — Stage 4 computational verification report

## Integrity and scope
- **54 controlled synthetic stress cases** across 3 vessel counts × 3 workload targets × 2 arrival windows × 3 base seed families.
- **6480 final schedules independently validated** across PSO, GA, SA, and MSLS (30 runs/method/case; 528 objective evaluations/run).
- **2520 PSO parameter-sensitivity schedules validated**, with constant 528-evaluation budgets.
- **432 runs independently regenerated** with exactly matching objective values, seeds, input hashes, and feasible schedules.
- All 54 input files passed SHA-256, arrival range, and workload intensity formula checks.
- Legacy decoder and PSO trajectory were preserved for the fixed-budget comparison. No alterations to submitted manuscript or 2019 original instance tables.

## Synthetic generation and what the factors mean
- **Workload intensity** = sum_j min_i p_ij / (13 H), varied by uniformly scaling all compatible processing durations (including fixed ancillary times). This *synthetic control* is not observed berth utilization.
- **Arrival-window fraction** 0.20 or 0.60 scales vessel release times; it models arrival concentration, not traffic density measured at a real port.
- Vessel features, compatibility sets, and relative berth processing-time patterns come from the original archived generator. All new inputs are labelled derived synthetic cases.
- The nominal H is used only to scale the instance generator. No hard c_j <= H deadline is imposed. Completed schedules meet the independently derived upper bound U.

## Main comparative findings
- Lowest mean objective by instance (54 cases): {'PSO': 52, 'GA': 2}.
- Cases where PSO has a lower sample mean than each comparator: {'GA': 52, 'SA': 54, 'MSLS': 54}.
- All four methods share exactly 528 objective evaluations per run, but do not necessarily share execution time.

### Overall measured wall-clock runtime per 528-evaluation run
| method | mean_runtime_s | median_runtime_s |
| --- | --- | --- |
| PSO | 0.0702 | 0.0716 |
| GA | 0.0883 | 0.0867 |
| SA | 0.0592 | 0.0563 |
| MSLS | 0.0594 | 0.0574 |

### Blocked exploratory inference (independent seed families, n=3)
| comparison | mean_PSO_relative_advantage_pct | blocks_in_favor_PSO | exact_sign_flip_two_sided_p | holm_3_tests_p |
| --- | --- | --- | --- | --- |
| PSO vs GA | 1.774 | 3 | 0.25 | 0.75 |
| PSO vs SA | 4.575 | 3 | 0.25 | 0.75 |
| PSO vs MSLS | 9.669 | 3 | 0.25 | 0.75 |

**Warning:** The same base seed is reused across correlated factorial treatments and sizes. Only three seed families are independent. Sign-flip p-values with three blocks have very low resolution; this study does not support general statistical superiority claims.

## Parameter sensitivity
- 24 controlled conditions (2 sizes × 3 workloads × 2 arrival windows × 2 seed families), seven variants, 15 independent repetitions each.
- Standard archived PSO settings: swarm 10, 45 iterations, c1=1.7, c2=2.0, periodic 15-trial local search.
- Increasing the swarm size or shifting c1 and c2 changes performance. No configuration is designated globally best or optimal based on these exploratory cases.
- Removing local search reallocates the same evaluation budget into more PSO particle updates, so the sensitivity analysis is a budget-matched **package comparison**, not an isolated test of the local-search component.

| variant | mean_improvement_pct | cases_improved |
| --- | --- | --- |
| cognitive_dominant | +1.209 | 20/24 |
| no_local_search | +1.363 | 18/24 |
| balanced | +0.382 | 15/24 |
| swarm_6 | +0.263 | 13/24 |
| swarm_16 | -0.595 | 6/24 |
| social_dominant | -0.783 | 7/24 |

## Exploratory time-matched pilot
- 384 runs on 12 conditions, equal hard wall-clock cutoff of 0.35 s per method and replicate.
- All four streaming implementations checked against Stage 3 full-run values at 528 objective evaluations.
- Only evaluations completed before the deadline contribute; objective and schedule independently verified.
- Lowest average objective in these 12 cases: {'PSO': 12}.
- **Limitation:** single base seed per condition, very short run time, shared machine with concurrent MILP runs; this pilot is diagnostic only.

## Outstanding scientific decisions
1. The historical vessel-level S1–M4 instances were not recovered. The present S/M exact datasets remain separate *new* validation examples.
2. Independent real-world or industry-calibrated test cases are still required to justify external operational relevance.
3. The separate 3600 s MILP benchmark has now certified M3 at 1290.629639 after 2192.05 s. M4 remains unresolved; no optimality claim is made for M4 or the Stage4 large synthetic stress cases.
4. Any PSO tuning choice requires held-out instance families or nested tuning/validation. Stage4 PSO is archived unchanged.
5. A stronger factorial generalization study should use more distinct base seed families and independent distributions/arrival processes.
6. Manuscript and reviewer responses remain frozen until the broader audit is complete.

## Files
- `code/`: source of generation, algorithms, independent verification, streamed time-budget comparison, statistical analysis and replay checks.
- `data/`: 54 fully specified synthetic berth-allocation scenarios, each with a SHA-256 recorded in the manifest.
- `results/all_runs.csv`: 6,480 disaggregated objective scores, seeds, run-times, checksums and feasibility statuses.
- `results/sensitivity_runs.csv`: 2,520 verified PSO parameter-sensitivity observations.
- `results/replayed_run_audit.csv`: 432 reproduced original Stage4 sample runs.
- `results/FULL_INTEGRITY_VERDICT.json`: independent end-to-end audit of 9,384 schedules across experiments.
- `results/paired_case_means.csv`, `factorial_condition_summary.csv`, `blocked_inference.csv`: effect estimates and cautious inference.
- `results/wallclock_runs.csv`: pilot best-so-far values under equal real elapsed time if complete.

## Reproduction
From the existing Stage2/Stage3 workspace in this environment:
```bash
python code/stage4.py --runs 30
python code/sensitivity.py
python code/replay_audit.py
python code/analyze.py
python code/time_matched.py --budget 0.35 --reps 8
python code/final_report.py
```
The necessary Stage2/Stage3 source modules are included in `code/dependencies/`; Stage4 scripts use paths relative to this package. Objective scores and instance hashes reproduce exactly; wall-clock durations remain environment-dependent. Re-running scripts overwrites outputs, so make a working copy first.
