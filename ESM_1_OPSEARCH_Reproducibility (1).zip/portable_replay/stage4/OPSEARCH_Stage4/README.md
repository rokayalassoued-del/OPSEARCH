# OPSEARCH — Stage 4 verified computational experiments

Research validation package, 2026-10-31. No manuscript or reviewer reply edited.

## Outputs

- **54 synthetic controlled test instances**; 3 vessel counts × 3 nominal workload targets × 2 arrival fractions × 3 seed families.
- **6,480** feasible schedules from PSO, GA, SA and multi-start local search, 30 independent runs per method/case, 528 objective evaluations each.
- **2,520** feasible PSO parameter sensitivity runs (7 variants × 24 cases × 15 repetitions).
- **384** feasible wall-clock-matched runs, each with a 0.35-second deadline (4 methods × 12 cases × 8 repetitions). Pilot only.
- **432** algorithm runs independently replayed with matching objectives and saved random seeds.
- **216** stored best schedules independently audited for feasibility.
- **54/54** generated input datasets have reproducible SHA-256 checksums and correct workload calculations.
- **9,384** distinct tested schedules overall, all passing the independent validator.

## Main results

Archived PSO has the smallest 30-run mean objective in 52/54 synthetic cases, GA in 2/54. Sample-average PSO relative advantages: 1.77% vs GA, 4.58% vs SA, 9.67% vs MSLS. Across the three underlying independent seed families, exploratory sign-flip p=0.25 (Holm=0.75), therefore no statistically significant general superiority claim is made.

The parameter-sensitivity experiments show some alternatives can outperform archived PSO. Time-matched pilot favored PSO in all 12 sampled conditions but has limited scope and coincident solver workloads.

## Read first

- `results/STAGE4_TECHNICAL_REPORT.md`: comprehensive methodology, findings, limitations.
- `results/FULL_INTEGRITY_VERDICT.json`: independent cross-file audit.
- `results/audit_summary.json`: factorial verification and method winners.
- `results/blocked_inference.csv`: conservative exploratory statistical tests.
- `results/label_normalization_audit.json`: traceable metadata change from display label R114 to R115 for true rho 1.15. Numerical objective values were *not* modified. The original labels and source CSVs are preserved in a ZIP under `logs/`.

## Computational trace and reproducibility

Sources in `code/` and its `dependencies/` include the archived synthetic generator/PSO, Stage 3 GA/SA/MSLS, independent MILP schedule validation, stress-case generator, sensitivity variants, time-matched streaming algorithms, independent replay, and full-integrity checks. The scripts use paths relative to this package. Required Python dependencies: numpy, scipy, matplotlib (for figures), standard Python library.

From this package's root, run:

```
python code/full_validation.py
python code/replay_audit.py
python code/analyze.py
python code/final_report.py
```

To rerun optimization on a *copy* of the package (these overwrite output files):

```
python code/stage4.py --runs 30
python code/sensitivity.py
python code/time_matched.py --budget 0.35 --reps 8
```

Deterministic objective and seed values should reproduce; wallclock runtimes, trial objective scores under strict time budgets, and OS process scheduling are not deterministic.

## Limitations

The 54 cases are not 54 independent data-generating families, since there are only three original seeds shared across controlled conditions. Workload ratios are synthetic min-service/H indicators and are **not** observed berth utilization. No fixed completion deadline c_j <= H is imposed. This package **does not** recover historical vessel-level small/medium S1–M4 inputs; the separate Stage 2 exact instances are new validation cases.

The independently certified exact 3,600-second benchmark for new Stage 2 instance M3 is copied to `linked_exact/`. M4 was still unresolved at the time of this package's audit. This does not claim optimal solutions for the Stage 4 large instances.
