"""Exploratory equal wall-clock, continuous best-so-far algorithm comparison.
Each objective evaluation is timestamped. Only evaluations completed before deadline
count. Archived PSO trajectory, Stage 3 GA/SA/MSLS logic, independent validation.
This is a new streaming implementation and tested against Stage 3 528-eval results.
"""
import time,random,math,statistics,sys,csv,json,hashlib
from collections import defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'code'))
import stage4
import compare_heuristics as s3
import synthetic_pso_experiments as legacy

def stream_pso(inst,rep):
 n=inst['n']; rng=random.Random(100000+inst['seed']*100+rep)
 X=[[rng.random() for _ in range(n)] for _ in range(10)]
 V=[[rng.uniform(-1,1) for _ in range(n)] for _ in range(10)]
 pb=[x[:] for x in X];scores=[];gb=None;gscore=math.inf
 visible_score=math.inf;visible_seq=None
 for xp in X:
  score,seq=legacy.decode_keys(inst,xp);scores.append(score)
  if score<gscore:gscore=score;gb=xp[:]
  if score<visible_score:visible_score=score;visible_seq=seq[:]
  yield visible_score,visible_seq
 for it in range(45):
  w=.9-.5*it/44
  for k in range(10):
   xp,vp,pk=X[k],V[k],pb[k]
   for j in range(n):
    v=w*vp[j]+1.7*rng.random()*(pk[j]-xp[j])+2.0*rng.random()*(gb[j]-xp[j])
    v=max(-4.,min(4.,v));vp[j]=v;xp[j]+=v
   score,seq=legacy.decode_keys(inst,xp)
   if score<scores[k]:
    scores[k]=score;pb[k]=xp[:]
    if score<gscore:gscore=score;gb=xp[:]
   if score<visible_score:visible_score=score;visible_seq=seq[:]
   yield visible_score,visible_seq
  if it%10==9:
   score,seq=legacy.decode_keys(inst,gb)
   yield visible_score,visible_seq
   locscore=score;locseq=seq[:]
   score,_=legacy.decode_keys(inst,legacy.seq_to_keys(locseq))
   yield visible_score,visible_seq
   for _ in range(15):
    cand=locseq[:]
    if rng.random()<.5:
     a,b=rng.sample(range(n),2);cand[a],cand[b]=cand[b],cand[a]
    else:
     a,b=rng.sample(range(n),2);v=cand.pop(a);cand.insert(b,v)
    score,_=legacy.decode_keys(inst,legacy.seq_to_keys(cand))
    if score<locscore:locscore,locseq=score,cand
    if score<visible_score:visible_score=score;visible_seq=cand[:]
    yield visible_score,visible_seq
   if locscore < gscore:gscore,gb=locscore,legacy.seq_to_keys(locseq)

def stream_ga(inst,rng):
 n=inst['n']; pop=[];bscore=math.inf;bseq=None
 for _ in range(24):
  seq=rng.sample(range(n),n);score=legacy.decode_keys(inst,legacy.seq_to_keys(seq))[0]
  pop.append((score,seq))
  if score<bscore:bscore,bseq=score,seq[:]
  yield bscore,bseq
 def tournament():return min(rng.sample(pop,3),key=lambda v:v[0])[1]
 for _ in range(21):
  children=[]
  for _ in range(24):
   mom,dad=tournament(),tournament()
   child=s3.crossover(mom,dad,rng) if rng.random()<.9 else mom[:]
   if rng.random()<.35:child=s3.mutate(child,rng)
   score=legacy.decode_keys(inst,legacy.seq_to_keys(child))[0]
   children.append((score,child))
   if score<bscore:bscore,bseq=score,child[:]
   yield bscore,bseq
  pop=sorted(pop+children,key=lambda v:v[0])[:24]

def stream_sa(inst,rng):
 n=inst['n'];cur=rng.sample(range(n),n);score=legacy.decode_keys(inst,legacy.seq_to_keys(cur))[0]
 bs=score;bseq=cur[:];t0=max(1.,.4*score/n)
 yield bs,bseq
 for k in range(527):
  if (k+1)%132==0:
   cur=rng.sample(range(n),n);score=legacy.decode_keys(inst,legacy.seq_to_keys(cur))[0]
  else:
   cand=s3.mutate(cur,rng);new=legacy.decode_keys(inst,legacy.seq_to_keys(cand))[0]
   temp=max(1e-6,t0*(.002**(k/526)))
   if new<=score or rng.random()<math.exp(min(0.,(score-new)/temp)):
    cur,score=cand,new
  if score<bs:bs,bseq=score,cur[:]
  yield bs,bseq

def stream_msls(inst,rng):
 n=inst['n'];seq=rng.sample(range(n),n);score=legacy.decode_keys(inst,legacy.seq_to_keys(seq))[0]
 bs=score;bseq=seq[:]
 yield bs,bseq
 for k in range(527):
  if (k+1)%66==0:
   seq=rng.sample(range(n),n);score=legacy.decode_keys(inst,legacy.seq_to_keys(seq))[0]
  else:
   cand=s3.mutate(seq,rng);value=legacy.decode_keys(inst,legacy.seq_to_keys(cand))[0]
   if value<score-1e-10:seq,score=cand,value
  if score<bs:bs,bseq=score,seq[:]
  yield bs,bseq

def mkstream(method,inst,rep,base=320000000):
 if method=='PSO':return stream_pso(inst,rep)
 rng=random.Random(base+inst['seed']*1000+rep*101+{'GA':1,'SA':2,'MSLS':3}[method])
 return {'GA':stream_ga,'SA':stream_sa,'MSLS':stream_msls}[method](inst,rng)

def unit_test():
 for n in (60,120):
  _,inst,can,_,_=stage4.build_case(n,.9,.2,17011)
  for method in ('PSO','GA','SA','MSLS'):
   rep=0
   stream=mkstream(method,inst,rep)
   values=[x for x in stream]
   assert len(values)==528,(method,len(values))
   end=values[-1][0];seq=values[-1][1]
   if method=='PSO':reference=s3.pso_archived(inst,rep)
   else:
    # same seed as streaming. No accidental change in GA/SA/MSLS RNG sequence.
    rng=random.Random(320000000+inst['seed']*1000+rep*101+{'GA':1,'SA':2,'MSLS':3}[method])
    reference={'GA':s3.ga,'SA':s3.sa,'MSLS':s3.msls_safe}[method](inst,rng)
   assert math.isclose(end,reference[0],abs_tol=1e-6,rel_tol=1e-11),(method,n,end,reference[0])
   stage4.independent_check(inst,can,seq,end)
   print('unit',n,method,'PASS',end,flush=True)

def run(budget_s=.35,reps=8):
 unit_test()
 records=[];trace=[];start=time.perf_counter()
 # 12 cases: 2 n x 3 load x 2 arrivals, one independent seed (pilot only)
 for n in (60,120):
  for w in (.65,.9,1.15):
   for f in (.2,.6):
    name,inst,can,sha,_=stage4.build_case(n,w,f,17011)
    for method in ('PSO','GA','SA','MSLS'):
     for rep in range(reps):
      best=math.inf;bestseq=None;evals=0;restart=0
      t0=time.perf_counter()
      while True:
       for score,seq in mkstream(method,inst,rep+1000*restart):
        elapsed=time.perf_counter()-t0
        if elapsed>budget_s:break
        evals+=1
        if score<best:best,bestseq=score,seq[:]
       if time.perf_counter()-t0>=budget_s:break
       restart+=1
      wall=time.perf_counter()-t0
      assert bestseq is not None
      audit,_=stage4.independent_check(inst,can,bestseq,best)
      records.append(dict(instance=name,n=n,rho=w,arrival_fraction=f,method=method,replicate=rep,
                          budget_s=budget_s,wall_s=wall,evaluations_completed_before_deadline=evals,
                          completed_restarts=restart,best=best,verified=audit['ok'],sha256=sha))
    print('time-matched',name,'done',len(records),'runs','elapsed',round(time.perf_counter()-start,1),flush=True)
    stage4.write_csv(ROOT/'results'/'wallclock_runs.csv',records)
 # Note: output is based on true wallclock time, with 1 eval precision.
 summary=[];by=defaultdict(list)
 for r in records:by[(r['instance'],r['method'])].append(r)
 for (name,method),rr in sorted(by.items()):
  vals=[r['best'] for r in rr]
  summary.append(dict(instance=name,method=method,runs=len(rr),mean=statistics.mean(vals),best=min(vals),
        std=statistics.stdev(vals),avg_evaluations_before_deadline=statistics.mean(r['evaluations_completed_before_deadline'] for r in rr),
        avg_real_wall_time=statistics.mean(r['wall_s'] for r in rr)))
 stage4.write_csv(ROOT/'results'/'wallclock_summary.csv',summary)
 (ROOT/'results'/'wallclock_metadata.json').write_text(json.dumps(dict(status='COMPLETE',cases=12,runs=len(records),budget_s=budget_s,
    n_replicates=reps,elapsed_s=time.perf_counter()-start,
    note='All methods given same wallclock deadline within each case. One complete evaluation timestamp precision; stream tested against archived fixed-budget algorithm. Results are preliminary, only one base seed per factorial condition and a potentially noisy shared CPU environment.'),indent=2))
 print('DONE wallclock',len(records),'runs',flush=True)
if __name__=='__main__':
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--unit-only',action='store_true');ap.add_argument('--budget',type=float,default=.35);ap.add_argument('--reps',type=int,default=8)
 args=ap.parse_args()
 if args.unit_only:unit_test()
 else:run(args.budget,args.reps)
