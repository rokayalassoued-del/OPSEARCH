"""Post-hoc audited Stage4 analysis. Full-factorial fixed effects, independent 9 block sensitivity."""
import csv,json,math,itertools,hashlib,statistics
from pathlib import Path
from collections import defaultdict,Counter
import numpy as np
ROOT=Path(__file__).resolve().parent.parent
RESULTS=ROOT/'results'

def read(name):
 with (RESULTS/name).open(newline='') as f:return list(csv.DictReader(f))
def write(name,rows):
 if not rows:return
 with (RESULTS/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def main():
 meta=json.loads((RESULTS/'metadata.json').read_text())
 assert meta['status']=='COMPLETE'
 runs=read('all_runs.csv');manifest=read('instance_manifest.csv');summary=read('summary.csv')
 assert len(runs)==54*4*30 and len(manifest)==54 and len(summary)==54*4
 assert len(set((r['instance'],r['algorithm'],r['replicate']) for r in runs))==len(runs)
 assert all(int(r['evals'])==528 and r['feasible']=='True' and float(r['runtime_s'])>0 for r in runs)
 assert set(r['algorithm'] for r in runs)=={'PSO','GA','SA','MSLS'}
 for r in manifest:
  blob=(ROOT/'data'/f"{r['instance']}.json").read_bytes()
  assert hashlib.sha256(blob).hexdigest()==r['sha256'],('input drift',r['instance'])
  x=json.loads(blob)
  assert abs(float(x['intensity_observed'])-float(r['workload']))<1e-10
  assert max(x['arrivals'])<=x['H_nominal']*x['arrival_fraction']+1e-8
  assert abs(sum(min(p.values()) for p in x['p_by_berth'])/(x['berths']*x['H_nominal'])-float(r['workload']))<1e-10
 by=defaultdict(dict)
 for s in summary:by[s['instance']][s['method']]=s
 assert all(len(v)==4 for v in by.values())
 case=[]
 for id,rec in sorted(by.items()):
  pp=rec['PSO'];x={'instance':id,'n':int(pp['n']),'rho':float(pp['rho']),'arrival_fraction':float(pp['arrival_fraction'])}
  for alg in ('PSO','GA','SA','MSLS'):
   x[f'{alg}_mean']=float(rec[alg]['mean']);x[f'{alg}_std']=float(rec[alg]['std']);x[f'{alg}_run_seconds']=float(rec[alg]['mean_runtime_s'])
  for alg in ('GA','SA','MSLS'):
   x[f'PSO_advantage_over_{alg}_pct']=100*(x[f'{alg}_mean']-x['PSO_mean'])/x[f'{alg}_mean']
  x['mean_winner']=min(('PSO','GA','SA','MSLS'),key=lambda m:x[f'{m}_mean'])
  case.append(x)
 write('paired_case_means.csv',case)
 # Aggregate by factor strata, with each instance as descriptive unit (paired design)
 grouped=defaultdict(list)
 for x in case:grouped[(x['n'],x['rho'],x['arrival_fraction'])].append(x)
 condition=[]
 for (n,rho,arr),cs in sorted(grouped.items()):
  item=dict(n=n,rho=rho,arrival_fraction=arr,independent_instances=len(cs))
  for m in ('PSO','GA','SA','MSLS'):item[m+'_mean_per_vessel']=statistics.mean(z[m+'_mean']/n for z in cs)
  for m in ('GA','SA','MSLS'):item['PSO_adv_'+m+'_pct']=statistics.mean(z['PSO_advantage_over_'+m+'_pct'] for z in cs)
  condition.append(item)
 write('factorial_condition_summary.csv',condition)
 # Conservatively use 3 independent seed families, not 54 independent cases.
 # The same seed is reused across sizes/treatments; within-seed outcomes are correlated.
 # Only 3 independent blocks -> no high-powered inferential claim.
 block=defaultdict(lambda:defaultdict(list))
 for x in case:
  seed=int(x['instance'].split('_K')[-1])
  for m in ('GA','SA','MSLS'):
   block[seed][m].append(x['PSO_advantage_over_'+m+'_pct'])
 assert len(block)==3 and all(len(vals)==18 for b in block.values() for vals in b.values())
 outcomes=[]
 for comp in ('GA','SA','MSLS'):
  d=np.array([statistics.mean(v[comp]) for key,v in sorted(block.items())]);obs=float(d.mean())
  # exact two-sided sign-flip test over the nine independent block contrasts
  dist=[]
  for signs in itertools.product((-1,1),repeat=len(d)):
   dist.append(float((d*np.array(signs)).mean()))
  p=sum(abs(z)>=abs(obs)-1e-12 for z in dist)/len(dist)
  # descriptive percentile interval across three seed families (very imprecise)
  rng=np.random.default_rng(20261031+('GA','SA','MSLS').index(comp))
  boots=np.mean(d[rng.integers(0,len(d),size=(15000,len(d)))],axis=1)
  lo,hi=np.quantile(boots,[.025,.975]);
  outcomes.append({'comparison':'PSO vs '+comp,'block_count':len(d),'mean_PSO_relative_advantage_pct':obs,
                   'blocks_in_favor_PSO':int((d>0).sum()),'exact_sign_flip_two_sided_p':p,
                   'block_bootstrap_95CI_low_pct':lo,'block_bootstrap_95CI_high_pct':hi})
 # Holm adjust 3 family tests
 order=sorted(range(3),key=lambda i:outcomes[i]['exact_sign_flip_two_sided_p'])
 h=0
 for rank,i in enumerate(order):
  h=max(h,min(1.,outcomes[i]['exact_sign_flip_two_sided_p']*(3-rank)))
  outcomes[i]['holm_3_tests_p']=h
 write('blocked_inference.csv',outcomes)
 # 2x3x3 factors but 3 underlying seeds: descriptive only
 global_meth=[]
 for m in ('PSO','GA','SA','MSLS'):
  rs=[r for r in runs if r['algorithm']==m]
  global_meth.append(dict(method=m,total_runs=len(rs),mean_runtime_s=statistics.mean(float(r['runtime_s']) for r in rs),
                         median_runtime_s=statistics.median(float(r['runtime_s']) for r in rs),
                         mean_objective_per_vessel=statistics.mean(float(r['objective'])/int(r['n']) for r in rs),
                         min_runtime_s=min(float(r['runtime_s']) for r in rs),max_runtime_s=max(float(r['runtime_s']) for r in rs)))
 write('method_runtime_summary.csv',global_meth)
 wins=Counter(x['mean_winner'] for x in case)
 audit={'validated_runs':len(runs),'datasets':len(manifest),'methods':4,'repetitions':30,
        'all_objective_evaluations_528':True,'schedule_passes':len(runs),
        'all_file_sha256_checks_passed':True,'all_54_workload_definitions_verified':True,
        'case_level_mean_winners':dict(wins),'PSO_vs_each_method_cases_positive':{m:sum(x['PSO_advantage_over_'+m+'_pct']>0 for x in case) for m in ('GA','SA','MSLS')},
        'cluster_note':'3 independent seed families; 18 correlated size/intensity/arrival treatment cells per seed. Block inference uses exact sign flips over the three independent seed families.',
        'testing_note':'Exploratory. Only 3 independent base seed families, low inferential power; no claim of statistical significance. All synthetic; original H is not a completion deadline.'}
 (RESULTS/'audit_summary.json').write_text(json.dumps(audit,indent=2))
 print('ALL CHECKS PASSED',json.dumps(audit,indent=2),flush=True)
 print('BLOCKED STATS',outcomes,flush=True)
if __name__=='__main__':main()
