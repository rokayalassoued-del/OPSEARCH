"""Final cross-file integrity validation for OPSEARCH Stage4 (no optimization reruns)."""
import csv,math,json,hashlib,collections,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(ROOT/'code'/'dependencies'))
from canonical_exact_milp import Instance,evaluate_schedule
D=ROOT/'data';R=ROOT/'results'
def csvread(p):
 with (R/p).open(newline='') as f:return list(csv.DictReader(f))
def main():
 manifest=csvread('instance_manifest.csv')
 mapping={r['instance']:r for r in manifest}
 assert len(mapping)==54
 for k,r in mapping.items():
  p=D/(k+'.json')
  assert p.exists(),p
  assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256']
  x=json.loads(p.read_text())
  assert x['instance']==k and abs(x['intensity_target']-float(r['workload']))<1e-10
  assert x['n']==int(r['size']) and len(x['arrivals'])==x['n']
  assert abs(sum(min(t.values()) for t in x['p_by_berth'])/(x['berths']*x['H_nominal'])-x['intensity_target'])<1e-9
 raw=csvread('all_runs.csv')
 assert len(raw)==6480
 by=collections.Counter(r['instance'] for r in raw)
 assert set(by)==set(mapping) and all(v==120 for v in by.values())
 assert len({(r['instance'],r['algorithm'],r['replicate']) for r in raw})==6480
 assert all(int(r['evals'])==528 and r['feasible']=='True' and r['input_sha256']==mapping[r['instance']]['sha256'] for r in raw)
 sens=csvread('sensitivity_runs.csv');assert len(sens)==2520
 assert all(r['sha256']==mapping[r['instance']]['sha256'] and r['feasible']=='True' and int(r['evaluations'])==528 for r in sens)
 wall=csvread('wallclock_runs.csv');assert len(wall)==384
 assert all(r['sha256']==mapping[r['instance']]['sha256'] and r['verified']=='True' and float(r['best'])>0 and float(r['budget_s'])==.35 for r in wall)
 assert all(float(r['wall_s'])>=.35 for r in wall)
 replays=csvread('replayed_run_audit.csv');assert len(replays)==432
 assert all(r['valid']=='True' and abs(float(r['difference']))<1e-7 for r in replays)
 best_schedules=[]
 for l in (R/'best_schedules.jsonl').read_text().splitlines():
  r=json.loads(l);name=r['instance']; x=json.loads((D/(name+'.json')).read_text())
  inst=Instance(tuple(x['arrivals']),tuple({int(i):float(t) for i,t in row.items()} for row in x['p_by_berth']),name)
  a=evaluate_schedule(inst,r['schedule'])
  assert a['ok'] and a['within_U']
  assert math.isclose(a['objective'],float(r['objective']),rel_tol=1e-10,abs_tol=1e-4)
  best_schedules.append((name,r['method']))
 assert len(best_schedules)==216 and len(set(best_schedules))==216
 verdict=dict(status='PASS',input_datasets_verified=54,raw_validated_runs=6480,sensitivity_validated_runs=2520,
              equal_time_validated_runs=384,independently_replayed_runs=432,
              saved_best_schedules_independently_validated=216,unique_run_keys=6480,
              total_unique_candidate_schedules_checked=9384,origin='controlled synthetic generator, 3 base seed families')
 (R/'FULL_INTEGRITY_VERDICT.json').write_text(json.dumps(verdict,indent=2))
 print(json.dumps(verdict,indent=2))
if __name__=='__main__':main()
