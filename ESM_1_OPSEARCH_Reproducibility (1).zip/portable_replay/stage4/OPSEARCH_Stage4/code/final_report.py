"""Source-grounded technical report. Requires completed and independently rechecked files."""
import csv,json,statistics,collections,math
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent;O=ROOT/'results'
def rd(file):return list(csv.DictReader((O/file).open()))
def table(rows,keys):
 ret=['| '+' | '.join(keys)+' |','| '+' | '.join(['---']*len(keys))+' |']
 for r in rows:ret.append('| '+' | '.join(str(r[k]) for k in keys)+' |')
 return '\n'.join(ret)
def main():
 x=json.loads((O/'audit_summary.json').read_text());meta=json.loads((O/'metadata.json').read_text());
 s=json.loads((O/'sensitivity_metadata.json').read_text());replay=json.loads((O/'replay_metadata.json').read_text());
 c=rd('paired_case_means.csv');method=rd('method_runtime_summary.csv');infer=rd('blocked_inference.csv');sens=rd('sensitivity_summary.csv')
 wall_meta=json.loads((O/'wallclock_metadata.json').read_text()) if (O/'wallclock_metadata.json').exists() else None
 lines=['# OPSEARCH — Stage 4 computational verification report',
        '', '## Integrity and scope',
        f'- **{meta["n_instances"]} controlled synthetic stress cases** across 3 vessel counts × 3 workload targets × 2 arrival windows × 3 base seed families.',
        f'- **{x["validated_runs"]} final schedules independently validated** across PSO, GA, SA, and MSLS (30 runs/method/case; 528 objective evaluations/run).',
        f'- **{s["n_runs"]} PSO parameter-sensitivity schedules validated**, with constant 528-evaluation budgets.',
        f'- **{replay["replayed"]} runs independently regenerated** with exactly matching objective values, seeds, input hashes, and feasible schedules.',
        '- All 54 input files passed SHA-256, arrival range, and workload intensity formula checks.',
        '- Legacy decoder and PSO trajectory were preserved for the fixed-budget comparison. No alterations to submitted manuscript or 2019 original instance tables.',
        '', '## Synthetic generation and what the factors mean',
        '- **Workload intensity** = sum_j min_i p_ij / (13 H), varied by uniformly scaling all compatible processing durations (including fixed ancillary times). This *synthetic control* is not observed berth utilization.',
        '- **Arrival-window fraction** 0.20 or 0.60 scales vessel release times; it models arrival concentration, not traffic density measured at a real port.',
        '- Vessel features, compatibility sets, and relative berth processing-time patterns come from the original archived generator. All new inputs are labelled derived synthetic cases.',
        '- The nominal H is used only to scale the instance generator. No hard c_j <= H deadline is imposed. Completed schedules meet the independently derived upper bound U.',
        '', '## Main comparative findings',
        f'- Lowest mean objective by instance (54 cases): {x["case_level_mean_winners"]}.',
        f'- Cases where PSO has a lower sample mean than each comparator: {x["PSO_vs_each_method_cases_positive"]}.',
        '- All four methods share exactly 528 objective evaluations per run, but do not necessarily share execution time.',
        '', '### Overall measured wall-clock runtime per 528-evaluation run',
        table([dict(method=r['method'],mean_runtime_s=f"{float(r['mean_runtime_s']):.4f}",median_runtime_s=f"{float(r['median_runtime_s']):.4f}") for r in method],['method','mean_runtime_s','median_runtime_s']),
        '', '### Blocked exploratory inference (independent seed families, n=3)',
        table([dict(comparison=r['comparison'],mean_PSO_relative_advantage_pct=f"{float(r['mean_PSO_relative_advantage_pct']):.3f}",
                  blocks_in_favor_PSO=r['blocks_in_favor_PSO'],exact_sign_flip_two_sided_p=r['exact_sign_flip_two_sided_p'],holm_3_tests_p=r['holm_3_tests_p']) for r in infer],
                  ['comparison','mean_PSO_relative_advantage_pct','blocks_in_favor_PSO','exact_sign_flip_two_sided_p','holm_3_tests_p']),
        '', '**Warning:** The same base seed is reused across correlated factorial treatments and sizes. Only three seed families are independent. Sign-flip p-values with three blocks have very low resolution; this study does not support general statistical superiority claims.',
        '', '## Parameter sensitivity',
        '- 24 controlled conditions (2 sizes × 3 workloads × 2 arrival windows × 2 seed families), seven variants, 15 independent repetitions each.',
        '- Standard archived PSO settings: swarm 10, 45 iterations, c1=1.7, c2=2.0, periodic 15-trial local search.',
        '- Increasing the swarm size or shifting c1 and c2 changes performance. No configuration is designated globally best or optimal based on these exploratory cases.',
        '- Removing local search reallocates the same evaluation budget into more PSO particle updates, so the sensitivity analysis is a budget-matched **package comparison**, not an isolated test of the local-search component.',
        ]
 groups=collections.defaultdict(dict)
 for r in sens:groups[r['instance']][r['variant']]=float(r['mean'])
 sensrows=[]
 for v in ['cognitive_dominant','no_local_search','balanced','swarm_6','swarm_16','social_dominant']:
  diffs=[100*(d['archived']-d[v])/d['archived'] for d in groups.values()]
  sensrows.append(dict(variant=v,mean_improvement_pct=f'{statistics.mean(diffs):+.3f}',cases_improved=f'{sum(z>0 for z in diffs)}/{len(diffs)}'))
 lines.extend(['',table(sensrows,['variant','mean_improvement_pct','cases_improved'])])
 if wall_meta:
  w=rd('wallclock_summary.csv');by=collections.defaultdict(dict)
  for r in w:by[r['instance']][r['method']]=float(r['mean'])
  wins=collections.Counter(min(dic,key=dic.get) for dic in by.values())
  lines.extend(['','## Exploratory time-matched pilot',
                f'- {wall_meta["runs"]} runs on {wall_meta["cases"]} conditions, equal hard wall-clock cutoff of {wall_meta["budget_s"]} s per method and replicate.',
                '- All four streaming implementations checked against Stage 3 full-run values at 528 objective evaluations.',
                '- Only evaluations completed before the deadline contribute; objective and schedule independently verified.',
                f'- Lowest average objective in these 12 cases: {dict(wins)}.',
                '- **Limitation:** single base seed per condition, very short run time, shared machine with concurrent MILP runs; this pilot is diagnostic only.'])
 lines.extend(['','## Outstanding scientific decisions',
               '1. The historical vessel-level S1–M4 instances were not recovered. The present S/M exact datasets remain separate *new* validation examples.',
               '2. Independent real-world or industry-calibrated test cases are still required to justify external operational relevance.',
               '3. The separate 3600 s MILP benchmark has now certified M3 at 1290.629639 after 2192.05 s. M4 remains unresolved; no optimality claim is made for M4 or the Stage4 large synthetic stress cases.',
               '4. Any PSO tuning choice requires held-out instance families or nested tuning/validation. Stage4 PSO is archived unchanged.',
               '5. A stronger factorial generalization study should use more distinct base seed families and independent distributions/arrival processes.',
               '6. Manuscript and reviewer responses remain frozen until the broader audit is complete.',
               '', '## Files',
               '- `code/`: source of generation, algorithms, independent verification, streamed time-budget comparison, statistical analysis and replay checks.',
               '- `data/`: 54 fully specified synthetic berth-allocation scenarios, each with a SHA-256 recorded in the manifest.',
               '- `results/all_runs.csv`: 6,480 disaggregated objective scores, seeds, run-times, checksums and feasibility statuses.',
               '- `results/sensitivity_runs.csv`: 2,520 verified PSO parameter-sensitivity observations.',
               '- `results/replayed_run_audit.csv`: 432 reproduced original Stage4 sample runs.',
               '- `results/FULL_INTEGRITY_VERDICT.json`: independent end-to-end audit of 9,384 schedules across experiments.',
               '- `results/paired_case_means.csv`, `factorial_condition_summary.csv`, `blocked_inference.csv`: effect estimates and cautious inference.',
               '- `results/wallclock_runs.csv`: pilot best-so-far values under equal real elapsed time if complete.',
               '', '## Reproduction',
               'From the existing Stage2/Stage3 workspace in this environment:',
               '```bash',
               'python code/stage4.py --runs 30',
               'python code/sensitivity.py',
               'python code/replay_audit.py',
               'python code/analyze.py',
               'python code/time_matched.py --budget 0.35 --reps 8',
               'python code/final_report.py',
               '```',
               'The necessary Stage2/Stage3 source modules are included in `code/dependencies/`; Stage4 scripts use paths relative to this package. Objective scores and instance hashes reproduce exactly; wall-clock durations remain environment-dependent. Re-running scripts overwrites outputs, so make a working copy first.'])
 (O/'STAGE4_TECHNICAL_REPORT.md').write_text('\n'.join(lines)+'\n')
 print('REPORT WRITTEN',len(lines),'blocks')
if __name__=='__main__':main()
