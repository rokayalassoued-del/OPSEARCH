#!/usr/bin/env python3
"""OPSEARCH Stage 4: reproducible, source-identified stress tests. No manuscript editing.
Factorial: size (60/90/120) x nominal work intensity (.65/.90/1.15)
x arrival concentration (.20/.60 of H) x independent baseline seeds (3): 54 cases.
Every final schedule redecoded, then audited by independent canonical checker.
"""
import os,sys,time,hashlib,json,csv,random,statistics,math,platform,argparse
from pathlib import Path
from collections import defaultdict
ROOT=Path(__file__).resolve().parent.parent
DEPS=ROOT/'code'/'dependencies'
if (DEPS/'compare_heuristics.py').exists():
    sys.path.insert(0,str(DEPS))
else:
    raise FileNotFoundError('The bundled Stage-4 dependencies directory is required')
import compare_heuristics as s3
from run_benchmark import decode_to_schedule
from canonical_exact_milp import evaluate_schedule,Instance
import synthetic_pso_experiments as legacy
import scipy,numpy
METHODS=['PSO','GA','SA','MSLS']
SEEDS=(17011,17029,17053)
SIZES=(60,90,120)
RHO=(.65,.90,1.15)
ARRIVAL_FRACTIONS=(.20,.60)

def build_case(n,work,frac,base_seed):
    # Original generator retained; the pairings across factors share original vessels,
    # compatibility and all berth-specific processing relationships before intensity scaling.
    base=legacy.gen_instance(n,base_seed)
    scale=work/base['rho']
    # For arrival concentration, scale sorted original arrivals with roundoff ≤1 h.
    arrivals=[int(math.floor(a*(frac/.35))) for a in base['A']]
    durations=[{i:p*scale for i,p in row.items()} for row in base['P']]
    rho=sum(min(row.values()) for row in durations)/(13*base['H'])
    assert abs(rho-work)<1e-10
    name=f'N{n}_R{int(round(work*100)):03d}_A{int(frac*100):02d}_K{SEEDS.index(base_seed)+1}'
    lg={'n':n,'H':base['H'],'A':arrivals,'feas':[tuple(x) for x in base['feas']],
        'P':durations,'seed':base_seed,'rho':rho}
    can=Instance(tuple(arrivals),tuple(durations),name)
    assert can.n==n and len(can.berths)==13 and len(lg['feas'])==n
    data={'instance':name,'source':'ARCHIVED_GENERATOR_WITH_CONTROLLED_PROCESSING_AND_ARRIVAL_SCALING',
         'n':n,'berths':13,'seed':base_seed,'H_nominal':base['H'],
         'arrival_fraction':frac,'intensity_target':work,'intensity_observed':rho,
         'base_workload_ratio':base['rho'],'process_duration_multiplier':scale,
         'arrivals':arrivals,'p_by_berth':[{str(i):p for i,p in r.items()} for r in durations],
         'U':can.U}
    p=ROOT/'data'/f'{name}.json'
    p.write_text(json.dumps(data,sort_keys=True,indent=2))
    checksum=hashlib.sha256(p.read_bytes()).hexdigest()
    assert len(data['p_by_berth'])==len(data['arrivals'])==n
    return name,lg,can,checksum,data

def execute_method(method,lg,k,work,frac,n):
    # Seeds independent for each method, replicate and scenario; Stage 3's fixed archived PSO
    # is used unaltered, and other methods keep their Stage 3 definitions.
    if method=='PSO':return s3.pso_archived(lg,k),100000+lg['seed']*100+k
    offset={'GA':1,'SA':2,'MSLS':3}[method]
    seed=290000000+lg['seed']*10000+k*100+offset+int(work*100)*1000000+int(frac*100)*10000000+n*100000
    rng=random.Random(seed)
    fn={'GA':s3.ga,'SA':s3.sa,'MSLS':s3.msls_safe}[method]
    return fn(lg,rng),seed

def independent_check(lg,can,seq,score):
    sch=decode_to_schedule(lg,legacy.seq_to_keys(seq))
    audit=evaluate_schedule(can,sch)
    assert audit['ok'] and audit['within_U'],audit
    assert len({r['vessel'] for r in sch})==can.n
    assert math.isclose(audit['objective'],score,rel_tol=2e-11,abs_tol=1e-5),(audit['objective'],score)
    # An alternate, direct invariant check, independent from the canonical checker:
    by_berth=defaultdict(list); ind_obj=0
    for r in sch:
        j=r['vessel']; i=r['berth']; st=r['start']; fin=r['finish']
        assert st >= lg['A'][j]-1e-9
        assert math.isclose(fin-st,lg['P'][j][i],rel_tol=1e-11,abs_tol=1e-7)
        by_berth[i].append((st,fin));ind_obj+=fin-lg['A'][j]
    for blocks in by_berth.values():
        blocks.sort()
        assert all(blocks[k][1]<=blocks[k+1][0]+1e-8 for k in range(len(blocks)-1))
    assert math.isclose(ind_obj,score,rel_tol=2e-11,abs_tol=1e-5)
    return audit,sch

def write_csv(file,rows):
    if not rows:return
    with file.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def main(runs,limit_cases=None):
    start=time.perf_counter(); rows=[]; instances=[]; best={}; count=0
    for n in SIZES:
     for w in RHO:
      for frac in ARRIVAL_FRACTIONS:
       for seed in SEEDS:
        name,lg,can,sha,data=build_case(n,w,frac,seed)
        if limit_cases is not None and count>=limit_cases:break
        instances.append(dict(instance=name,size=n,workload=w,arrival_fraction=frac,base_seed=seed,sha256=sha,U=can.U,base_rho=data['base_workload_ratio'],factor=data['process_duration_multiplier']))
        for method in METHODS:
         for k in range(runs):
          t0=time.perf_counter()
          (score,seq,calls),rng_seed=execute_method(method,lg,k,w,frac,n)
          elapsed=time.perf_counter()-t0
          audit,sch=independent_check(lg,can,seq,score)
          row={'instance':name,'n':n,'rho':w,'arrival_fraction':frac,'base_seed':seed,'input_sha256':sha,
               'algorithm':method,'replicate':k,'random_seed':rng_seed,
               'objective':score,'evals':calls,'runtime_s':elapsed,
               'feasible':True,'max_completion':audit['max_completion'],'U':can.U}
          assert calls==s3.BUDGET
          rows.append(row)
          key=(name,method)
          if key not in best or score<best[key]['objective']:
           best[key]={'instance':name,'method':method,'replicate':k,'objective':score,'schedule':sch}
        count+=1
        if count%3==0:
            print(f'progress {count}/54 instances; {len(rows)} verified runs; {time.perf_counter()-start:.1f}s',flush=True)
            write_csv(ROOT/'results'/'all_runs.csv',rows)
        if limit_cases is not None and count>=limit_cases:break
       if limit_cases is not None and count>=limit_cases:break
      if limit_cases is not None and count>=limit_cases:break
     if limit_cases is not None and count>=limit_cases:break
    write_csv(ROOT/'results'/'all_runs.csv',rows)
    write_csv(ROOT/'results'/'instance_manifest.csv',instances)
    summ=[];group=defaultdict(list)
    for r in rows:group[(r['instance'],r['algorithm'])].append(r)
    for (name,alg),rs in sorted(group.items()):
        vals=[r['objective'] for r in rs];rt=[r['runtime_s'] for r in rs]
        summ.append(dict(instance=name,n=rs[0]['n'],rho=rs[0]['rho'],arrival_fraction=rs[0]['arrival_fraction'],
                         method=alg,runs=len(rs),best=min(vals),mean=statistics.mean(vals),std=statistics.stdev(vals) if len(vals)>1 else 0.0,
                         median=statistics.median(vals),worst=max(vals),mean_runtime_s=statistics.mean(rt)))
    write_csv(ROOT/'results'/'summary.csv',summ)
    with (ROOT/'results'/'best_schedules.jsonl').open('w') as f:
     for k in sorted(best):f.write(json.dumps(best[k])+'\n')
    meta={'status':'COMPLETE','n_instances':count,'n_runs':len(rows),'runs_per_algorithm_per_case':runs,
         'factorial':{'vessels':SIZES,'target_workload':RHO,'arrival_fraction':ARRIVAL_FRACTIONS,'seeds':SEEDS},
         'evaluation_budget':s3.BUDGET,'tested_methods':METHODS,'python':platform.python_version(),
         'numpy':numpy.__version__,'scipy':scipy.__version__,'generator_sha256':hashlib.sha256(Path(legacy.__file__).read_bytes()).hexdigest(),
         'stage3_algo_sha256':hashlib.sha256(Path(s3.__file__).read_bytes()).hexdigest(),'elapsed_s':time.perf_counter()-start,
         'cautions':['synthetic controlled stresses: processing duration scaling including administrative service','workload ratio is min-service /13H, not a physical berth utilization or feasibility guarantee','same 528 evaluations, not equal wall clock','no parameter tuning','new independently seeded cases, not historical study instances']}
    (ROOT/'results'/'metadata.json').write_text(json.dumps(meta,indent=2))
    print('DONE',len(rows),'runs',count,'instances; elapsed',meta['elapsed_s'],flush=True)

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--runs',type=int,default=30);ap.add_argument('--limit-cases',type=int,default=None)
 a=ap.parse_args();main(a.runs,a.limit_cases)
