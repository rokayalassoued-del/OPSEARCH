"""Independent end-to-end reproducibility replay from stored instance manifest and raw runs."""
import csv,sys,math,json,hashlib,time
from collections import defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(ROOT/'code'))
import stage4

def main():
 raw=list(csv.DictReader((ROOT/'results'/'all_runs.csv').open()))
 assert len(raw)==6480
 by={(r['instance'],r['algorithm'],int(r['replicate'])):r for r in raw}
 assert len(by)==6480
 replay=[];count=0
 for n in stage4.SIZES:
  for w in stage4.RHO:
   for frac in stage4.ARRIVAL_FRACTIONS:
    for seed in stage4.SEEDS:
     name,lg,can,sha,dat=stage4.build_case(n,w,frac,seed)
     for method in stage4.METHODS:
      for rep in (0,29):
       reference=by[(name,method,rep)]
       assert sha==reference['input_sha256']
       (obj,seq,calls),s=stage4.execute_method(method,lg,rep,w,frac,n)
       assert s==int(reference['random_seed'])
       assert calls==528
       assert math.isclose(obj,float(reference['objective']),rel_tol=1e-13,abs_tol=1e-7), (name,method,rep,obj,reference['objective'])
       audit,_=stage4.independent_check(lg,can,seq,obj)
       replay.append(dict(instance=name,method=method,replicate=rep,original=float(reference['objective']),replayed=obj,
                          difference=obj-float(reference['objective']),valid=audit['ok']))
     count+=1
     if count%9==0:print('REPLAY',count,'/54 datasets',len(replay),'runs',flush=True)
 stage4.write_csv(ROOT/'results'/'replayed_run_audit.csv',replay)
 (ROOT/'results'/'replay_metadata.json').write_text(json.dumps(dict(status='PASS',cases=54,replayed=432,
   source='raw all_runs.csv; regenerated full datasets from original generator',all_exact_objective_reproductions=True),indent=2))
 print('PASS: 432 independent exact objective reproductions and schedule checks',flush=True)
if __name__=='__main__':main()
