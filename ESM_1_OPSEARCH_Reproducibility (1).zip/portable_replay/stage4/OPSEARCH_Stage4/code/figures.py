"""Generate transparent research plots directly from audited Stage4 CSVs."""
import csv,collections,statistics
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent.parent;O=ROOT/'results';P=O/'figures';P.mkdir(exist_ok=True)
with (O/'paired_case_means.csv').open() as f:rows=list(csv.DictReader(f))
for n in (60,90,120):
 fig,ax=plt.subplots(figsize=(8,5))
 for method in ('PSO','GA','SA','MSLS'):
  xs=[];means=[]
  for rho in (.65,.9,1.15):
   subset=[r for r in rows if int(r['n'])==n and abs(float(r['rho'])-rho)<1e-8]
   xs.append(rho);means.append(statistics.mean(float(r[f'{method}_mean'])/n for r in subset))
  ax.plot(xs,means,marker='o',label=method)
 ax.set_xlabel('Nominal workload intensity (synthetic)')
 ax.set_ylabel('Mean turnaround time per vessel (hours)')
 ax.set_title(f'Synthetic workload sensitivity — {n} vessels')
 ax.grid(alpha=.25);ax.legend()
 fig.tight_layout();fig.savefig(P/f'workload_sensitivity_n{n}.png',dpi=200);plt.close(fig)
fig,ax=plt.subplots(figsize=(8,5))
for comp in ('GA','SA','MSLS'):
 xs=[];ys=[]
 for n in (60,90,120):
  sub=[r for r in rows if int(r['n'])==n]
  xs.append(n);ys.append(statistics.mean(float(r['PSO_advantage_over_'+comp+'_pct']) for r in sub))
 ax.plot(xs,ys,marker='o',label=f'PSO vs {comp}')
ax.set_xlabel('Number of vessels')
ax.set_ylabel('PSO average relative advantage (%)')
ax.set_title('Size sensitivity: paired objective means')
ax.grid(alpha=.25);ax.legend();fig.tight_layout()
fig.savefig(P/'relative_advantage_by_size.png',dpi=200);plt.close(fig)
print('Written 4 figures to',P)
