#!/usr/bin/env python3
"""Independent fair-evaluation benchmark: OPSEARCH Stage 3.
NO manuscript changes. Uses immutable Stage 2 NEW instances or recovered L instances.
Budget = 528 objective calls per run, matching archived random-key PSO:
10 initial + 45*10 + 4*(1 decode gbest + 1 initial local search + 15 neighbors).
Checks every final schedule and its objective with independent MILP validator.
"""
from __future__ import annotations
import argparse, csv, hashlib, json, math, platform, random, statistics, sys, time
from pathlib import Path
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
S2 = HERE
LARGE = HERE
sys.path.insert(0,str(S2/'code'))
from run_benchmark import inputs as s2inputs
from run_benchmark import decode_to_schedule
from canonical_exact_milp import evaluate_schedule, Instance
import synthetic_pso_experiments as legacy
BUDGET=528
METHODS=('PSO','GA','SA','MSLS')

class Counter:
    def __init__(self,lg,budget=BUDGET):
        self.inst=lg; self.calls=0; self.budget=budget
    def eval(self,seq):
        if self.calls >= self.budget: raise RuntimeError('budget exhausted')
        self.calls+=1
        return legacy.decode_keys(self.inst,legacy.seq_to_keys(seq))[0]

def mutate(seq,rng):
    seq=seq[:]; a,b=rng.sample(range(len(seq)),2)
    if rng.random()<0.5: seq[a],seq[b]=seq[b],seq[a]
    else: seq.insert(b,seq.pop(a))
    return seq

def crossover(p1,p2,rng):
    n=len(p1);a,b=sorted(rng.sample(range(n),2));b+=1
    child=[None]*n;child[a:b]=p1[a:b]
    remain=[x for x in p2 if x not in set(p1[a:b])]
    positions=list(range(0,a))+list(range(b,n))
    for pos,x in zip(positions,remain):child[pos]=x
    return child

def ga(lg,rng):
    meter=Counter(lg); n=lg['n']; pop=[]
    for _ in range(24):
        seq=rng.sample(range(n),n)
        pop.append((meter.eval(seq),seq))
    best=min(pop,key=lambda v:v[0]);
    def tournament(): return min(rng.sample(pop,3),key=lambda v:v[0])[1]
    for _ in range(21):
        children=[]
        for _ in range(24):
            mom,dad=tournament(),tournament()
            offspring=crossover(mom,dad,rng) if rng.random()<0.9 else mom[:]
            if rng.random()<0.35:offspring=mutate(offspring,rng)
            children.append((meter.eval(offspring),offspring))
        pop=sorted(pop+children,key=lambda v:v[0])[:24]
        if pop[0][0]<best[0]:best=pop[0]
    assert meter.calls==BUDGET
    return best[0],best[1],meter.calls

def sa(lg,rng):
    meter=Counter(lg);n=lg['n']; cur=rng.sample(range(n),n)
    score=meter.eval(cur);best_score=score;best=cur[:]
    t0=max(1.0, .4*score/n)
    for k in range(BUDGET-1):
        if (k+1)%132==0:
            cur=rng.sample(range(n),n);score=meter.eval(cur)
        else:
            cand=mutate(cur,rng);new=meter.eval(cand)
            temp=max(1e-6,t0*(0.002**(k/(BUDGET-2))))
            if new<=score or rng.random()<math.exp(min(0.0,(score-new)/temp)):
                cur,score=cand,new
        if score<best_score:best_score,best=score,cur[:]
    assert meter.calls==BUDGET
    return best_score,best,meter.calls

def msls_safe(lg,rng):
    meter=Counter(lg);n=lg['n'];seq=rng.sample(range(n),n)
    score=meter.eval(seq);best_score=score;best=seq[:]
    for k in range(BUDGET-1):
        if (k+1)%66==0:
            seq=rng.sample(range(n),n);score=meter.eval(seq)
        else:
            cand=mutate(seq,rng)
            obj=meter.eval(cand)
            if obj<score-1e-10:seq,score=cand,obj
        if score<best_score:best_score,best=score,seq[:]
    assert meter.calls==BUDGET
    return best_score,best,meter.calls

def pso_archived(lg,run):
    """Bitwise same arithmetic and RNG behavior as archived script; track best decoded sequence."""
    n=lg['n'];rng=random.Random(100000+lg['seed']*100+run)
    X=[[rng.random() for _ in range(n)] for _ in range(10)]
    V=[[rng.uniform(-1,1) for _ in range(n)] for _ in range(10)]
    pb=[x[:] for x in X]; scores=[legacy.decode_keys(lg,x)[0] for x in X]
    calls=10
    idx=min(range(10),key=lambda p:scores[p]);gb=pb[idx][:];gscore=scores[idx]
    for it in range(45):
        w=.9-.5*it/44
        for k in range(10):
            xp,vp,pk=X[k],V[k],pb[k]
            for j in range(n):
                v=w*vp[j]+1.7*rng.random()*(pk[j]-xp[j])+2.0*rng.random()*(gb[j]-xp[j])
                v=max(-4.0,min(4.0,v));vp[j]=v;xp[j]+=v
            objective,_=legacy.decode_keys(lg,xp);calls+=1
            if objective<scores[k]:
                scores[k]=objective;pb[k]=xp[:]
                if objective<gscore:gscore,gb=objective,xp[:]
        if it%10==9:
            _,seq=legacy.decode_keys(lg,gb);calls+=1
            local_obj,rngseq=legacy.local_search(lg,seq,max_trials=15,rnd=rng)
            calls+=16 # local_search: one initialization and 15 candidates
            if local_obj<gscore:gscore,gb=local_obj,legacy.seq_to_keys(rngseq)
    seq=legacy.decode_keys(lg,gb)[1] # post-run decoding not an optimization evaluation
    assert calls==BUDGET
    return gscore,seq,calls

def load_instance(name):
    if name[0] in ('S','M'):
        o,can,lg,sha=s2inputs(name)
        return can,lg,sha,'NEW_VALIDATION'
    seed={'L1':15,'L2':11,'L3':37,'L4':23,'L5':23,'L6':12}[name]
    # source: recovered verified deterministic generator (13 berths)
    lg=legacy.gen_instance({'L1':60,'L2':72,'L3':84,'L4':96,'L5':108,'L6':120}[name],seed)
    can=Instance(tuple(float(a) for a in lg['A']),tuple({int(i):float(p) for i,p in d.items()} for d in lg['P']),name)
    sha=hashlib.sha256((LARGE/f'{name}_seed{seed}.json').read_bytes()).hexdigest()
    return can,lg,sha,'ARCHIVED_GENERATOR_REGENERATED'

def run(names,runs=30):
    output=ROOT/'results';output.mkdir(exist_ok=True,parents=True)
    # The historical Stage-3 runner's external reference tables are not used by nested stages.
    existing={}
    exact={}
    raw=[];summary=[];best_schedules=[]
    for name in names:
        can,lg,sha,origin=load_instance(name)
        for meth in METHODS:
            vals=[];tms=[];bests=None
            for replicate in range(runs):
                if meth=='PSO': fn=lambda:pso_archived(lg,replicate)
                else:
                    seed=(250000000+lg['seed']*1000+replicate*101+{'GA':1,'SA':2,'MSLS':3}[meth]);rng=random.Random(seed)
                    fn={'GA':lambda:ga(lg,rng),'SA':lambda:sa(lg,rng),'MSLS':lambda:msls_safe(lg,rng)}[meth]
                t=time.perf_counter();obj,seq,calls=fn();elapsed=time.perf_counter()-t
                schedule=decode_to_schedule(lg,legacy.seq_to_keys(seq))
                audit=evaluate_schedule(can,schedule)
                valid=bool(audit['ok'] and audit['within_U'] and math.isclose(float(audit['objective']),obj,rel_tol=1e-9,abs_tol=1e-5))
                if not valid:raise RuntimeError(f'invalid {name} {meth} {replicate}: {audit} vs {obj}')
                if meth=='PSO' and (name,replicate) in existing and not math.isclose(obj,existing[(name,replicate)],rel_tol=1e-12,abs_tol=1e-7):
                    raise RuntimeError(f'Archived PSO mismatch for {name} run {replicate}: {obj}, previous={existing[(name,replicate)]}')
                row=dict(instance=name,origin=origin,input_sha256=sha,n_vessels=lg['n'],n_berths=len(can.berths),method=meth,replicate=replicate,random_seed=100000+lg['seed']*100+replicate if meth=='PSO' else seed,objective=obj,objective_evaluations=calls,runtime_s=elapsed,feasible=valid)
                raw.append(row);vals.append(obj);tms.append(elapsed)
                if bests is None or obj<bests[0]:bests=(obj,schedule,replicate)
            fcfs=min((max(lg['A'][j],0.0),j) for j in range(lg['n'])) if False else None
            opt=float(exact[name]['MILP_objective']) if name in exact and exact[name]['certified_optimal']=='True' else None
            bound=float(exact[name]['MILP_lower_bound']) if name in exact and exact[name]['MILP_lower_bound'] else None
            summary.append(dict(instance=name,origin=origin,method=meth,runs=runs,evaluations_per_run=BUDGET,best=min(vals),mean=statistics.mean(vals),median=statistics.median(vals),sample_std=statistics.stdev(vals),worst=max(vals),mean_runtime_s=statistics.mean(tms),optimum_proven=opt,exact_lower_bound=bound,
                best_gap_to_opt_pct=(min(vals)/opt-1)*100 if opt is not None else None,
                optimal_hits=sum(abs(v-opt)<=1e-5 for v in vals) if opt is not None else None))
            best_schedules.append(dict(instance=name,method=meth,replicate=bests[2],objective=bests[0],schedule=bests[1]))
            print(f'{name} {meth:<4} best={min(vals):12.3f} mean={statistics.mean(vals):12.3f} sd={statistics.stdev(vals):8.3f} t={statistics.mean(tms):.3f}s  valid={len(vals)}',flush=True)
        output_csv(output/'all_runs.csv',raw)
        output_csv(output/'method_summary.csv',summary)
        with (output/'best_schedules.jsonl').open('w') as f:
            for row in best_schedules:f.write(json.dumps(row)+'\n')
    meta={'date':'2026-10-31','description':'OPSEARCH Stage 3 independent 4-algorithm matched fitness-call evaluation','budget_per_run':BUDGET,'replicates':runs,'origin_small':'new reduced instances not historical','origin_large':'recovered legacy generator and seeds','source_unchanged':True,'python':platform.python_version(),'methods':{'PSO':'replayed exact archived random-key PSO trajectory, 10 particles, 45 iterations, 4x15 stochastic local moves','GA':'population 24, 21 generations x24 new children, order crossover 0.9, mutation 0.35, tournament 3, retain best 24','SA':'4 cooling epochs, 527 proposal/restart evaluations, randomized pair swap/insertion, geometric cooling 0.4*obj/n to 0.002 of initial T','MSLS':'eight random-start hill-climbing epochs, 527 proposals and restarts, strict-improvement swap/insertion'},'fairness':'identical fitness evaluations, exact same greedy berth decoder; runtimes recorded but are not equalized; no automatic parameter tuning'}
    (output/'environment_and_methods.json').write_text(json.dumps(meta,indent=2))
    print('FINISHED',len(raw),'complete validated runs',flush=True)

def output_csv(path,rows):
    if not rows:return
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys()));w.writeheader();w.writerows(rows)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--names',nargs='+',default=[f'S{i}' for i in range(1,7)]+[f'M{i}' for i in range(1,5)]+[f'L{i}' for i in range(1,7)]);ap.add_argument('--runs',type=int,default=30)
    a=ap.parse_args();run(a.names,a.runs)
