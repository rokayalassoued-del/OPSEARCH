"""Controlled PSO sensitivity. Fixed 528 objective evaluations, independently audited.
Stand-alone research script; original source and Stage 3 runs remain untouched.
"""
import sys,math,time,random,json,csv,hashlib,statistics,platform
from pathlib import Path
from collections import defaultdict
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'code'))
import stage4
import synthetic_pso_experiments as legacy
from compare_heuristics import pso_archived
from run_benchmark import decode_to_schedule
from canonical_exact_milp import evaluate_schedule
BUDGET=528
VARIANTS={
 'archived':dict(swarm=10,c1=1.7,c2=2.0,local_trials=15),
 'balanced':dict(swarm=10,c1=1.5,c2=1.5,local_trials=15),
 'social_dominant':dict(swarm=10,c1=1.2,c2=2.5,local_trials=15),
 'cognitive_dominant':dict(swarm=10,c1=2.5,c2=1.2,local_trials=15),
 'swarm_6':dict(swarm=6,c1=1.7,c2=2.0,local_trials=15),
 'swarm_16':dict(swarm=16,c1=1.7,c2=2.0,local_trials=15),
 'no_local_search':dict(swarm=10,c1=1.7,c2=2.0,local_trials=0),
}

def variant_pso(inst,replicate,config):
    n=inst['n']; r=random.Random(100000+inst['seed']*100+replicate)
    S=config['swarm']; T=config['local_trials'];c1=config['c1'];c2=config['c2']
    X=[[r.random() for _ in range(n)] for _ in range(S)]
    V=[[r.uniform(-1,1) for _ in range(n)] for _ in range(S)]
    pb=[x[:] for x in X]; scores=[legacy.decode_keys(inst,x)[0] for x in X];count=S
    k=min(range(S),key=lambda i:scores[i]);gb=pb[k][:];best=scores[k]
    # approximate theoretical full iteration count needed for a 528-evaluation budget.
    I_est=math.ceil((BUDGET-S)/(S+((1+T)/10 if T else 0)))
    i=0
    while count < BUDGET:
        w=.9-.5*min(1,i/max(1,I_est-1))
        for p in range(S):
            if count>=BUDGET:break
            xp,vp,pk=X[p],V[p],pb[p]
            for j in range(n):
                v=w*vp[j]+c1*r.random()*(pk[j]-xp[j])+c2*r.random()*(gb[j]-xp[j])
                v=max(-4.,min(4.,v));vp[j]=v;xp[j]+=v
            score,_=legacy.decode_keys(inst,xp);count+=1
            if score<scores[p]:
                scores[p]=score;pb[p]=xp[:]
                if score<best:best=score;gb=xp[:]
        if T and i%10==9 and count+1+T+1<=BUDGET:
            _,seq=legacy.decode_keys(inst,gb);count+=1
            loc,rseq=legacy.local_search(inst,seq,max_trials=T,rnd=r)
            count+=T+1
            if loc<best:best=loc;gb=legacy.seq_to_keys(rseq)
        i+=1
    seq=legacy.decode_keys(inst,gb)[1]
    assert count==BUDGET
    return best,seq,count

def main(reps=15):
    records=[];start=time.perf_counter();idx=0
    for n in (60,120):
      for w in (.65,.90,1.15):
       for f in (.20,.60):
        for seed in (17011,17029):
         name,lg,can,sha,data=stage4.build_case(n,w,f,seed)
         for label,params in VARIANTS.items():
          for rep in range(reps):
           t0=time.perf_counter()
           obj,seq,calls=variant_pso(lg,rep,params)
           elapsed=time.perf_counter()-t0
           audit,_=stage4.independent_check(lg,can,seq,obj)
           if label=='archived' and rep in (0,1):
              archived_obj=pso_archived(lg,rep)[0]
              assert math.isclose(obj,archived_obj,abs_tol=1e-6,rel_tol=1e-12),(name,rep,obj,archived_obj)
           records.append(dict(instance=name,n=n,rho=w,arrival_fraction=f,seed=seed,variant=label,replicate=rep,
                    objective=obj,evaluations=calls,runtime_s=elapsed,feasible=audit['ok'],sha256=sha))
         idx+=1
         if idx%3==0:
             print('progress',idx,'/24 sensitivity cases;',len(records),'verified; time',round(time.perf_counter()-start,1),flush=True)
             stage4.write_csv(ROOT/'results'/'sensitivity_runs.csv',records)
    stage4.write_csv(ROOT/'results'/'sensitivity_runs.csv',records)
    out=[];grp=defaultdict(list)
    for x in records:grp[(x['instance'],x['variant'])].append(x['objective'])
    for (name,v),a in grp.items():out.append(dict(instance=name,variant=v,n=len(a),best=min(a),mean=statistics.mean(a),std=statistics.stdev(a)))
    stage4.write_csv(ROOT/'results'/'sensitivity_summary.csv',out)
    meta=dict(status='COMPLETE',n_runs=len(records),cases=idx,replicates=reps,variants=VARIANTS,evals=528,
        independent_schedule_checks=len(records),elapsed_s=time.perf_counter()-start,
        scope='sensitivity only; not a general tuning recommendation; same 528 evaluations')
    (ROOT/'results'/'sensitivity_metadata.json').write_text(json.dumps(meta,indent=2))
    print('DONE sensitivity',len(records),'runs',flush=True)
if __name__=='__main__':main()
