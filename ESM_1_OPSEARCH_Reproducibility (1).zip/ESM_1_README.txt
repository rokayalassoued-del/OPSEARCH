Online Resource 1 — Reproducibility package

Journal: OPSEARCH
Manuscript: Dynamic discrete berth allocation in bulk ports: an exact formulation and a random-key particle swarm optimization approach
Manuscript ID: OPSE-D-26-00417
Authors: Rokaya Lassoued and Abdelkarim Elloumi
Affiliation: Laboratory of Modeling and Optimization for Decisional, Industrial and Logistic Systems (MODILS), Faculty of Economics and Management of Sfax, University of Sfax, Tunisia
Corresponding author: Rokaya Lassoued
Contact: rokaya.lassoued@fsegs.usf.tn

Contents: Full archived benchmark and reproducibility materials; original large-instance generator and recovered code; new synthetic instance files; algorithm source codes; optimizer output and solver certificates where available; per-run numerical outputs; experiment and result lineage; and integrity checks.

Evidence limits: The historical original reduced S1–M4 instance inputs and original solver certificates have not been recovered. The original-run CPU, RAM and operating-system details cannot be independently established from the archived outputs. NEW-M4 is time-limited with a 15.78% certified objective gap; the experiments are synthetic.

Index: See REPRODUCIBILITY_PACKAGE_INDEX.md and the SHA256 manifest included at the root of this archive.
