# Included reproducibility archives

These archives are **unchanged copies** of previously verified research packages. They are nested here to preserve dataset, code, output, schedule, and solver evidence in their original folder layout. Their original contents were not rewritten.

- `original_SUBMITTED_source_and_recovered_generator.zip`: original journal-submission manuscript source, archived exact results summary, recovered generator and PSO, and historical materials.
- `NEW_exact_instances_and_MILP_code.zip`: 10 distinct new small/medium JSON inputs and independent MILP formulation scripts. **Original historical S/M vessel-level inputs remain missing.**
- `NEW_30run_large_comparisons.zip`: regenerated original L1–L6 inputs, 30-run GA/SA/PSO/MSLS code and schedules.
- `EXPLORATORY_congestion_sensitivity.zip`: Stage 4 parameters, synthetic factorial runs and exploratory wall-time experiments. This experiment has only 3 independent seed families.
- `INDEPENDENT_family_holdout_12seeds.zip`: Stage 5 96 JSON cases, 5,760 runs, 12 family effects and replay scripts.
- `ARRIVAL_patterns_and_MILP3600_solver_certificates.zip`: Stage 6 144 arrival-process cases; all 10 NEW exact-case solver JSONs, M3/M4 one-hour logs, and independent audits are stored under `OPSEARCH_Stage6/evidence/`.

For direct inspection of selected outcomes, use the shorter CSV files in the root and the `source_records/` folder. All Stage 5/6 percentages were re-aggregated from the unchanged raw CSVs using the source data.

**Traceability note:** code and hashes support computational reproducibility; they cannot retroactively recover missing historical S1–M4 input files or prove field validity of synthetic inputs.
